/** @type {import('tailwindcss').Config} */
/*
 * Tema "Kampus Hijau" — kertas krem, hijau hutan, aksen lime.
 * Token lama (navy, amber, paper, dll.) tetap ada agar panel admin & halaman lama
 * otomatis mengikuti palet baru.
 */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: { DEFAULT: '#0E3326', 700: '#174A38', 600: '#1E6B4F', 100: '#D3E2D8', 50: '#E7EFE8' },
        accent: { DEFAULT: '#3A7A1E', hover: '#2F6617', soft: '#E4F0D4' },
        lime: { DEFAULT: '#D4EE4E', deep: '#B9D62E', soft: '#F1F8C9' },
        surface: '#ECE6D8',
        cream: '#F5F1E8',
        line: '#D9D1BF',
        muted: '#5C6358',
        navy: { DEFAULT: '#0E3326', light: '#174A38', line: '#2A5A48' },
        paper: '#F5F1E8',
        mist: '#EFEAE0',
        ink: '#15201A',
        amber: '#D4EE4E',
        'amber-soft': '#F1F8C9',
        teal: '#1E6B4F',
        'teal-soft': '#E1EDE4',
        hairline: '#D9D1BF',
      },
      fontFamily: {
        display: ['Zodiak', 'Georgia', 'serif'],
        body: ['Satoshi', '"Segoe UI"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
        code: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        soft: '0 1px 0 rgba(14,51,38,0.08)',
        elegant: '6px 6px 0 0 #0E3326',
        glow: '4px 4px 0 0 #0E3326',
        card: '4px 4px 0 0 rgba(14,51,38,0.9)',
        ambient: '0 1px 0 rgba(14,51,38,0.06)',
        hard: '6px 6px 0 0 #0E3326',
        'hard-sm': '3px 3px 0 0 #0E3326',
        'hard-lime': '6px 6px 0 0 #D4EE4E',
      },
      borderRadius: {
        sm: '2px', DEFAULT: '3px', md: '4px', lg: '5px', xl: '6px', '2xl': '8px', '3xl': '10px', xl2: '8px',
      },
    },
  },
  plugins: [],
}
