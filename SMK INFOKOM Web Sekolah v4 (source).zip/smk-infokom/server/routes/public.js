import { Router } from 'express'
import rateLimit from 'express-rate-limit'
import { db } from '../db/knex.js'
import { RESOURCES } from '../resources.js'
import { listRows, getSettings } from '../lib/query.js'
import { validatePayload, serialize, HttpError } from '../lib/validate.js'

const router = Router()
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next)

const formLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false, message: { error: 'Terlalu banyak pengiriman. Coba lagi dalam 15 menit.' } })

router.get('/settings', wrap(async (req, res) => {
  res.set('Cache-Control', 'no-cache')
  res.json(await getSettings())
}))

/** Data ringkas untuk beranda dalam satu permintaan. */
router.get('/beranda', wrap(async (req, res) => {
  const [jurusan, berita, testimoni, tahapan, agenda] = await Promise.all([
    listRows('jurusan', RESOURCES.jurusan, {}, { publicMode: true }),
    listRows('berita', RESOURCES.berita, { limit: 3 }, { publicMode: true }),
    listRows('testimoni', RESOURCES.testimoni, {}, { publicMode: true }),
    listRows('tahapan', RESOURCES.tahapan, {}, { publicMode: true }),
    listRows('agenda', RESOURCES.agenda, { limit: 100 }, { publicMode: true }),
  ])
  const today = new Date().toISOString().slice(0, 10)
  const upcoming = agenda.data.filter((a) => (a.tanggal_selesai || a.tanggal) >= today).slice(0, 4)
  res.json({ jurusan: jurusan.data, berita: berita.data, testimoni: testimoni.data, tahapan: tahapan.data, agenda: upcoming })
}))

/* ---------- Formulir publik ---------- */

router.post('/pesan', formLimiter, wrap(async (req, res) => {
  if (req.body?.website) return res.status(201).json({ ok: true }) // honeypot anti-spam
  const data = await validatePayload('pesan', RESOURCES.pesan, req.body)
  data.dibaca = false
  await db('pesan').insert(data)
  res.status(201).json({ ok: true, message: 'Pesan terkirim. Terima kasih!' })
}))

async function nomorPendaftaran() {
  const year = new Date().getFullYear()
  const prefix = `PPDB-${year}-`
  const last = await db('pendaftar').where('nomor', 'like', `${prefix}%`).orderBy('id', 'desc').first()
  const next = last ? Number(String(last.nomor).slice(prefix.length)) + 1 : 1
  return prefix + String(next).padStart(4, '0')
}

router.post('/pendaftaran', formLimiter, wrap(async (req, res) => {
  if (req.body?.website) return res.status(201).json({ ok: true, nomor: '-' })
  const settings = await getSettings()
  if (settings.ppdb_dibuka === 'false') throw new HttpError(403, 'Pendaftaran online sedang ditutup.')

  const body = { ...req.body }
  delete body.status
  delete body.catatan_admin
  const data = await validatePayload('pendaftar', RESOURCES.pendaftar, body)

  const jur = await db('jurusan').where({ slug: data.jurusan_1, aktif: true }).first()
  if (!jur) throw new HttpError(422, 'Periksa kembali isian formulir.', { jurusan_1: 'Pilihan jurusan tidak tersedia' })
  if (!/^\d{10}$/.test(data.nisn)) throw new HttpError(422, 'Periksa kembali isian formulir.', { nisn: 'NISN harus 10 digit angka' })
  const dup = await db('pendaftar').where({ nisn: data.nisn }).first()
  if (dup) throw new HttpError(409, `NISN ini sudah terdaftar dengan nomor ${dup.nomor}. Gunakan menu Cek Status.`)

  data.status = 'baru'
  data.nomor = await nomorPendaftaran()
  await db('pendaftar').insert(data)
  res.status(201).json({ ok: true, nomor: data.nomor, nama: data.nama })
}))

router.get('/pendaftaran/cek', formLimiter, wrap(async (req, res) => {
  const nomor = String(req.query.nomor || '').trim().toUpperCase()
  const tgl = String(req.query.tanggal_lahir || '').trim()
  if (!nomor || !tgl) throw new HttpError(400, 'Nomor pendaftaran dan tanggal lahir wajib diisi.')
  const row = await db('pendaftar').where({ nomor }).first()
  if (!row || String(row.tanggal_lahir).slice(0, 10) !== tgl) throw new HttpError(404, 'Data pendaftaran tidak ditemukan. Periksa kembali nomor dan tanggal lahir.')
  const jur = await db('jurusan').where({ slug: row.jurusan_1 }).first()
  res.json({
    nomor: row.nomor, nama: row.nama, asal_sekolah: row.asal_sekolah, status: row.status,
    jurusan: jur ? jur.nama : row.jurusan_1, catatan: row.catatan_admin || '', tanggal_daftar: row.created_at,
  })
}))

/* ---------- BKK ---------- */

router.post('/lamaran', formLimiter, wrap(async (req, res) => {
  if (req.body?.website) return res.status(201).json({ ok: true })
  const body = { ...req.body }
  delete body.status
  const data = await validatePayload('lamaran', RESOURCES.lamaran, body)
  const low = await db('lowongan').where({ id: Number(data.lowongan_id) || 0 }).first()
  if (!low) throw new HttpError(404, 'Lowongan tidak ditemukan.')
  if (low.status !== 'dibuka') throw new HttpError(403, 'Lowongan ini sudah ditutup.')
  const dup = await db('lamaran').where({ lowongan_id: low.id, email: data.email }).first()
  if (dup) throw new HttpError(409, 'Kamu sudah mengirim lamaran untuk lowongan ini dengan email yang sama.')
  data.lowongan_judul = `${low.judul} — ${low.perusahaan}`
  data.status = 'baru'
  await db('lamaran').insert(data)
  res.status(201).json({ ok: true, message: 'Lamaran terkirim. Tim BKK akan menghubungi kamu.' })
}))

router.post('/alumni', formLimiter, wrap(async (req, res) => {
  if (req.body?.website) return res.status(201).json({ ok: true })
  const data = await validatePayload('alumni', RESOURCES.alumni, req.body)
  await db('alumni').insert(data)
  res.status(201).json({ ok: true, message: 'Terima kasih, data kamu sudah tercatat di BKK.' })
}))

/* ---------- Magang Jepang ---------- */

async function nomorMagang() {
  const year = new Date().getFullYear()
  const prefix = `MJ-${year}-`
  const last = await db('pendaftar_magang').where('nomor', 'like', `${prefix}%`).orderBy('id', 'desc').first()
  const next = last ? Number(String(last.nomor).slice(prefix.length)) + 1 : 1
  return prefix + String(next).padStart(4, '0')
}

router.post('/pendaftaran-magang', formLimiter, wrap(async (req, res) => {
  if (req.body?.website) return res.status(201).json({ ok: true, nomor: '-' })
  const settings = await getSettings()
  if (settings.magang_dibuka === 'false') throw new HttpError(403, 'Pendaftaran Magang Jepang sedang ditutup.')
  const body = { ...req.body }
  delete body.status
  delete body.catatan_admin
  const data = await validatePayload('pendaftar_magang', RESOURCES.pendaftar_magang, body)
  const lahir = new Date(data.tanggal_lahir)
  const umur = (Date.now() - lahir.getTime()) / (365.25 * 86400000)
  if (!(umur >= 17 && umur <= 27)) throw new HttpError(422, 'Periksa kembali isian formulir.', { tanggal_lahir: 'Usia peserta harus 17 — 27 tahun' })
  const dup = await db('pendaftar_magang').where({ telepon: data.telepon, tanggal_lahir: data.tanggal_lahir }).first()
  if (dup) throw new HttpError(409, `Data ini sudah terdaftar dengan nomor ${dup.nomor}. Gunakan menu Cek Status.`)
  data.status = 'baru'
  data.nomor = await nomorMagang()
  await db('pendaftar_magang').insert(data)
  res.status(201).json({ ok: true, nomor: data.nomor, nama: data.nama })
}))

router.get('/pendaftaran-magang/cek', formLimiter, wrap(async (req, res) => {
  const nomor = String(req.query.nomor || '').trim().toUpperCase()
  const tgl = String(req.query.tanggal_lahir || '').trim()
  if (!nomor || !tgl) throw new HttpError(400, 'Nomor pendaftaran dan tanggal lahir wajib diisi.')
  const row = await db('pendaftar_magang').where({ nomor }).first()
  if (!row || String(row.tanggal_lahir).slice(0, 10) !== tgl) throw new HttpError(404, 'Data tidak ditemukan. Periksa kembali nomor dan tanggal lahir.')
  res.json({ nomor: row.nomor, nama: row.nama, bidang: row.bidang_minat, status: row.status, catatan: row.catatan_admin || '', tanggal_daftar: row.created_at })
}))

/* ---------- Data publik generik ---------- */

router.get('/:resource', wrap(async (req, res) => {
  const def = RESOURCES[req.params.resource]
  if (!def || !def.public) throw new HttpError(404, 'Data tidak ditemukan.')
  res.json(await listRows(req.params.resource, def, req.query, { publicMode: true }))
}))

router.get('/:resource/:key', wrap(async (req, res) => {
  const name = req.params.resource
  const def = RESOURCES[name]
  if (!def || !def.public) throw new HttpError(404, 'Data tidak ditemukan.')
  const key = req.params.key
  const q = db(name).modify((qq) => { if (def.publicWhere) qq.where(def.publicWhere) })
  const row = def.fields.slug
    ? await q.where((w) => { w.where('slug', key); if (/^\d+$/.test(key)) w.orWhere('id', Number(key)) }).first()
    : await q.where({ id: Number(key) || 0 }).first()
  if (!row) throw new HttpError(404, 'Data tidak ditemukan.')
  res.json(serialize(def, row, { hide: def.publicHidden || [] }))
}))

export default router
