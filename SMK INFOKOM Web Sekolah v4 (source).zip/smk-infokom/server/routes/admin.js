import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { Router } from 'express'
import multer from 'multer'
import bcrypt from 'bcryptjs'
import { db } from '../db/knex.js'
import { config } from '../config.js'
import { RESOURCES } from '../resources.js'
import { SETTING_GROUPS, SETTING_KEYS } from '../settings.js'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { listRows, getSettings } from '../lib/query.js'
import { validatePayload, serialize, HttpError } from '../lib/validate.js'

const router = Router()
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next)
const stamp = () => new Date().toISOString().slice(0, 19).replace('T', ' ')

router.use(requireAuth)

/* ---------- Metadata untuk membangun form admin ---------- */
router.get('/meta', (req, res) => {
  const resources = Object.fromEntries(
    Object.entries(RESOURCES)
      .filter(([, r]) => !r.adminOnly || req.user.role === 'admin')
      .map(([k, r]) => [k, { ...r, publicWhere: undefined }]),
  )
  res.json({ resources, settings: req.user.role === 'admin' ? SETTING_GROUPS : [] })
})

/* ---------- Ringkasan dashboard ---------- */
router.get('/stats', wrap(async (req, res) => {
  const count = async (t, where) => Number((await db(t).modify((q) => where && q.where(where)).count({ n: '*' }))[0].n)
  const [berita, guru, jurusan, galeri, pendaftar, pendaftarBaru, pesanBaru, prestasi] = await Promise.all([
    count('berita'), count('guru'), count('jurusan'), count('galeri'), count('pendaftar'),
    count('pendaftar', { status: 'baru' }), count('pesan', { dibaca: false }), count('prestasi'),
  ])
  const [lowonganAktif, lamaranBaru, magangTotal, magangBaru, alumniTotal] = await Promise.all([
    count('lowongan', { status: 'dibuka' }), count('lamaran', { status: 'baru' }), count('pendaftar_magang'),
    count('pendaftar_magang', { status: 'baru' }), count('alumni'),
  ])
  const perJurusan = await db('pendaftar').select('jurusan_1').count({ n: '*' }).groupBy('jurusan_1')
  const perStatus = await db('pendaftar').select('status').count({ n: '*' }).groupBy('status')
  const jurusanList = await db('jurusan').select('slug', 'kode', 'nama')
  const recentPendaftar = await db('pendaftar').orderBy('id', 'desc').limit(5).select('id', 'nomor', 'nama', 'asal_sekolah', 'jurusan_1', 'status', 'created_at')
  const recentPesan = await db('pesan').orderBy('id', 'desc').limit(5).select('id', 'nama', 'subjek', 'dibaca', 'created_at')
  const recentBerita = await db('berita').orderBy('tanggal', 'desc').limit(5).select('id', 'judul', 'kategori', 'tanggal', 'status')
  res.json({
    counts: { berita, guru, jurusan, galeri, pendaftar, pendaftarBaru, pesanBaru, prestasi, lowonganAktif, lamaranBaru, magangTotal, magangBaru, alumniTotal },
    perJurusan: jurusanList.map((j) => ({ ...j, n: Number(perJurusan.find((p) => p.jurusan_1 === j.slug)?.n || 0) })),
    perStatus: perStatus.map((s) => ({ status: s.status, n: Number(s.n) })),
    recentPendaftar,
    recentPesan: recentPesan.map((p) => ({ ...p, dibaca: p.dibaca === true || p.dibaca === 1 })),
    recentBerita,
  })
}))

/* ---------- Pengaturan situs ---------- */
router.get('/settings', requireRole('admin'), wrap(async (req, res) => res.json(await getSettings())))

router.put('/settings', requireRole('admin'), wrap(async (req, res) => {
  const body = req.body || {}
  const entries = Object.entries(body).filter(([k]) => SETTING_KEYS.has(k))
  await db.transaction(async (trx) => {
    for (const [key, value] of entries) {
      const v = value === null || value === undefined ? '' : String(value).slice(0, 20000)
      const exists = await trx('settings').where({ key }).first()
      if (exists) await trx('settings').where({ key }).update({ value: v, updated_at: stamp() })
      else await trx('settings').insert({ key, value: v, updated_at: stamp() })
    }
  })
  res.json(await getSettings())
}))

/* ---------- Unggah gambar ---------- */
fs.mkdirSync(config.uploadDir, { recursive: true })
const ALLOWED = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' }
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const sub = new Date().toISOString().slice(0, 7) // YYYY-MM
      const dir = path.join(config.uploadDir, sub)
      fs.mkdirSync(dir, { recursive: true })
      cb(null, dir)
    },
    filename: (req, file, cb) => cb(null, `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ALLOWED[file.mimetype] || '.jpg'}`),
  }),
  limits: { fileSize: config.maxUploadMb * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => (ALLOWED[file.mimetype] ? cb(null, true) : cb(new HttpError(422, 'File harus berupa gambar JPG, PNG, WebP, atau GIF.'))),
})

router.post('/upload', (req, res, next) => {
  upload.single('file')(req, res, (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') return next(new HttpError(413, `Ukuran file maksimal ${config.maxUploadMb} MB.`))
      return next(err)
    }
    if (!req.file) return next(new HttpError(400, 'Tidak ada file yang diunggah.'))
    const rel = path.relative(config.uploadDir, req.file.path).split(path.sep).join('/')
    res.status(201).json({ url: `/uploads/${rel}`, size: req.file.size })
  })
})

/* ---------- CRUD generik ---------- */
function resolve(req) {
  const name = req.params.resource
  const def = RESOURCES[name]
  if (!def) throw new HttpError(404, 'Resource tidak dikenal.')
  if (def.adminOnly && req.user.role !== 'admin') throw new HttpError(403, 'Hanya admin yang dapat mengelola data ini.')
  return { name, def }
}

function csvEscape(v) {
  if (v === null || v === undefined) return ''
  const s = Array.isArray(v) ? v.join('; ') : String(v)
  return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

router.get('/:resource/export.csv', wrap(async (req, res) => {
  const { name, def } = resolve(req)
  if (!def.exportable) throw new HttpError(404, 'Ekspor tidak tersedia.')
  const { data } = await listRows(name, def, { ...req.query, limit: 500, page: 1 })
  const cols = ['id', ...Object.keys(def.fields).filter((k) => def.fields[k].type !== 'password'), 'created_at']
  const header = cols.map((c) => csvEscape(def.fields[c]?.label || c)).join(',')
  const lines = data.map((r) => cols.map((c) => csvEscape(r[c])).join(','))
  res.setHeader('Content-Type', 'text/csv; charset=utf-8')
  res.setHeader('Content-Disposition', `attachment; filename="${name}-${new Date().toISOString().slice(0, 10)}.csv"`)
  res.send('\uFEFF' + [header, ...lines].join('\n'))
}))

router.get('/:resource', wrap(async (req, res) => {
  const { name, def } = resolve(req)
  res.json(await listRows(name, def, req.query))
}))

router.get('/:resource/:id', wrap(async (req, res) => {
  const { name, def } = resolve(req)
  const row = await db(name).where({ id: Number(req.params.id) }).first()
  if (!row) throw new HttpError(404, 'Data tidak ditemukan.')
  res.json(serialize(def, row))
}))

router.post('/:resource', wrap(async (req, res) => {
  const { name, def } = resolve(req)
  if (def.canCreate === false) throw new HttpError(405, 'Data ini tidak dapat ditambahkan dari panel admin.')
  const data = await validatePayload(name, def, req.body)
  if (data.password) data.password = await bcrypt.hash(data.password, 10)
  if (name === 'pendaftar') {
    const year = new Date().getFullYear()
    const last = await db('pendaftar').where('nomor', 'like', `PPDB-${year}-%`).orderBy('id', 'desc').first()
    data.nomor = `PPDB-${year}-${String(last ? Number(last.nomor.split('-')[2]) + 1 : 1).padStart(4, '0')}`
  }
  const ts = stamp()
  const inserted = await db(name).insert({ ...data, created_at: ts, updated_at: ts }).returning('id')
  const id = typeof inserted[0] === 'object' ? inserted[0].id : inserted[0]
  const row = await db(name).where({ id }).first()
  res.status(201).json(serialize(def, row))
}))

router.put('/:resource/:id', wrap(async (req, res) => {
  const { name, def } = resolve(req)
  const id = Number(req.params.id)
  const current = await db(name).where({ id }).first()
  if (!current) throw new HttpError(404, 'Data tidak ditemukan.')
  const data = await validatePayload(name, def, req.body, { partial: true, id })
  if (data.password) data.password = await bcrypt.hash(data.password, 10)
  if (name === 'users' && id === req.user.id) {
    if (data.role && data.role !== 'admin') throw new HttpError(422, 'Anda tidak bisa menurunkan peran akun sendiri.')
    if (data.aktif === false) throw new HttpError(422, 'Anda tidak bisa menonaktifkan akun sendiri.')
  }
  await db(name).where({ id }).update({ ...data, updated_at: stamp() })
  res.json(serialize(def, await db(name).where({ id }).first()))
}))

router.delete('/:resource/:id', wrap(async (req, res) => {
  const { name } = resolve(req)
  const id = Number(req.params.id)
  if (name === 'users') {
    if (id === req.user.id) throw new HttpError(422, 'Anda tidak bisa menghapus akun sendiri.')
    const [{ n }] = await db('users').where({ role: 'admin' }).whereNot({ id }).count({ n: '*' })
    const target = await db('users').where({ id }).first()
    if (target?.role === 'admin' && Number(n) === 0) throw new HttpError(422, 'Minimal harus ada satu admin.')
  }
  const deleted = await db(name).where({ id }).del()
  if (!deleted) throw new HttpError(404, 'Data tidak ditemukan.')
  res.json({ ok: true })
}))

export default router
