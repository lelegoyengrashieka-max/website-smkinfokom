import { Router } from 'express'
import bcrypt from 'bcryptjs'
import rateLimit from 'express-rate-limit'
import { db } from '../db/knex.js'
import { signToken, requireAuth } from '../middleware/auth.js'
import { HttpError } from '../lib/validate.js'

const router = Router()
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next)

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Terlalu banyak percobaan login. Coba lagi dalam 15 menit.' } })

router.post('/login', loginLimiter, wrap(async (req, res) => {
  const username = String(req.body?.username || '').trim()
  const password = String(req.body?.password || '')
  if (!username || !password) throw new HttpError(400, 'Username dan password wajib diisi.')
  const user = await db('users').where({ username }).first()
  const ok = user && (user.aktif === true || user.aktif === 1) && (await bcrypt.compare(password, user.password || ''))
  if (!ok) throw new HttpError(401, 'Username atau password salah.')
  res.json({ token: signToken(user), user: { id: user.id, username: user.username, nama: user.nama, email: user.email, role: user.role } })
}))

router.get('/me', requireAuth, (req, res) => res.json({ user: req.user }))

router.put('/me', requireAuth, wrap(async (req, res) => {
  const { nama, email, password_lama, password_baru } = req.body || {}
  const patch = { updated_at: new Date().toISOString().slice(0, 19).replace('T', ' ') }
  if (nama !== undefined) {
    if (!String(nama).trim()) throw new HttpError(422, 'Nama wajib diisi.', { nama: 'Nama wajib diisi' })
    patch.nama = String(nama).trim().slice(0, 150)
  }
  if (email !== undefined) patch.email = String(email).trim().toLowerCase().slice(0, 150) || null
  if (password_baru) {
    const user = await db('users').where({ id: req.user.id }).first()
    if (!(await bcrypt.compare(String(password_lama || ''), user.password))) {
      throw new HttpError(422, 'Password lama salah.', { password_lama: 'Password lama salah' })
    }
    if (String(password_baru).length < 8) throw new HttpError(422, 'Password baru minimal 8 karakter.', { password_baru: 'Minimal 8 karakter' })
    patch.password = await bcrypt.hash(String(password_baru), 10)
  }
  await db('users').where({ id: req.user.id }).update(patch)
  const u = await db('users').where({ id: req.user.id }).first()
  res.json({ user: { id: u.id, username: u.username, nama: u.nama, email: u.email, role: u.role } })
}))

export default router
