import dotenv from 'dotenv'
dotenv.config({ quiet: true })
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
export const ROOT = path.resolve(__dirname, '..')

const env = process.env

export const config = {
  env: env.NODE_ENV || 'development',
  isProd: env.NODE_ENV === 'production',
  port: Number(env.PORT || 4000),
  jwtSecret: env.JWT_SECRET || 'ganti-dengan-rahasia-panjang-acak',
  jwtExpires: env.JWT_EXPIRES || '12h',
  corsOrigin: env.CORS_ORIGIN ? env.CORS_ORIGIN.split(',').map((s) => s.trim()) : true,
  uploadDir: path.resolve(ROOT, env.UPLOAD_DIR || 'uploads'),
  maxUploadMb: Number(env.MAX_UPLOAD_MB || 5),
  autoSeed: env.AUTO_SEED !== 'false',
  admin: {
    username: env.ADMIN_USERNAME || 'admin',
    password: env.ADMIN_PASSWORD || 'admin12345',
    nama: env.ADMIN_NAMA || 'Administrator',
  },
  db: {
    client: env.DB_CLIENT || 'sqlite',
    // SQLite
    filename: path.resolve(ROOT, env.DB_FILE || 'database/smk_infokom.sqlite'),
    // MySQL / MariaDB / PostgreSQL
    host: env.DB_HOST || '127.0.0.1',
    port: env.DB_PORT ? Number(env.DB_PORT) : undefined,
    user: env.DB_USER || 'root',
    password: env.DB_PASSWORD || '',
    database: env.DB_NAME || 'smk_infokom',
    url: env.DATABASE_URL || '',
  },
}

if (config.isProd && config.jwtSecret === 'ganti-dengan-rahasia-panjang-acak') {
  console.warn('[PERINGATAN] JWT_SECRET belum diganti. Isi JWT_SECRET di file .env sebelum dipakai publik.')
}
