import jwt from 'jsonwebtoken'
import { config } from '../config.js'
import { db } from '../db/knex.js'

export function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role, username: user.username }, config.jwtSecret, { expiresIn: config.jwtExpires })
}

export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || ''
    const token = header.startsWith('Bearer ') ? header.slice(7) : null
    if (!token) return res.status(401).json({ error: 'Silakan login terlebih dahulu.' })
    const payload = jwt.verify(token, config.jwtSecret)
    const user = await db('users').where({ id: payload.sub }).first()
    if (!user || !(user.aktif === true || user.aktif === 1)) return res.status(401).json({ error: 'Sesi tidak valid. Silakan login ulang.' })
    req.user = { id: user.id, username: user.username, nama: user.nama, email: user.email, role: user.role }
    next()
  } catch {
    res.status(401).json({ error: 'Sesi berakhir. Silakan login ulang.' })
  }
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) return res.status(403).json({ error: 'Anda tidak memiliki akses untuk tindakan ini.' })
    next()
  }
}
