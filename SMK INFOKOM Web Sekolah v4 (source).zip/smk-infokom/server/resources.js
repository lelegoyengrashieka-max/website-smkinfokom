/**
 * DEFINISI RESOURCE — satu sumber kebenaran untuk:
 *   1. Struktur tabel database (dibuat/diperbarui otomatis oleh server/db/sync.js)
 *   2. Validasi input di API (server/lib/validate.js)
 *   3. Form & tabel di panel admin (dikirim ke frontend lewat GET /api/admin/meta)
 *
 * Tipe field yang didukung:
 *   string, text, longtext, email, url, int, bool, date, image, list, slug, select, password
 *
 * Opsi resource:
 *   public        : boolean — boleh dibaca publik lewat /api/public/:resource
 *   publicWhere   : filter tambahan untuk publik, mis. { status: 'terbit' }
 *   canCreate     : admin boleh menambah data (default true)
 *   adminOnly     : hanya role "admin" (bukan editor) yang boleh mengelola
 *   orderBy       : urutan default [[kolom, 'asc'|'desc'], ...]
 *   searchable    : kolom yang dicari oleh parameter ?q=
 *   filters       : kolom yang boleh difilter lewat query string
 *   columns       : kolom yang tampil di tabel admin
 *   titleField    : kolom yang dipakai sebagai judul baris
 *   group         : pengelompokan menu di sidebar admin
 */

export const GALERI_KATEGORI = ['Profil Sekolah', 'OSIS', 'PKL', 'Akademik', 'Industri', 'Ekstrakurikuler', 'Kegiatan']
export const MITRA_JENIS = ['Industri', 'Rekrutmen BKK', 'Mitra Jepang']
export const FAQ_KATEGORI = ['PPDB', 'BKK', 'Magang Jepang', 'Umum']
export const JURUSAN_OPSI = ['RPL', 'TKJ', 'Multimedia', 'PSPT', 'Lainnya']
export const GURU_KATEGORI = ['Kepala Sekolah', 'Wakasek', 'Guru', 'Staf']
export const BERITA_KATEGORI = ['PENGUMUMAN', 'PRESTASI', 'AKADEMIK', 'KEMITRAAN', 'KEGIATAN']

const urutan = { type: 'int', label: 'Urutan', default: 0, help: 'Angka kecil tampil lebih dulu' }
const tampil = { type: 'bool', label: 'Tampilkan di situs', default: true }

/** Field bersama untuk video Instagram (BKK & Magang Jepang). */
const IG_PATTERN = '^https?://(www\\.)?instagram\\.com/(reel|reels|p|tv)/[A-Za-z0-9_-]+'
const videoIgFields = () => ({
  judul: { type: 'string', label: 'Judul Video', required: true, max: 200 },
  url: {
    type: 'url', label: 'Tautan Instagram', required: true, max: 300, pattern: IG_PATTERN,
    patternMsg: 'Tautan harus berupa Reel/Post Instagram, mis. https://www.instagram.com/reel/ABC123/',
    help: 'Buka Reel/Post di Instagram → ⋯ → Salin tautan, lalu tempel di sini. Akun harus publik.',
  },
  keterangan: { type: 'text', label: 'Keterangan Singkat', max: 500 },
  sampul: { type: 'image', label: 'Gambar Sampul (opsional)', help: 'Ditampilkan sebelum video diputar. Kosong = sampul otomatis.' },
  tanggal: { type: 'date', label: 'Tanggal Unggah' },
  tampil,
  urutan,
})
const videoIgResource = (label, group) => ({
  label,
  singular: 'Video',
  group,
  icon: 'video',
  public: true,
  publicWhere: { tampil: true },
  orderBy: [['urutan', 'asc'], ['id', 'desc']],
  searchable: ['judul', 'keterangan'],
  columns: ['sampul', 'judul', 'url', 'tanggal', 'tampil'],
  titleField: 'judul',
  fields: videoIgFields(),
})

export const RESOURCES = {
  berita: {
    label: 'Berita & Pengumuman',
    singular: 'Berita',
    group: 'Konten',
    icon: 'news',
    public: true,
    publicWhere: { status: 'terbit' },
    orderBy: [['tanggal', 'desc'], ['id', 'desc']],
    searchable: ['judul', 'ringkasan'],
    filters: ['kategori', 'status'],
    columns: ['gambar', 'judul', 'kategori', 'tanggal', 'status'],
    titleField: 'judul',
    fields: {
      judul: { type: 'string', label: 'Judul', required: true, max: 200 },
      slug: { type: 'slug', label: 'Slug URL', from: 'judul', help: 'Dikosongkan = dibuat otomatis dari judul' },
      kategori: { type: 'select', label: 'Kategori', options: BERITA_KATEGORI, required: true, default: 'KEGIATAN' },
      tanggal: { type: 'date', label: 'Tanggal', required: true },
      gambar: { type: 'image', label: 'Gambar Utama' },
      ringkasan: { type: 'text', label: 'Ringkasan', max: 500, help: 'Tampil di kartu daftar berita' },
      isi: { type: 'longtext', label: 'Isi Berita', required: true, help: 'Pisahkan paragraf dengan baris kosong' },
      penulis: { type: 'string', label: 'Penulis', max: 100 },
      status: { type: 'select', label: 'Status', options: ['terbit', 'draft'], default: 'terbit' },
    },
  },

  agenda: {
    label: 'Agenda & Kalender',
    singular: 'Agenda',
    group: 'Konten',
    icon: 'calendar',
    public: true,
    orderBy: [['tanggal', 'asc'], ['id', 'asc']],
    searchable: ['kegiatan', 'lokasi'],
    columns: ['tanggal', 'periode', 'kegiatan', 'lokasi'],
    titleField: 'kegiatan',
    fields: {
      kegiatan: { type: 'string', label: 'Nama Kegiatan', required: true, max: 250 },
      tanggal: { type: 'date', label: 'Tanggal Mulai', required: true },
      tanggal_selesai: { type: 'date', label: 'Tanggal Selesai' },
      periode: { type: 'string', label: 'Label Periode', max: 60, help: 'Opsional, mis. "Juli 2026". Kosong = pakai tanggal' },
      lokasi: { type: 'string', label: 'Lokasi', max: 150 },
      keterangan: { type: 'text', label: 'Keterangan' },
    },
  },

  galeri: {
    label: 'Galeri Foto',
    singular: 'Foto',
    group: 'Konten',
    icon: 'image',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'desc']],
    searchable: ['judul'],
    filters: ['kategori'],
    columns: ['gambar', 'judul', 'kategori', 'tanggal'],
    titleField: 'judul',
    fields: {
      judul: { type: 'string', label: 'Judul / Keterangan', required: true, max: 200 },
      kategori: { type: 'select', label: 'Kategori', options: GALERI_KATEGORI, required: true, default: 'Kegiatan' },
      gambar: { type: 'image', label: 'Foto', required: true },
      tanggal: { type: 'date', label: 'Tanggal Kegiatan' },
      urutan,
    },
  },

  prestasi: {
    label: 'Prestasi',
    singular: 'Prestasi',
    group: 'Konten',
    icon: 'trophy',
    public: true,
    orderBy: [['tahun', 'desc'], ['urutan', 'asc'], ['id', 'desc']],
    searchable: ['judul', 'peraih'],
    columns: ['tahun', 'judul', 'tingkat', 'peraih'],
    titleField: 'judul',
    fields: {
      judul: { type: 'string', label: 'Nama Prestasi', required: true, max: 250 },
      tahun: { type: 'string', label: 'Tahun', required: true, max: 4 },
      tingkat: { type: 'select', label: 'Tingkat', options: ['Sekolah', 'Kota', 'Provinsi', 'Nasional', 'Internasional'], default: 'Provinsi' },
      peraih: { type: 'string', label: 'Peraih', max: 200 },
      gambar: { type: 'image', label: 'Foto' },
      keterangan: { type: 'text', label: 'Keterangan' },
      urutan,
    },
  },

  ekskul: {
    label: 'Ekstrakurikuler',
    singular: 'Ekstrakurikuler',
    group: 'Kesiswaan',
    icon: 'star',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['nama'],
    columns: ['gambar', 'nama', 'jadwal', 'pembina'],
    titleField: 'nama',
    fields: {
      nama: { type: 'string', label: 'Nama Ekskul', required: true, max: 150 },
      jadwal: { type: 'string', label: 'Jadwal', max: 150 },
      pembina: { type: 'string', label: 'Pembina', max: 150 },
      deskripsi: { type: 'text', label: 'Deskripsi' },
      gambar: { type: 'image', label: 'Foto' },
      urutan,
    },
  },

  testimoni: {
    label: 'Testimoni Alumni',
    singular: 'Testimoni',
    group: 'Kesiswaan',
    icon: 'quote',
    public: true,
    publicWhere: { tampil: true },
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['nama', 'kutipan'],
    columns: ['foto', 'nama', 'peran', 'tampil'],
    titleField: 'nama',
    fields: {
      nama: { type: 'string', label: 'Nama', required: true, max: 150 },
      peran: { type: 'string', label: 'Angkatan / Pekerjaan', max: 200 },
      kutipan: { type: 'text', label: 'Kutipan', required: true },
      foto: { type: 'image', label: 'Foto' },
      tampil,
      urutan,
    },
  },

  jurusan: {
    label: 'Program Keahlian',
    singular: 'Jurusan',
    group: 'Akademik',
    icon: 'cap',
    public: true,
    publicWhere: { aktif: true },
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['nama', 'kode'],
    columns: ['gambar', 'kode', 'nama', 'aktif'],
    titleField: 'nama',
    fields: {
      nama: { type: 'string', label: 'Nama Jurusan', required: true, max: 150 },
      kode: { type: 'string', label: 'Kode Singkat', required: true, max: 10, help: 'Mis. RPL, TKJ' },
      slug: { type: 'slug', label: 'Slug URL', from: 'kode' },
      tagline: { type: 'string', label: 'Tagline', max: 250 },
      deskripsi: { type: 'text', label: 'Deskripsi Singkat' },
      gambar: { type: 'image', label: 'Gambar' },
      skills: { type: 'list', label: 'Keahlian Unggulan (tag)' },
      kompetensi: { type: 'list', label: 'Kompetensi Utama' },
      mapel_x: { type: 'list', label: 'Mata Pelajaran Kelas X' },
      mapel_xi: { type: 'list', label: 'Mata Pelajaran Kelas XI' },
      mapel_xii: { type: 'list', label: 'Mata Pelajaran Kelas XII' },
      karir: { type: 'list', label: 'Prospek Karier' },
      mitra: { type: 'list', label: 'Mitra Industri' },
      aktif: { type: 'bool', label: 'Aktif / Menerima Siswa', default: true },
      urutan,
    },
  },

  guru: {
    label: 'Guru & Staf',
    singular: 'Guru',
    group: 'Akademik',
    icon: 'user',
    public: true,
    publicWhere: { tampil: true },
    publicHidden: ['nip', 'email', 'telepon'],
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['nama', 'jabatan', 'bidang', 'nip'],
    filters: ['kategori'],
    columns: ['foto', 'nama', 'kategori', 'jabatan', 'bidang', 'tampil'],
    titleField: 'nama',
    fields: {
      nama: { type: 'string', label: 'Nama Lengkap & Gelar', required: true, max: 150 },
      kategori: { type: 'select', label: 'Kelompok', options: GURU_KATEGORI, required: true, default: 'Guru', help: 'Menentukan di bagian mana foto tampil: Kepala Sekolah, Wakasek, Guru, atau Staf (tenaga kependidikan)' },
      nip: { type: 'string', label: 'NIP / NUPTK', max: 30 },
      jabatan: { type: 'string', label: 'Jabatan', required: true, max: 150 },
      bidang: { type: 'string', label: 'Bidang / Mata Pelajaran', max: 150 },
      foto: { type: 'image', label: 'Foto' },
      email: { type: 'email', label: 'Email', max: 150 },
      telepon: { type: 'string', label: 'Telepon', max: 30 },
      tampil,
      urutan,
    },
  },

  struktur: {
    label: 'Struktur Organisasi',
    singular: 'Jabatan',
    group: 'Akademik',
    icon: 'tree',
    public: true,
    orderBy: [['level', 'asc'], ['urutan', 'asc'], ['id', 'asc']],
    searchable: ['nama', 'jabatan'],
    columns: ['level', 'nama', 'jabatan'],
    titleField: 'jabatan',
    fields: {
      jabatan: { type: 'string', label: 'Jabatan', required: true, max: 150 },
      nama: { type: 'string', label: 'Nama Pejabat', required: true, max: 150 },
      level: { type: 'select', label: 'Tingkat Bagan', options: ['1', '2', '3', '4'], default: '2', help: '1 = Kepala Sekolah, 2 = Wakil Kepala, 3 = Kepala Program/Unit, 4 = Staf' },
      urutan,
    },
  },

  fasilitas: {
    label: 'Sarana & Prasarana',
    singular: 'Fasilitas',
    group: 'Akademik',
    icon: 'building',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['ruang'],
    columns: ['gambar', 'ruang', 'unit', 'kapasitas'],
    titleField: 'ruang',
    fields: {
      ruang: { type: 'string', label: 'Nama Ruang / Fasilitas', required: true, max: 150 },
      unit: { type: 'string', label: 'Jumlah Unit', max: 50 },
      kapasitas: { type: 'string', label: 'Kapasitas', max: 50 },
      deskripsi: { type: 'text', label: 'Deskripsi' },
      gambar: { type: 'image', label: 'Foto' },
      urutan,
    },
  },

  sejarah: {
    label: 'Sejarah (Timeline)',
    singular: 'Peristiwa',
    group: 'Akademik',
    icon: 'clock',
    public: true,
    orderBy: [['tahun', 'asc'], ['id', 'asc']],
    searchable: ['teks'],
    columns: ['tahun', 'teks'],
    titleField: 'tahun',
    fields: {
      tahun: { type: 'string', label: 'Tahun', required: true, max: 10 },
      teks: { type: 'text', label: 'Peristiwa', required: true },
    },
  },

  mitra: {
    label: 'Mitra Industri',
    singular: 'Mitra',
    group: 'Akademik',
    icon: 'handshake',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['nama', 'bidang'],
    filters: ['jenis'],
    columns: ['logo', 'nama', 'jenis', 'bidang'],
    titleField: 'nama',
    fields: {
      nama: { type: 'string', label: 'Nama Perusahaan', required: true, max: 150 },
      jenis: { type: 'select', label: 'Jenis Mitra', options: MITRA_JENIS, default: 'Industri' },
      bidang: { type: 'string', label: 'Bentuk Kerja Sama', max: 250 },
      logo: { type: 'image', label: 'Logo' },
      website: { type: 'url', label: 'Website', max: 250 },
      urutan,
    },
  },

  pendaftar: {
    label: 'Pendaftar PPDB',
    singular: 'Pendaftar',
    group: 'PPDB',
    icon: 'clipboard',
    public: false,
    orderBy: [['id', 'desc']],
    searchable: ['nomor', 'nama', 'nisn', 'asal_sekolah', 'telepon'],
    filters: ['status', 'jurusan_1'],
    columns: ['nomor', 'nama', 'asal_sekolah', 'jurusan_1', 'status', 'created_at'],
    titleField: 'nama',
    exportable: true,
    fields: {
      nomor: { type: 'string', label: 'No. Pendaftaran', max: 30, readonly: true },
      nama: { type: 'string', label: 'Nama Lengkap', required: true, max: 150 },
      nisn: { type: 'string', label: 'NISN', required: true, max: 20 },
      jenis_kelamin: { type: 'select', label: 'Jenis Kelamin', options: ['L', 'P'], required: true },
      tempat_lahir: { type: 'string', label: 'Tempat Lahir', required: true, max: 100 },
      tanggal_lahir: { type: 'date', label: 'Tanggal Lahir', required: true },
      agama: { type: 'select', label: 'Agama', options: ['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Konghucu'] },
      asal_sekolah: { type: 'string', label: 'Asal Sekolah', required: true, max: 150 },
      jurusan_1: { type: 'string', label: 'Pilihan Jurusan 1', required: true, max: 20 },
      jurusan_2: { type: 'string', label: 'Pilihan Jurusan 2', max: 20 },
      nama_ortu: { type: 'string', label: 'Nama Orang Tua / Wali', required: true, max: 150 },
      telepon: { type: 'string', label: 'No. HP / WhatsApp', required: true, max: 20 },
      email: { type: 'email', label: 'Email', max: 150 },
      alamat: { type: 'text', label: 'Alamat Lengkap', required: true },
      status: { type: 'select', label: 'Status', options: ['baru', 'diverifikasi', 'diterima', 'cadangan', 'ditolak'], default: 'baru' },
      catatan_admin: { type: 'text', label: 'Catatan Panitia', help: 'Ditampilkan ke pendaftar saat cek status' },
    },
  },

  biaya: {
    label: 'Rincian Biaya',
    singular: 'Biaya',
    group: 'PPDB',
    icon: 'money',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['item'],
    columns: ['item', 'nominal', 'keterangan'],
    titleField: 'item',
    fields: {
      item: { type: 'string', label: 'Komponen Biaya', required: true, max: 150 },
      nominal: { type: 'string', label: 'Nominal', required: true, max: 50, help: 'Mis. Rp 150.000' },
      keterangan: { type: 'string', label: 'Keterangan', max: 250 },
      urutan,
    },
  },

  tahapan: {
    label: 'Jadwal Tahapan PPDB',
    singular: 'Tahapan',
    group: 'PPDB',
    icon: 'steps',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    columns: ['urutan', 'label', 'waktu'],
    titleField: 'label',
    fields: {
      label: { type: 'string', label: 'Tahapan', required: true, max: 150 },
      waktu: { type: 'string', label: 'Waktu', required: true, max: 100 },
      urutan,
    },
  },

  faq: {
    label: 'FAQ',
    singular: 'FAQ',
    group: 'PPDB',
    icon: 'help',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['pertanyaan', 'jawaban'],
    filters: ['kategori'],
    columns: ['pertanyaan', 'kategori', 'urutan'],
    titleField: 'pertanyaan',
    fields: {
      kategori: { type: 'select', label: 'Kategori', options: FAQ_KATEGORI, default: 'PPDB' },
      pertanyaan: { type: 'string', label: 'Pertanyaan', required: true, max: 300 },
      jawaban: { type: 'text', label: 'Jawaban', required: true },
      urutan,
    },
  },

  /* ================= BKK ================= */
  lowongan: {
    label: 'Lowongan Kerja',
    singular: 'Lowongan',
    group: 'BKK',
    icon: 'briefcase',
    public: true,
    orderBy: [['status', 'asc'], ['tanggal', 'desc'], ['id', 'desc']],
    searchable: ['judul', 'perusahaan', 'lokasi', 'bidang'],
    filters: ['tipe', 'bidang', 'status'],
    columns: ['logo', 'judul', 'perusahaan', 'tipe', 'deadline', 'status'],
    titleField: 'judul',
    fields: {
      judul: { type: 'string', label: 'Posisi', required: true, max: 200 },
      slug: { type: 'slug', label: 'Slug URL', from: 'judul' },
      perusahaan: { type: 'string', label: 'Perusahaan', required: true, max: 150 },
      logo: { type: 'image', label: 'Logo Perusahaan' },
      lokasi: { type: 'string', label: 'Lokasi', max: 150 },
      tipe: { type: 'select', label: 'Tipe Pekerjaan', options: ['Penuh Waktu', 'Kontrak', 'Magang', 'Paruh Waktu'], default: 'Penuh Waktu' },
      bidang: { type: 'select', label: 'Bidang', options: ['Perangkat Lunak', 'Jaringan & IT Support', 'Multimedia & Desain', 'Broadcasting', 'Administrasi', 'Lainnya'], default: 'Perangkat Lunak' },
      gaji: { type: 'string', label: 'Kisaran Gaji', max: 100, help: 'Mis. Rp 4,5 – 5,5 juta' },
      kuota: { type: 'int', label: 'Kuota', default: 1 },
      tanggal: { type: 'date', label: 'Tanggal Tayang' },
      deadline: { type: 'date', label: 'Batas Lamaran' },
      deskripsi: { type: 'longtext', label: 'Deskripsi Pekerjaan', help: 'Pisahkan paragraf dengan baris kosong' },
      kualifikasi: { type: 'list', label: 'Kualifikasi' },
      benefit: { type: 'list', label: 'Benefit' },
      cara_melamar: { type: 'text', label: 'Catatan Cara Melamar' },
      status: { type: 'select', label: 'Status', options: ['dibuka', 'ditutup'], default: 'dibuka' },
    },
  },

  lamaran: {
    label: 'Lamaran Masuk',
    singular: 'Lamaran',
    group: 'BKK',
    icon: 'mail',
    public: false,
    orderBy: [['id', 'desc']],
    searchable: ['nama', 'email', 'telepon', 'lowongan_judul'],
    filters: ['status', 'jurusan'],
    columns: ['nama', 'lowongan_judul', 'jurusan', 'tahun_lulus', 'status', 'created_at'],
    titleField: 'nama',
    exportable: true,
    fields: {
      lowongan_id: { type: 'int', label: 'ID Lowongan', default: 0 },
      lowongan_judul: { type: 'string', label: 'Lowongan', max: 300 },
      nama: { type: 'string', label: 'Nama Lengkap', required: true, max: 150 },
      email: { type: 'email', label: 'Email', required: true, max: 150 },
      telepon: { type: 'string', label: 'No. HP / WhatsApp', required: true, max: 20 },
      jurusan: { type: 'select', label: 'Jurusan', options: JURUSAN_OPSI, required: true },
      tahun_lulus: { type: 'string', label: 'Tahun Lulus', required: true, max: 4 },
      alamat: { type: 'text', label: 'Domisili' },
      link_cv: { type: 'url', label: 'Tautan CV / Portofolio', required: true, help: 'Google Drive, LinkedIn, dsb.' },
      pesan: { type: 'text', label: 'Pesan Singkat', max: 2000 },
      status: { type: 'select', label: 'Status', options: ['baru', 'diproses', 'wawancara', 'diterima', 'ditolak'], default: 'baru' },
    },
  },

  video_bkk: videoIgResource('Video Instagram BKK', 'BKK'),

  alumni: {
    label: 'Tracer Study Alumni',
    singular: 'Alumni',
    group: 'BKK',
    icon: 'user',
    public: false,
    orderBy: [['id', 'desc']],
    searchable: ['nama', 'instansi', 'telepon'],
    filters: ['status_kini', 'jurusan', 'tahun_lulus'],
    columns: ['nama', 'jurusan', 'tahun_lulus', 'status_kini', 'instansi', 'created_at'],
    titleField: 'nama',
    exportable: true,
    fields: {
      nama: { type: 'string', label: 'Nama Lengkap', required: true, max: 150 },
      jurusan: { type: 'select', label: 'Jurusan', options: JURUSAN_OPSI, required: true },
      tahun_lulus: { type: 'string', label: 'Tahun Lulus', required: true, max: 4 },
      telepon: { type: 'string', label: 'No. HP / WhatsApp', required: true, max: 20 },
      email: { type: 'email', label: 'Email', max: 150 },
      status_kini: { type: 'select', label: 'Status Saat Ini', options: ['Bekerja', 'Kuliah', 'Wirausaha', 'Kuliah & Bekerja', 'Magang Luar Negeri', 'Mencari Kerja'], required: true },
      instansi: { type: 'string', label: 'Nama Instansi / Kampus / Usaha', max: 200 },
      jabatan: { type: 'string', label: 'Jabatan / Program Studi', max: 150 },
      kesesuaian: { type: 'select', label: 'Kesesuaian dengan Jurusan', options: ['Sangat sesuai', 'Sesuai', 'Kurang sesuai', 'Tidak sesuai'] },
      pendapatan: { type: 'select', label: 'Pendapatan per Bulan', options: ['< Rp 3 juta', 'Rp 3 – 5 juta', 'Rp 5 – 8 juta', '> Rp 8 juta', 'Belum berpenghasilan'] },
      saran: { type: 'text', label: 'Saran untuk Sekolah', max: 2000 },
    },
  },

  /* ================= MAGANG JEPANG ================= */
  magang_bidang: {
    label: 'Bidang Kerja Jepang',
    singular: 'Bidang',
    group: 'Magang Jepang',
    icon: 'plane',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['nama'],
    columns: ['gambar', 'nama', 'istilah_jp', 'durasi', 'gaji'],
    titleField: 'nama',
    fields: {
      nama: { type: 'string', label: 'Nama Bidang', required: true, max: 150 },
      istilah_jp: { type: 'string', label: 'Istilah Jepang', max: 100 },
      deskripsi: { type: 'text', label: 'Deskripsi' },
      durasi: { type: 'string', label: 'Durasi Kontrak', max: 100 },
      gaji: { type: 'string', label: 'Perkiraan Gaji', max: 100 },
      syarat: { type: 'list', label: 'Syarat Khusus' },
      gambar: { type: 'image', label: 'Foto' },
      urutan,
    },
  },

  magang_alumni: {
    label: 'Alumni di Jepang',
    singular: 'Alumni Jepang',
    group: 'Magang Jepang',
    icon: 'quote',
    public: true,
    publicWhere: { tampil: true },
    orderBy: [['urutan', 'asc'], ['id', 'asc']],
    searchable: ['nama', 'perusahaan'],
    columns: ['foto', 'nama', 'angkatan', 'prefektur', 'bidang', 'tampil'],
    titleField: 'nama',
    fields: {
      nama: { type: 'string', label: 'Nama', required: true, max: 150 },
      angkatan: { type: 'string', label: 'Angkatan Berangkat', max: 20 },
      jurusan: { type: 'string', label: 'Jurusan Asal', max: 50 },
      perusahaan: { type: 'string', label: 'Perusahaan', max: 150 },
      prefektur: { type: 'string', label: 'Prefektur / Kota', max: 100 },
      bidang: { type: 'string', label: 'Bidang Kerja', max: 100 },
      foto: { type: 'image', label: 'Foto' },
      kutipan: { type: 'text', label: 'Kutipan / Cerita' },
      tampil,
      urutan,
    },
  },

  video_magang: videoIgResource('Video Instagram Magang', 'Magang Jepang'),

  pendaftar_magang: {
    label: 'Pendaftar Magang Jepang',
    singular: 'Pendaftar',
    group: 'Magang Jepang',
    icon: 'clipboard',
    public: false,
    orderBy: [['id', 'desc']],
    searchable: ['nomor', 'nama', 'telepon', 'email'],
    filters: ['status', 'bidang_minat', 'status_peserta'],
    columns: ['nomor', 'nama', 'status_peserta', 'bidang_minat', 'level_bahasa', 'status', 'created_at'],
    titleField: 'nama',
    exportable: true,
    fields: {
      nomor: { type: 'string', label: 'No. Pendaftaran', max: 30, readonly: true },
      nama: { type: 'string', label: 'Nama Lengkap', required: true, max: 150 },
      jenis_kelamin: { type: 'select', label: 'Jenis Kelamin', options: ['L', 'P'], required: true },
      tanggal_lahir: { type: 'date', label: 'Tanggal Lahir', required: true },
      tinggi_badan: { type: 'int', label: 'Tinggi Badan (cm)', default: 0 },
      berat_badan: { type: 'int', label: 'Berat Badan (kg)', default: 0 },
      status_peserta: { type: 'select', label: 'Status Peserta', options: ['Siswa kelas XII', 'Alumni'], required: true },
      jurusan: { type: 'select', label: 'Jurusan', options: JURUSAN_OPSI, required: true },
      tahun_lulus: { type: 'string', label: 'Tahun Lulus', max: 4 },
      telepon: { type: 'string', label: 'No. HP / WhatsApp', required: true, max: 20 },
      email: { type: 'email', label: 'Email', max: 150 },
      alamat: { type: 'text', label: 'Alamat Lengkap', required: true },
      bidang_minat: { type: 'string', label: 'Bidang Minat', required: true, max: 150 },
      level_bahasa: { type: 'select', label: 'Kemampuan Bahasa Jepang', options: ['Belum pernah belajar', 'Dasar (kana)', 'Setara N5', 'Setara N4', 'N3 ke atas'], default: 'Belum pernah belajar' },
      kesehatan: { type: 'select', label: 'Riwayat Kesehatan', options: ['Sehat, tidak ada riwayat penyakit', 'Memakai kacamata', 'Ada riwayat penyakit (jelaskan di motivasi)'], default: 'Sehat, tidak ada riwayat penyakit' },
      motivasi: { type: 'text', label: 'Motivasi', required: true, max: 3000 },
      status: { type: 'select', label: 'Status Seleksi', options: ['baru', 'seleksi administrasi', 'tes tertulis', 'wawancara', 'pelatihan', 'lolos', 'berangkat', 'tidak lolos'], default: 'baru' },
      catatan_admin: { type: 'text', label: 'Catatan Panitia', help: 'Ditampilkan ke pendaftar saat cek status' },
    },
  },

  unduhan: {
    label: 'Pusat Unduhan',
    singular: 'Dokumen',
    group: 'Konten',
    icon: 'file',
    public: true,
    orderBy: [['urutan', 'asc'], ['id', 'desc']],
    searchable: ['judul', 'keterangan'],
    filters: ['kategori'],
    columns: ['judul', 'kategori', 'urutan'],
    titleField: 'judul',
    fields: {
      judul: { type: 'string', label: 'Judul Dokumen', required: true, max: 200 },
      kategori: { type: 'select', label: 'Kategori', options: ['PPDB', 'Akademik', 'BKK', 'Magang Jepang', 'Umum'], default: 'Umum' },
      file: { type: 'url', label: 'Tautan File', required: true, help: 'Tautan Google Drive / file PDF' },
      keterangan: { type: 'string', label: 'Keterangan', max: 250 },
      urutan,
    },
  },

  pesan: {
    label: 'Pesan Masuk',
    singular: 'Pesan',
    group: 'Interaksi',
    icon: 'mail',
    public: false,
    canCreate: false,
    orderBy: [['id', 'desc']],
    searchable: ['nama', 'email', 'subjek', 'pesan'],
    filters: ['dibaca'],
    columns: ['nama', 'email', 'subjek', 'dibaca', 'created_at'],
    titleField: 'subjek',
    exportable: true,
    fields: {
      nama: { type: 'string', label: 'Nama', required: true, max: 150 },
      email: { type: 'email', label: 'Email', required: true, max: 150 },
      telepon: { type: 'string', label: 'Telepon', max: 30 },
      subjek: { type: 'string', label: 'Subjek', max: 200 },
      pesan: { type: 'text', label: 'Pesan', required: true, max: 5000 },
      dibaca: { type: 'bool', label: 'Sudah dibaca', default: false },
    },
  },

  users: {
    label: 'Pengguna Admin',
    singular: 'Pengguna',
    group: 'Sistem',
    icon: 'shield',
    public: false,
    adminOnly: true,
    orderBy: [['id', 'asc']],
    searchable: ['username', 'nama', 'email'],
    columns: ['username', 'nama', 'role', 'aktif'],
    titleField: 'username',
    hidden: ['password'],
    fields: {
      username: { type: 'string', label: 'Username', required: true, max: 50, unique: true, pattern: '^[a-zA-Z0-9_.]{3,50}$' },
      nama: { type: 'string', label: 'Nama Lengkap', required: true, max: 150 },
      email: { type: 'email', label: 'Email', max: 150 },
      password: { type: 'password', label: 'Password', help: 'Minimal 8 karakter. Kosongkan saat edit bila tidak diganti' },
      role: { type: 'select', label: 'Peran', options: ['admin', 'editor'], default: 'editor', help: 'Admin: akses penuh. Editor: kelola konten saja' },
      aktif: { type: 'bool', label: 'Akun aktif', default: true },
    },
  },
}

/** Tipe kolom database untuk setiap tipe field. */
export function columnFor(table, name, field) {
  switch (field.type) {
    case 'int':
      return table.integer(name).defaultTo(field.default ?? 0)
    case 'bool':
      return table.boolean(name).defaultTo(field.default ?? false)
    case 'date':
      return table.date(name).nullable()
    case 'text':
    case 'list':
      return table.text(name).nullable()
    case 'longtext':
      return table.text(name, 'longtext').nullable()
    case 'image':
    case 'url':
      return table.string(name, 500).nullable()
    case 'password':
      return table.string(name, 255).nullable()
    default:
      return table.string(name, field.max && field.max > 255 ? 500 : 255).nullable()
  }
}
