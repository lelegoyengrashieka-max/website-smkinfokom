export const FASILITAS = [
  { ruang: 'Lab. Rekayasa Perangkat Lunak', unit: '3 ruang', kapasitas: '108 siswa' },
  { ruang: 'Lab. Jaringan & Server', unit: '2 ruang', kapasitas: '72 siswa' },
  { ruang: 'Studio Multimedia', unit: '2 ruang', kapasitas: '64 siswa' },
  { ruang: 'Ruang Server & Data Center Mini', unit: '1 ruang', kapasitas: '—' },
  { ruang: 'Perpustakaan Digital', unit: '1 ruang', kapasitas: '80 siswa' },
  { ruang: 'Aula & Ruang Serbaguna', unit: '1 ruang', kapasitas: '400 orang' },
]

export const SOSMED = [
  { nama: 'Facebook', url: 'https://facebook.com', icon: 'facebook' },
  { nama: 'Instagram', url: 'https://instagram.com', icon: 'instagram' },
  { nama: 'YouTube', url: 'https://youtube.com', icon: 'youtube' },
]

export const KALENDER = [
  { periode: 'Juli 2026', kegiatan: 'Awal tahun ajaran baru & Masa Pengenalan Lingkungan Sekolah' },
  { periode: 'Agustus 2026', kegiatan: 'Upacara HUT Kemerdekaan RI & lomba internal' },
  { periode: 'September 2026', kegiatan: 'Penilaian Tengah Semester Ganjil' },
  { periode: 'Desember 2026', kegiatan: 'Penilaian Akhir Semester Ganjil & pembagian rapor' },
  { periode: 'Maret 2027', kegiatan: 'Ujian Sekolah & Uji Kompetensi Keahlian kelas XII' },
  { periode: 'Juni 2027', kegiatan: 'Penilaian Akhir Semester Genap & kenaikan kelas' },
]

export const AKADEMIK = [
  'Kurikulum Merdeka dengan penguatan proyek profil pelajar Pancasila',
  'Jam pelajaran produktif minimal 18 jam per minggu di setiap program keahlian',
  'Evaluasi capaian kompetensi setiap akhir semester bersama guru produktif',
  'Kelas industri dengan silabus yang disusun bersama mitra perusahaan',
]

export const NON_AKADEMIK = [
  'Pembinaan karakter lewat kegiatan kepramukaan wajib kelas X',
  'Program literasi digital dan numerasi setiap pagi sebelum jam pertama',
  'Layanan bimbingan konseling untuk perkembangan pribadi dan karier siswa',
  'Kegiatan keagamaan rutin sesuai keyakinan masing-masing siswa',
]

export const TATA_TERTIB = [
  'Hadir di sekolah paling lambat 06.45 WIB dan mengenakan seragam sesuai jadwal',
  'Menjaga sikap sopan santun kepada guru, staf, dan sesama siswa',
  'Menonaktifkan perangkat elektronik pribadi selama jam pelajaran berlangsung',
  'Mengikuti seluruh kegiatan akademik dan non-akademik yang diwajibkan sekolah',
  'Menjaga kebersihan dan fasilitas sekolah sebagai tanggung jawab bersama',
]

export const BKK = {
  desc: 'Bursa Kerja Khusus (BKK) SMK INFOKOM menjembatani lulusan dengan dunia kerja melalui penyaluran kerja, pelatihan kesiapan karier, dan pameran kerja rutin.',
  stats: [
    { label: 'Keterserapan Lulusan', value: '92%' },
    { label: 'Mitra Penyalur Kerja', value: '65+' },
    { label: 'Job Fair per Tahun', value: '2x' },
  ],
}

export const PKL_INFO = {
  desc: 'Praktik Kerja Lapangan (PKL) berlangsung minimal enam bulan pada kelas XI, ditempatkan di perusahaan mitra sesuai kompetensi keahlian masing-masing siswa.',
  tahapan: [
    'Pembekalan PKL dan pemetaan minat siswa',
    'Penempatan ke perusahaan mitra sesuai kompetensi',
    'Pelaksanaan PKL dengan bimbingan guru dan mentor industri',
    'Presentasi laporan akhir dan penilaian bersama',
  ],
}

export const KEMITRAAN = [
  'Kolaborasi Digital — kelas industri Rekayasa Perangkat Lunak',
  'SecureNet Indonesia — kelas industri Teknik Komputer & Jaringan',
  'Studio Rekakarya — magang dan kelas industri Multimedia',
  'Studio Siaran Nusantara — magang produksi program televisi',
  'Nusantara Software House — penyaluran kerja lulusan RPL',
]

export const TRACER_STUDY = {
  desc: 'Tracer Study dilakukan setiap tahun untuk memantau keterserapan dan kesesuaian bidang kerja alumni dengan program keahlian yang ditempuh.',
  stats: [
    { label: 'Bekerja sesuai bidang', value: '78%' },
    { label: 'Melanjutkan kuliah', value: '15%' },
    { label: 'Wirausaha', value: '7%' },
  ],
}

export const MANAJEMEN_MUTU = {
  desc: 'SMK INFOKOM menerapkan sistem manajemen mutu untuk memastikan proses belajar-mengajar, sarana prasarana, dan layanan sekolah terus terukur dan ditingkatkan setiap tahun.',
  poin: [
    'Audit mutu internal setiap semester oleh tim penjaminan mutu sekolah',
    'Survei kepuasan siswa, orang tua, dan mitra industri secara berkala',
    'Tinjauan kurikulum tahunan berdasarkan umpan balik dunia kerja',
    'Sasaran mutu terukur untuk setiap program keahlian',
  ],
}

export const SAMBUTAN_KEPSEK = [
  'Selamat datang di website resmi SMK INFOKOM. Di era digital seperti sekarang, website sekolah menjadi pintu gerbang informasi mengenai perkembangan dan pencapaian sekolah kepada siswa, orang tua, dan masyarakat luas.',
  'Kami membangun setiap program keahlian bersama mitra industri, agar apa yang dipelajari siswa di kelas benar-benar relevan dengan kebutuhan dunia kerja saat mereka lulus nanti.',
  'Kami juga berharap website ini menjadi ruang komunikasi antara sekolah dengan para alumni di berbagai tempat, sebagai keluarga besar yang terus bertumbuh bersama.',
  'Terima kasih atas kepercayaan yang diberikan kepada SMK INFOKOM. Mari terus berkarya menuju sekolah kejuruan yang unggul dan berdaya saing.',
]

export const PROGRAMS = [
  {
    slug: 'rpl',
    code: 'RPL',
    name: 'Rekayasa Perangkat Lunak',
    tagline: 'Dari rancangan sistem sampai aplikasi siap pakai.',
    desc: 'Membangun aplikasi web dan mobile dari nol — mulai basis data, back-end, hingga antarmuka pengguna.',
    skills: ['Pemrograman Web', 'Basis Data', 'Mobile Development'],
    kompetensi: [
      'Pemrograman dasar (algoritma, struktur data, Python/Java)',
      'Pengembangan web front-end dan back-end',
      'Perancangan dan pengelolaan basis data relasional',
      'Pengembangan aplikasi mobile dengan Flutter/Kotlin',
      'Praktik kerja tim dengan metodologi Agile & version control',
    ],
    mapel: {
      X: ['Dasar Pemrograman', 'Perakitan Komputer', 'Sistem Operasi', 'Logika & Algoritma'],
      XI: ['Pemrograman Web Lanjut', 'Basis Data', 'Pemrograman Berorientasi Objek', 'UI/UX Dasar'],
      XII: ['Pengembangan Aplikasi Mobile', 'Proyek Perangkat Lunak', 'Praktik Kerja Industri', 'Uji Kompetensi Keahlian'],
    },
    karir: ['Junior Web Developer', 'Mobile App Developer', 'Quality Assurance', 'Technopreneur'],
    mitra: ['Kolaborasi Digital', 'Nusantara Software House', 'Codeversity Indonesia'],
  },
  {
    slug: 'tkj',
    code: 'TKJ',
    name: 'Teknik Komputer & Jaringan',
    tagline: 'Menghubungkan setiap titik, mengamankan setiap jalur.',
    desc: 'Merancang, memasang, dan mengelola infrastruktur jaringan — dari LAN kantor hingga server cloud.',
    skills: ['Administrasi Jaringan', 'Keamanan Siber', 'Cloud Computing'],
    kompetensi: [
      'Perakitan dan konfigurasi perangkat jaringan (router, switch)',
      'Administrasi server Linux dan Windows Server',
      'Dasar keamanan siber dan pengujian kerentanan jaringan',
      'Konfigurasi layanan cloud computing skala kecil-menengah',
      'Pemeliharaan dan troubleshooting infrastruktur IT',
    ],
    mapel: {
      X: ['Dasar Jaringan Komputer', 'Perakitan Komputer', 'Sistem Operasi Jaringan', 'K3 Perkantoran'],
      XI: ['Administrasi Infrastruktur Jaringan', 'Teknologi WAN', 'Keamanan Jaringan', 'Server Linux'],
      XII: ['Cloud Computing Dasar', 'Proyek Infrastruktur Jaringan', 'Praktik Kerja Industri', 'Uji Kompetensi Keahlian'],
    },
    karir: ['Network Administrator', 'IT Support Specialist', 'Junior Cyber Security Analyst', 'Data Center Technician'],
    mitra: ['Nettra Infrastruktur', 'SecureNet Indonesia', 'CloudBase Systems'],
  },
  {
    slug: 'multimedia',
    code: 'MM',
    name: 'Multimedia',
    tagline: 'Mengubah ide menjadi visual yang bicara.',
    desc: 'Produksi konten visual: motion graphic, videografi, dan desain digital untuk kebutuhan industri kreatif.',
    skills: ['Motion Graphic', 'Videografi', 'UI/UX Design'],
    kompetensi: [
      'Fotografi dan videografi produksi konten digital',
      'Desain grafis dan tipografi untuk media cetak & digital',
      'Motion graphic dan animasi 2D dasar',
      'Prinsip dasar UI/UX untuk aplikasi dan situs web',
      'Manajemen proyek kreatif dan presentasi klien',
    ],
    mapel: {
      X: ['Dasar Desain Grafis', 'Fotografi Dasar', 'Simulasi & Komunikasi Digital', 'Animasi 2D Dasar'],
      XI: ['Videografi & Editing', 'Motion Graphic', 'Desain UI/UX', 'Produksi Multimedia Interaktif'],
      XII: ['Animasi 3D Dasar', 'Proyek Kreatif Industri', 'Praktik Kerja Industri', 'Uji Kompetensi Keahlian'],
    },
    karir: ['Graphic Designer', 'Video Editor', 'UI/UX Designer Pemula', 'Content Creator'],
    mitra: ['Studio Rekakarya', 'Visualindo Kreatif', 'Framewerk Studio'],
  },
  {
    slug: 'pspt',
    code: 'PSPT',
    name: 'Produksi & Siaran Program Televisi',
    tagline: 'Dari naskah ke layar — belajar bertutur lewat gambar bergerak.',
    desc: 'Memproduksi program televisi dari perencanaan naskah, pengambilan gambar, penyutradaraan, hingga siaran.',
    skills: ['Penyutradaraan', 'Videografi Siaran', 'Penataan Artistik'],
    kompetensi: [
      'Penulisan naskah dan skenario program televisi',
      'Teknik kamera, pencahayaan, dan tata suara siaran',
      'Penyutradaraan dan pengarahan talent di studio',
      'Editing pascaproduksi untuk program berita dan hiburan',
      'Penataan artistik panggung dan studio siaran',
    ],
    mapel: {
      X: ['Dasar Broadcasting', 'Fotografi Dasar', 'Simulasi & Komunikasi Digital', 'Penulisan Naskah Dasar'],
      XI: ['Kameramen & Pencahayaan', 'Penyutradaraan', 'Tata Suara Siaran', 'Editing Program TV'],
      XII: ['Produksi Program Televisi', 'Manajemen Siaran', 'Praktik Kerja Industri', 'Uji Kompetensi Keahlian'],
    },
    karir: ['Kameramen', 'Video Editor Siaran', 'Asisten Sutradara', 'Penulis Naskah Pemula'],
    mitra: ['Studio Siaran Nusantara', 'Kreasi Layar Indonesia', 'Broadcast Academy'],
  },
]

export const BERITA = [
  {
    slug: 'juara-lks-web-technology',
    tanggal: '02 SEP 2026',
    kategori: 'PRESTASI',
    judul: 'Tim RPL SMK INFOKOM raih Juara 1 LKS Web Technology tingkat Provinsi',
    ringkasan:
      'Tim yang beranggotakan tiga siswa kelas XII berhasil unggul dari 24 sekolah peserta melalui proyek aplikasi manajemen UMKM.',
    isi: [
      'Tim Lomba Kompetensi Siswa (LKS) bidang Web Technology dari jurusan Rekayasa Perangkat Lunak SMK INFOKOM berhasil meraih peringkat pertama pada ajang LKS tingkat Provinsi yang berlangsung selama tiga hari di Jakarta.',
      'Proyek yang dibawakan berupa aplikasi manajemen UMKM berbasis web, lengkap dengan fitur pencatatan stok, laporan penjualan, dan integrasi pembayaran digital. Dewan juri menilai tinggi kerapian arsitektur kode dan kejelasan alur pengguna.',
      'Prestasi ini melengkapi capaian sekolah pada dua tahun terakhir, dan tim akan mewakili provinsi ke ajang LKS tingkat nasional pada awal tahun depan.',
    ],
  },
  {
    slug: 'mou-kelas-industri',
    tanggal: '18 AGU 2026',
    kategori: 'KEMITRAAN',
    judul: 'Penandatanganan MoU kelas industri bersama tiga perusahaan teknologi',
    ringkasan:
      'Kerja sama mencakup kurikulum bersama, kunjungan industri, dan jalur magang khusus bagi siswa jurusan TKJ dan RPL.',
    isi: [
      'SMK INFOKOM menandatangani nota kesepahaman dengan tiga perusahaan teknologi nasional untuk menyelenggarakan kelas industri bagi jurusan Teknik Komputer & Jaringan serta Rekayasa Perangkat Lunak.',
      'Melalui kerja sama ini, kurikulum kedua jurusan akan disusun bersama tim engineering dari masing-masing perusahaan, mencakup materi terkini seputar keamanan siber dan integrasi cloud.',
      'Selain kurikulum bersama, siswa juga mendapat kesempatan kunjungan industri rutin dan jalur magang prioritas pada semester praktik kerja industri.',
    ],
  },
  {
    slug: 'pelepasan-prakerin-2026',
    tanggal: '05 AGU 2026',
    kategori: 'AKADEMIK',
    judul: 'Gelombang pertama Praktik Kerja Industri 2026 dilepas ke 40 perusahaan mitra',
    ringkasan:
      '312 siswa tingkat XI memulai enam bulan magang di berbagai perusahaan teknologi dan kreatif di wilayah Jabodetabek.',
    isi: [
      'Sebanyak 312 siswa kelas XI dari empat jurusan resmi dilepas untuk memulai program Praktik Kerja Industri (Prakerin) selama enam bulan di 40 perusahaan mitra wilayah Jabodetabek.',
      'Penempatan siswa disesuaikan dengan kompetensi jurusan masing-masing, mulai dari perusahaan pengembang perangkat lunak, penyedia layanan jaringan, hingga rumah produksi multimedia.',
      'Selama masa prakerin, setiap siswa didampingi oleh guru pembimbing sekolah dan mentor dari perusahaan untuk memastikan capaian kompetensi sesuai target.',
    ],
  },
  {
    slug: 'workshop-cloud-computing',
    tanggal: '22 JUL 2026',
    kategori: 'AKADEMIK',
    judul: 'Workshop dua hari Cloud Computing dasar untuk siswa TKJ',
    ringkasan:
      'Diselenggarakan bersama praktisi industri, siswa belajar langsung konfigurasi layanan cloud skala kecil.',
    isi: [
      'Sebanyak 60 siswa jurusan TKJ mengikuti workshop intensif dua hari bertema dasar-dasar cloud computing, dipandu langsung oleh praktisi dari mitra industri sekolah.',
      'Materi mencakup pengenalan layanan komputasi awan, konfigurasi server virtual, hingga simulasi migrasi aplikasi sederhana ke lingkungan cloud.',
      'Workshop ini menjadi bagian dari upaya sekolah memperbarui muatan kurikulum agar selaras dengan kebutuhan industri terkini.',
    ],
  },
  {
    slug: 'pameran-karya-multimedia',
    tanggal: '10 JUL 2026',
    kategori: 'PRESTASI',
    judul: 'Pameran karya siswa Multimedia tarik perhatian pengunjung pusat kota',
    ringkasan:
      'Puluhan karya motion graphic dan fotografi dipamerkan dalam acara tahunan Pekan Kreatif SMK INFOKOM.',
    isi: [
      'Pekan Kreatif SMK INFOKOM tahun ini menampilkan lebih dari 60 karya siswa jurusan Multimedia, mulai dari motion graphic, fotografi produk, hingga video pendek dokumenter.',
      'Acara yang digelar di area publik pusat kota ini berhasil menarik ratusan pengunjung, termasuk perwakilan dari beberapa agensi kreatif yang menyatakan minat menjalin kerja sama magang.',
      'Beberapa karya terbaik turut dipajang secara permanen di galeri sekolah sebagai referensi bagi siswa baru.',
    ],
  },
  {
    slug: 'sertifikasi-bnsp-2026',
    tanggal: '28 JUN 2026',
    kategori: 'AKADEMIK',
    judul: '420 siswa tingkat XII ikuti Uji Sertifikasi Kompetensi BNSP',
    ringkasan:
      'Sertifikasi mencakup skema kompetensi sesuai empat program keahlian yang tersedia di sekolah.',
    isi: [
      'Sebanyak 420 siswa kelas XII dari empat program keahlian mengikuti Uji Sertifikasi Kompetensi yang diselenggarakan bersama Lembaga Sertifikasi Profesi berlisensi BNSP.',
      'Skema uji disesuaikan dengan kompetensi masing-masing jurusan, mulai dari pengembangan perangkat lunak, administrasi jaringan, produksi multimedia, hingga integrasi sistem.',
      'Sertifikat kompetensi ini menjadi salah satu syarat penunjang dalam proses penyaluran kerja melalui Bursa Kerja Khusus sekolah.',
    ],
  },
]

export const GALERI = [
  { kategori: 'Profil Sekolah', judul: 'Suasana gedung dan lingkungan sekolah' },
  { kategori: 'Profil Sekolah', judul: 'Upacara bendera hari Senin' },
  { kategori: 'Profil Sekolah', judul: 'Kunjungan orang tua siswa' },
  { kategori: 'OSIS', judul: 'Rapat kerja pengurus OSIS' },
  { kategori: 'OSIS', judul: 'Pelantikan pengurus OSIS baru' },
  { kategori: 'OSIS', judul: 'Class meeting akhir semester' },
  { kategori: 'PKL', judul: 'Pelepasan siswa Praktik Kerja Lapangan' },
  { kategori: 'PKL', judul: 'Kunjungan monitoring ke perusahaan mitra' },
  { kategori: 'PKL', judul: 'Presentasi laporan akhir PKL' },
  { kategori: 'Akademik', judul: 'Praktik pemrograman web kelas XI RPL' },
  { kategori: 'Akademik', judul: 'Konfigurasi jaringan lab TKJ' },
  { kategori: 'Akademik', judul: 'Sesi produksi program TV kelas PSPT' },
  { kategori: 'Industri', judul: 'Penandatanganan MoU kelas industri' },
  { kategori: 'Industri', judul: 'Kunjungan industri ke perusahaan mitra' },
  { kategori: 'Industri', judul: 'Talkshow karier bersama praktisi' },
]

export const EKSKUL = [
  { nama: 'Klub Robotika', jadwal: 'Selasa & Kamis, 15.30', desc: 'Merancang dan memprogram robot untuk kompetisi tingkat regional dan nasional.' },
  { nama: 'Cyber Security Club', jadwal: 'Rabu, 15.30', desc: 'Latihan Capture The Flag dan simulasi keamanan jaringan bersama alumni.' },
  { nama: 'Videografi & Broadcasting', jadwal: 'Jumat, 14.00', desc: 'Produksi konten harian sekolah dan liputan acara-acara internal.' },
  { nama: 'English Debate Society', jadwal: 'Senin, 15.30', desc: 'Melatih kemampuan berbahasa Inggris lewat debat dan presentasi teknis.' },
  { nama: 'Futsal & Basket', jadwal: 'Sabtu, 08.00', desc: 'Latihan rutin dan partisipasi pada turnamen antar-SMK se-kota.' },
  { nama: 'Pramuka', jadwal: 'Jumat, 15.30', desc: 'Kegiatan kepramukaan wajib bagi kelas X sebagai pembinaan karakter.' },
]

export const PRESTASI = [
  { tahun: '2026', judul: 'Juara 1 LKS Web Technology tingkat Provinsi' },
  { tahun: '2025', judul: 'Juara 2 Kompetisi Cyber Security Nasional (Cyberthon)' },
  { tahun: '2025', judul: 'Juara 1 Festival Film Pendek Pelajar se-Jabodetabek' },
  { tahun: '2024', judul: 'Juara 3 LKS Network Support Administration Nasional' },
  { tahun: '2024', judul: 'Sekolah Rujukan Kurikulum Merdeka bidang TI oleh Dinas Pendidikan' },
]

export const SEJARAH = [
  { tahun: '1998', teks: 'SMK INFOKOM didirikan dengan dua program keahlian: Teknik Komputer & Jaringan dan Multimedia.' },
  { tahun: '2007', teks: 'Membuka jurusan Rekayasa Perangkat Lunak seiring meningkatnya kebutuhan pengembang aplikasi.' },
  { tahun: '2015', teks: 'Meraih akreditasi A pertama kali dari BAN-SM dan memulai program kelas industri.' },
  { tahun: '2021', teks: 'Membuka jurusan Produksi & Siaran Program Televisi menyusul meningkatnya kebutuhan industri media dan penyiaran.' },
  { tahun: '2026', teks: 'Mengelola lebih dari 1.200 siswa aktif dengan 65+ mitra industri penyalur kerja dan magang.' },
]

export const STRUKTUR = [
  { nama: 'Dr. Hendra Wijaya, S.Kom., M.T.', jabatan: 'Kepala Sekolah' },
  { nama: 'Siti Rahmawati, S.Pd., M.Pd.', jabatan: 'Wakil Kepala Bidang Kurikulum' },
  { nama: 'Agus Prasetyo, S.T.', jabatan: 'Wakil Kepala Bidang Kesiswaan' },
  { nama: 'Dewi Anggraini, S.Kom.', jabatan: 'Wakil Kepala Bidang Hubungan Industri' },
  { nama: 'Farhan Nugraha, S.Kom.', jabatan: 'Kepala Program Keahlian RPL' },
  { nama: 'Rina Kartika, S.T.', jabatan: 'Kepala Program Keahlian TKJ' },
]

export const TIM_GURU = [
  { kategori: 'Kepala Sekolah', nama: 'Dr. Hendra Wijaya, S.Kom., M.T.', jabatan: 'Kepala Sekolah', bidang: 'Manajemen Pendidikan', foto: '/images/team/guru-1.jpg' },
  { kategori: 'Wakasek', nama: 'Siti Rahmawati, S.Pd., M.Pd.', jabatan: 'Wakil Kepala Bidang Kurikulum', bidang: 'Kurikulum', foto: '/images/team/guru-2.jpg' },
  { kategori: 'Wakasek', nama: 'Agus Prasetyo, S.T.', jabatan: 'Wakil Kepala Bidang Kesiswaan', bidang: 'Kesiswaan', foto: '/images/team/guru-3.jpg' },
  { kategori: 'Wakasek', nama: 'Dewi Anggraini, S.Kom.', jabatan: 'Wakil Kepala Bidang Hubungan Industri', bidang: 'Hubinmas', foto: '/images/team/guru-4.jpg' },
  { kategori: 'Guru', nama: 'Farhan Nugraha, S.Kom.', jabatan: 'Kepala Program Keahlian RPL', bidang: 'Rekayasa Perangkat Lunak', foto: '/images/team/guru-5.jpg' },
  { kategori: 'Guru', nama: 'Rina Kartika, S.T.', jabatan: 'Kepala Program Keahlian TKJ', bidang: 'Teknik Komputer & Jaringan', foto: '/images/team/guru-6.jpg' },
  { kategori: 'Guru', nama: 'Budi Santoso, S.Kom.', jabatan: 'Guru Produktif RPL', bidang: 'Pemrograman Web & Mobile', foto: '/images/team/guru-7.jpg' },
  { kategori: 'Guru', nama: 'Maya Puspitasari, S.Ds.', jabatan: 'Guru Produktif Multimedia', bidang: 'Desain & Motion Graphic', foto: '/images/team/guru-8.jpg' },
  { kategori: 'Guru', nama: 'Yusuf Ardiansyah, S.T.', jabatan: 'Guru Produktif TKJ', bidang: 'Administrasi Jaringan', foto: '/images/team/guru-9.jpg' },
  { kategori: 'Guru', nama: 'Lestari Handayani, S.Pd.', jabatan: 'Guru Bimbingan Konseling', bidang: 'BK / Karier Siswa', foto: '/images/team/guru-10.jpg' },
  { kategori: 'Guru', nama: 'Dimas Prakoso, S.Sos.', jabatan: 'Guru Produktif PSPT', bidang: 'Produksi & Siaran TV', foto: '/images/team/guru-11.jpg' },
  { kategori: 'Guru', nama: 'Fitri Ramadhani, S.Pd.', jabatan: 'Guru Bahasa Inggris', bidang: 'Bahasa Inggris', foto: '/images/team/guru-12.jpg' },
]

/** Tenaga kependidikan (staf) — ditambahkan bila kelompok Staf masih kosong. */
export const TIM_STAF = [
  { kategori: 'Staf', nama: 'Nurhayati, S.E.', jabatan: 'Kepala Tata Usaha', bidang: 'Administrasi & Keuangan', foto: '/images/team/staf-1.jpg' },
  { kategori: 'Staf', nama: 'Rizki Maulana, A.Md.Kom.', jabatan: 'Operator Sekolah', bidang: 'Dapodik & Sistem Informasi', foto: '/images/team/staf-2.jpg' },
  { kategori: 'Staf', nama: 'Anisa Putri, S.IP.', jabatan: 'Pustakawan', bidang: 'Perpustakaan', foto: '/images/team/staf-3.jpg' },
]

/** Contoh video Instagram — ganti dengan Reel akun sekolah lewat panel admin. */
export const VIDEO_BKK = [
  { judul: 'Pekan Karier Bursa Kerja Khusus', url: 'https://www.instagram.com/reel/DNzquVM0EKS/', keterangan: 'Contoh video: suasana pekan karier dan rekrutmen langsung di sekolah.', sampul: '/images/hero/bkk.jpg' },
  { judul: 'Career Day: Membuka Jalan ke Dunia Kerja', url: 'https://www.instagram.com/reel/DZ2Y4dCTdKX/', keterangan: 'Contoh video: talkshow karier bersama praktisi industri dan HRD perusahaan.', sampul: '/images/gallery/gallery-13.jpg' },
  { judul: 'Job Fair: Temukan Peluang Karier yang Tepat', url: 'https://www.instagram.com/reel/DOfY7UykoeK/', keterangan: 'Contoh video: job fair dengan puluhan perusahaan mitra.', sampul: '/images/gallery/gallery-7.jpg' },
]
export const VIDEO_MAGANG = [
  { judul: 'Menuju Karier Internasional di Jepang', url: 'https://www.instagram.com/reel/DXfuZF-EwIo/', keterangan: 'Contoh video: persiapan siswa SMK untuk program kerja ke Jepang.', sampul: '/images/magang/pelatihan.jpg' },
  { judul: 'Berangkat Kerja ke Jepang lewat LPK Resmi', url: 'https://www.instagram.com/reel/DP3sHW2kptp/', keterangan: 'Contoh video: alur pelatihan hingga keberangkatan peserta magang.', sampul: '/images/hero/magang-jepang.jpg' },
  { judul: 'Keseharian Peserta Magang di Jepang', url: 'https://www.instagram.com/reel/DOs_d6WiVAR/', keterangan: 'Contoh video: cerita peserta magang yang sudah bekerja di Jepang.', sampul: '/images/magang/manufaktur.jpg' },
]

export const TESTIMONI = [
  {
    nama: 'Aditya Putra Ramadhan',
    peran: 'Alumni RPL 2023 — Software Engineer di Kolaborasi Digital',
    kutipan:
      'Proyek nyata bersama industri sejak kelas XI membuat saya sudah terbiasa bekerja dalam tim sebelum lulus. Transisi ke dunia kerja terasa jauh lebih ringan.',
  },
  {
    nama: 'Nadya Az-Zahra',
    peran: 'Alumni Multimedia 2024 — Motion Designer di Studio Rekakarya',
    kutipan:
      'Guru-guru di sini adalah praktisi aktif, bukan sekadar mengajar teori. Portofolio yang saya bangun selama sekolah langsung terpakai saat melamar kerja.',
  },
  {
    nama: 'Muhammad Rafi Firmansyah',
    peran: 'Alumni TKJ 2022 — Network Engineer di SecureNet Indonesia',
    kutipan:
      'Sertifikasi BNSP yang saya dapat di sekolah jadi nilai tambah besar saat interview. Lab jaringan di sini setara dengan yang saya temui di kantor sekarang.',
  },
]

export const FAQ = [
  {
    q: 'Apa saja syarat pendaftaran SMK INFOKOM?',
    a: 'Calon siswa merupakan lulusan atau akan lulus SMP/MTs, memiliki nilai rapor semester 1–5, dan mengikuti tes bakat skolastik yang diselenggarakan sekolah.',
  },
  {
    q: 'Apakah ada jalur beasiswa atau keringanan biaya?',
    a: 'Tersedia jalur beasiswa prestasi akademik dan non-akademik, serta keringanan biaya bagi keluarga kurang mampu dengan melampirkan dokumen pendukung saat pendaftaran.',
  },
  {
    q: 'Bagaimana proses pemilihan jurusan dilakukan?',
    a: 'Calon siswa memilih jurusan saat mendaftar. Penempatan akhir mempertimbangkan pilihan, hasil tes bakat skolastik, dan kuota tiap program keahlian.',
  },
  {
    q: 'Apakah SMK INFOKOM menyediakan asrama?',
    a: 'Saat ini sekolah belum menyediakan asrama, namun tim kesiswaan dapat membantu memberikan referensi tempat kos di sekitar area sekolah.',
  },
  {
    q: 'Berapa lama masa Praktik Kerja Industri?',
    a: 'Praktik Kerja Industri berlangsung minimal enam bulan pada kelas XI, ditempatkan di perusahaan mitra sesuai program keahlian masing-masing siswa.',
  },
]

export const BIAYA = [
  { item: 'Biaya Pendaftaran', nominal: 'Rp 150.000', keterangan: 'Sekali bayar, saat pendaftaran' },
  { item: 'Sumbangan Pengembangan Pendidikan', nominal: 'Rp 3.500.000', keterangan: 'Sekali bayar, saat daftar ulang' },
  { item: 'SPP Bulanan', nominal: 'Rp 375.000', keterangan: 'Dibayarkan setiap bulan' },
  { item: 'Seragam & Perlengkapan', nominal: 'Rp 1.200.000', keterangan: 'Sekali bayar, saat daftar ulang' },
]

export const TAHAPAN_PPDB = [
  { label: 'Pendaftaran Online', waktu: '01 Des — 20 Jan' },
  { label: 'Tes Bakat Skolastik', waktu: '27 — 28 Jan' },
  { label: 'Pengumuman', waktu: '05 Feb' },
  { label: 'Daftar Ulang', waktu: '06 — 14 Feb' },
]

/* ================= BKK ================= */
export const LOWONGAN = [
  { judul: 'Junior Web Developer', perusahaan: 'Kolaborasi Digital', lokasi: 'Jakarta Selatan', tipe: 'Penuh Waktu', bidang: 'Perangkat Lunak', gaji: 'Rp 5 – 6,5 juta', kuota: 4, hari: 3, sisa: 25,
    deskripsi: 'Bergabung dengan tim produk untuk membangun dan merawat aplikasi web klien dari sektor ritel dan logistik.\n\nKamu akan bekerja dengan React, Laravel, dan REST API di bawah bimbingan senior engineer, dengan siklus sprint dua mingguan.',
    kualifikasi: ['Lulusan SMK RPL atau sederajat, maksimal 2 tahun', 'Menguasai HTML, CSS, JavaScript dasar', 'Terbiasa memakai Git', 'Memiliki portofolio minimal 2 proyek web'], benefit: ['BPJS Kesehatan & Ketenagakerjaan', 'Mentoring 3 bulan pertama', 'Laptop kerja', 'Jenjang karier ke Mid Developer'] },
  { judul: 'Network Support Engineer', perusahaan: 'SecureNet Indonesia', lokasi: 'Jakarta Pusat', tipe: 'Kontrak', bidang: 'Jaringan & IT Support', gaji: 'Rp 4,8 – 5,5 juta', kuota: 6, hari: 6, sisa: 18,
    deskripsi: 'Menangani instalasi, konfigurasi, dan pemeliharaan jaringan kantor klien korporat. Kontrak 12 bulan dengan peluang pengangkatan karyawan tetap.',
    kualifikasi: ['Lulusan SMK TKJ', 'Memahami routing, switching, VLAN dasar', 'Sertifikat MikroTik MTCNA menjadi nilai tambah', 'Bersedia mobile ke lokasi klien'], benefit: ['Tunjangan transport', 'Sertifikasi CCNA dibiayai', 'BPJS'] },
  { judul: 'Motion Graphic Designer', perusahaan: 'Studio Rekakarya', lokasi: 'Tangerang Selatan', tipe: 'Penuh Waktu', bidang: 'Multimedia & Desain', gaji: 'Rp 4,5 – 6 juta', kuota: 2, hari: 9, sisa: 20,
    deskripsi: 'Membuat animasi dan aset visual untuk kampanye iklan digital klien. Bekerja bersama tim kreatif dan copywriter.',
    kualifikasi: ['Lulusan SMK Multimedia / DKV', 'Mahir Adobe After Effects dan Illustrator', 'Memiliki showreel'], benefit: ['Jam kerja fleksibel', 'Tunjangan makan', 'Lisensi software'] },
  { judul: 'Camera Person & Editor', perusahaan: 'Studio Siaran Nusantara', lokasi: 'Jakarta Barat', tipe: 'Kontrak', bidang: 'Broadcasting', gaji: 'Rp 4,5 – 5 juta', kuota: 3, hari: 12, sisa: 14,
    deskripsi: 'Mengoperasikan kamera studio dan lapangan untuk program berita dan hiburan, serta menyunting materi tayang.',
    kualifikasi: ['Lulusan SMK PSPT / Multimedia', 'Menguasai Adobe Premiere atau DaVinci Resolve', 'Siap bekerja dengan sistem shift'], benefit: ['Uang lembur', 'BPJS', 'Pelatihan produksi'] },
  { judul: 'IT Helpdesk', perusahaan: 'Bank Mitra Sejahtera', lokasi: 'Bogor', tipe: 'Penuh Waktu', bidang: 'Jaringan & IT Support', gaji: 'Rp 4,6 juta', kuota: 5, hari: 15, sisa: 10,
    deskripsi: 'Memberikan dukungan teknis perangkat keras, perangkat lunak, dan jaringan untuk kantor cabang wilayah Bogor.',
    kualifikasi: ['Lulusan SMK TKJ / RPL', 'Komunikatif dan ramah', 'Memahami instalasi Windows dan printer jaringan'], benefit: ['Karyawan tetap setelah 6 bulan', 'THR & bonus tahunan', 'Asuransi kesehatan'] },
  { judul: 'Programmer Magang (Paid Internship)', perusahaan: 'Nusantara Software House', lokasi: 'Depok (Hybrid)', tipe: 'Magang', bidang: 'Perangkat Lunak', gaji: 'Uang saku Rp 2,5 juta', kuota: 8, hari: 20, sisa: 30,
    deskripsi: 'Program magang berbayar 6 bulan untuk lulusan baru. Peserta terbaik akan diangkat menjadi Junior Developer.',
    kualifikasi: ['Siswa kelas XII semester akhir atau lulusan baru RPL', 'Memahami dasar pemrograman PHP atau JavaScript'], benefit: ['Uang saku', 'Sertifikat', 'Peluang diangkat karyawan'] },
  { judul: 'Admin Data Entry', perusahaan: 'PT Logistik Cepat Indonesia', lokasi: 'Cikarang', tipe: 'Kontrak', bidang: 'Administrasi', gaji: 'Sesuai UMK Bekasi', kuota: 10, hari: 40, sisa: -5,
    deskripsi: 'Mengelola input data pengiriman dan laporan harian gudang.', kualifikasi: ['Lulusan SMK semua jurusan', 'Teliti dan menguasai Microsoft Excel'], benefit: ['BPJS', 'Uang makan'] },
]

export const BKK_MITRA = ['Bank Mitra Sejahtera', 'PT Logistik Cepat Indonesia', 'Telkom Akses', 'Indomaret Group', 'PT Astra Honda Motor', 'Tokopedia Care']

export const FAQ_BKK = [
  { q: 'Apakah layanan BKK dipungut biaya?', a: 'Tidak. Seluruh layanan BKK SMK INFOKOM gratis untuk siswa kelas XII dan alumni, termasuk tes rekrutmen yang dilakukan di sekolah.' },
  { q: 'Siapa saja yang boleh melamar lewat BKK?', a: 'Siswa kelas XII semester akhir dan alumni SMK INFOKOM. Beberapa lowongan juga terbuka untuk lulusan SMK lain bila disebutkan di detail lowongan.' },
  { q: 'Bagaimana saya tahu status lamaran saya?', a: 'Tim BKK akan menghubungi melalui WhatsApp atau email yang kamu isi. Kamu juga dapat datang langsung ke ruang BKK pada jam layanan.' },
  { q: 'Perusahaan ingin merekrut lulusan, bagaimana caranya?', a: 'Perusahaan dapat menghubungi BKK melalui halaman Kontak atau WhatsApp untuk mengirim informasi lowongan dan menjadwalkan rekrutmen di sekolah.' },
]

/* ================= MAGANG JEPANG ================= */
export const MAGANG_BIDANG = [
  { nama: 'Manufaktur & Pengolahan Logam', istilah_jp: 'Seizou / Kinzoku', gambar: '/images/magang/manufaktur.jpg', durasi: '3 — 5 tahun', gaji: '¥160.000 — ¥190.000 / bulan',
    deskripsi: 'Operator mesin CNC, perakitan komponen otomotif dan elektronik, serta pengendalian mutu di pabrik.', syarat: ['Pria / wanita', 'Tidak buta warna', 'Teliti dan kuat berdiri lama'] },
  { nama: 'Perawat Lansia', istilah_jp: 'Kaigo', gambar: '/images/magang/kaigo.jpg', durasi: '3 — 5 tahun', gaji: '¥170.000 — ¥200.000 / bulan',
    deskripsi: 'Mendampingi aktivitas harian lansia di panti wreda: makan, mandi, rekreasi, dan mobilitas.', syarat: ['Diutamakan wanita', 'Bahasa Jepang minimal N4', 'Sabar dan komunikatif'] },
  { nama: 'Konstruksi', istilah_jp: 'Kensetsu', gambar: '/images/magang/konstruksi.jpg', durasi: '3 tahun', gaji: '¥180.000 — ¥220.000 / bulan',
    deskripsi: 'Pemasangan perancah, bekisting, besi beton, dan finishing interior di proyek bangunan.', syarat: ['Pria', 'Tinggi minimal 165 cm', 'Fisik prima'] },
  { nama: 'Pertanian', istilah_jp: 'Nougyou', gambar: '/images/magang/pertanian.jpg', durasi: '3 tahun', gaji: '¥150.000 — ¥175.000 / bulan',
    deskripsi: 'Budidaya sayuran di rumah kaca, panen, pengemasan hasil tani, dan perawatan lahan.', syarat: ['Pria / wanita', 'Tahan cuaca dingin', 'Terbiasa kerja fisik'] },
  { nama: 'Pengolahan Makanan', istilah_jp: 'Shokuhin Seizou', gambar: '/images/magang/makanan.jpg', durasi: '3 — 5 tahun', gaji: '¥155.000 — ¥180.000 / bulan',
    deskripsi: 'Produksi bento, roti, dan makanan olahan di pabrik dengan standar higienitas tinggi.', syarat: ['Pria / wanita', 'Tidak alergi makanan laut', 'Menjaga kebersihan diri'] },
]

export const MAGANG_ALUMNI = [
  { nama: 'Rizky Maulana', angkatan: '2022', jurusan: 'TKJ', perusahaan: 'Toyota Boshoku Kyushu', prefektur: 'Fukuoka', bidang: 'Manufaktur', kutipan: 'Tiga tahun di Fukuoka mengajarkan saya disiplin yang tidak saya dapat di mana pun. Tabungan saya cukup untuk membuka bengkel sendiri di Bogor.' },
  { nama: 'Salsabila Putri', angkatan: '2023', jurusan: 'Multimedia', perusahaan: 'Sakura Care Home', prefektur: 'Osaka', bidang: 'Kaigo', kutipan: 'Pelatihan bahasa di sekolah sangat membantu. Di minggu pertama saya sudah bisa berkomunikasi dengan para ojiichan dan obaachan.' },
  { nama: 'Fajar Nugroho', angkatan: '2023', jurusan: 'RPL', perusahaan: 'Hokkaido Green Farm', prefektur: 'Hokkaido', bidang: 'Pertanian', kutipan: 'Musim dingin di Hokkaido memang berat, tapi tim sekolah selalu memantau kabar kami lewat grup setiap bulan.' },
  { nama: 'Dian Lestari', angkatan: '2024', jurusan: 'PSPT', perusahaan: 'Nichirei Foods', prefektur: 'Chiba', bidang: 'Pengolahan Makanan', kutipan: 'Biaya pelatihan bisa dicicil, jadi orang tua tidak terbebani. Sekarang saya yang membantu biaya sekolah adik.' },
]

export const MAGANG_MITRA = ['Toyota Boshoku Kyushu', 'Sakura Care Home', 'Nichirei Foods', 'Hokkaido Green Farm', 'LPK Sakura Nusantara', 'Kyodo Kumiai Chubu']

export const FAQ_MAGANG = [
  { q: 'Apakah alumni jurusan TI bisa ikut magang ke Jepang?', a: 'Bisa. Program ini terbuka untuk semua jurusan. Bidang kerja ditentukan oleh minat, hasil tes fisik, dan kebutuhan perusahaan penerima di Jepang.' },
  { q: 'Berapa lama pelatihan sebelum berangkat?', a: 'Pelatihan bahasa dan budaya kerja berlangsung 4 — 6 bulan. Waktu tunggu keberangkatan setelah lolos interview user rata-rata 3 — 5 bulan untuk pengurusan COE dan visa.' },
  { q: 'Apakah program ini resmi?', a: 'Ya. Sekolah bekerja sama dengan LPK berizin Kemnaker dan Sending Organization resmi. Seluruh peserta berangkat dengan visa Technical Intern Training atau Specified Skilled Worker.' },
  { q: 'Bagaimana jika gagal di interview user?', a: 'Peserta tetap mengikuti pelatihan dan akan diikutkan pada interview user berikutnya tanpa biaya tambahan hingga maksimal tiga kali kesempatan.' },
  { q: 'Apakah boleh berangkat jika memakai hijab?', a: 'Boleh. Banyak perusahaan mitra kami menerima peserta berhijab dan menyediakan waktu serta ruang untuk beribadah.' },
]

export const FAQ_UMUM = [
  { q: 'Di mana lokasi SMK INFOKOM?', a: 'Kampus berada di alamat yang tercantum di halaman Kontak dan dapat dijangkau dengan transportasi umum. Peta lokasi juga tersedia di halaman tersebut.' },
]

export const UNDUHAN = [
  { judul: 'Brosur PPDB 2027/2028', kategori: 'PPDB', keterangan: 'PDF, 2 halaman', file: '/files/brosur-ppdb-2027-2028.pdf' },
  { judul: 'Formulir Pendaftaran PPDB 2027/2028', kategori: 'PPDB', keterangan: 'PDF isian, 2 halaman — bisa diisi langsung atau dicetak', file: '/files/formulir-pendaftaran-ppdb-2027-2028.pdf' },
  { judul: 'Surat Pernyataan Orang Tua / Wali', kategori: 'PPDB', keterangan: 'PDF, dicetak, bermeterai, dan ditandatangani', file: '/files/surat-pernyataan-orang-tua-ppdb.pdf' },
  { judul: 'Kalender Akademik 2026/2027', kategori: 'Akademik', keterangan: 'PDF, 1 halaman' },
  { judul: 'Panduan Praktik Kerja Lapangan', kategori: 'Akademik', keterangan: 'PDF, 18 halaman' },
  { judul: 'Template CV Lulusan SMK INFOKOM', kategori: 'BKK', keterangan: 'DOCX, bisa diedit' },
  { judul: 'Surat Izin Orang Tua Magang Jepang', kategori: 'Magang Jepang', keterangan: 'PDF, wajib bermeterai' },
  { judul: 'Buku Panduan Program Magang Jepang', kategori: 'Magang Jepang', keterangan: 'PDF, 24 halaman' },
]
