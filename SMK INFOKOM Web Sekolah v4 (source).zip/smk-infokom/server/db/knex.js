import fs from 'node:fs'
import path from 'node:path'
import knexFactory from 'knex'
import { config } from '../config.js'

function buildConfig() {
  const c = config.db
  const client = c.client.toLowerCase()

  if (client === 'sqlite' || client === 'sqlite3' || client === 'better-sqlite3') {
    fs.mkdirSync(path.dirname(c.filename), { recursive: true })
    return {
      client: 'better-sqlite3',
      connection: { filename: c.filename },
      useNullAsDefault: true,
    }
  }

  if (client === 'mysql' || client === 'mysql2' || client === 'mariadb') {
    return {
      client: 'mysql2',
      connection: c.url || {
        host: c.host,
        port: c.port || 3306,
        user: c.user,
        password: c.password,
        database: c.database,
        charset: 'utf8mb4',
        dateStrings: true,
      },
      pool: { min: 0, max: 10 },
    }
  }

  if (client === 'pg' || client === 'postgres' || client === 'postgresql') {
    return {
      client: 'pg',
      connection: c.url || {
        host: c.host,
        port: c.port || 5432,
        user: c.user,
        password: c.password,
        database: c.database,
      },
      pool: { min: 0, max: 10 },
    }
  }

  throw new Error(`DB_CLIENT tidak dikenal: ${c.client}. Gunakan sqlite, mysql, atau pg.`)
}

export const knexConfig = buildConfig()
export const db = knexFactory(knexConfig)
export const isSqlite = knexConfig.client === 'better-sqlite3'
