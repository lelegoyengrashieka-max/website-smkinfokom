/**
 * Sinkronisasi skema: membuat tabel yang belum ada dan menambahkan kolom baru
 * berdasarkan definisi di server/resources.js. Aman dijalankan berulang kali
 * (tidak pernah menghapus tabel/kolom/data).
 */
import { db } from './knex.js'
import { RESOURCES, columnFor } from '../resources.js'

export async function syncSchema({ log = true } = {}) {
  for (const [name, res] of Object.entries(RESOURCES)) {
    const exists = await db.schema.hasTable(name)
    if (!exists) {
      await db.schema.createTable(name, (t) => {
        t.increments('id').primary()
        for (const [col, field] of Object.entries(res.fields)) {
          const c = columnFor(t, col, field)
          if (field.type === 'slug' || field.unique) c.unique()
        }
        t.timestamp('created_at').defaultTo(db.fn.now())
        t.timestamp('updated_at').defaultTo(db.fn.now())
      })
      if (log) console.log(`  + tabel ${name} dibuat`)
    } else {
      for (const [col, field] of Object.entries(res.fields)) {
        if (!(await db.schema.hasColumn(name, col))) {
          await db.schema.alterTable(name, (t) => columnFor(t, col, field))
          if (log) console.log(`  + kolom ${name}.${col} ditambahkan`)
        }
      }
    }
  }

  if (!(await db.schema.hasTable('settings'))) {
    await db.schema.createTable('settings', (t) => {
      t.string('key', 100).primary()
      t.text('value', 'longtext').nullable()
      t.timestamp('updated_at').defaultTo(db.fn.now())
    })
    if (log) console.log('  + tabel settings dibuat')
  }
}
