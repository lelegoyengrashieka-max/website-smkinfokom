/**
 * Perintah database:
 *   node server/db/cli.js migrate   → buat/perbarui tabel
 *   node server/db/cli.js seed      → isi data contoh (hanya tabel kosong)
 *   node server/db/cli.js setup     → migrate + seed
 *   node server/db/cli.js sql       → cetak skema SQL MySQL ke database/schema.mysql.sql
 */
import fs from 'node:fs'
import path from 'node:path'
import knexFactory from 'knex'
import { db } from './knex.js'
import { syncSchema } from './sync.js'
import { seedDatabase } from './seed.js'
import { RESOURCES, columnFor } from '../resources.js'
import { ROOT } from '../config.js'

const cmd = process.argv[2] || 'setup'

async function dumpMysql() {
  const k = knexFactory({ client: 'mysql2' })
  const parts = ['-- Skema database SMK INFOKOM (MySQL / MariaDB)', '-- Dibuat otomatis dari server/resources.js', '-- Import lewat phpMyAdmin atau: mysql -u root -p smk_infokom < database/schema.mysql.sql', '', 'SET NAMES utf8mb4;', '']
  for (const [name, res] of Object.entries(RESOURCES)) {
    const sql = k.schema.createTable(name, (t) => {
      t.increments('id').primary()
      for (const [col, field] of Object.entries(res.fields)) {
        const c = columnFor(t, col, field)
        if (field.type === 'slug' || field.unique) c.unique()
      }
      t.timestamp('created_at').defaultTo(k.fn.now())
      t.timestamp('updated_at').defaultTo(k.fn.now())
      t.charset('utf8mb4')
      t.collate('utf8mb4_unicode_ci')
    }).toString()
    parts.push(`DROP TABLE IF EXISTS \`${name}\`;`, sql.replace(/;?\s*$/, ';'), '')
  }
  parts.push('DROP TABLE IF EXISTS `settings`;')
  parts.push(k.schema.createTable('settings', (t) => {
    t.string('key', 100).primary(); t.text('value', 'longtext').nullable(); t.timestamp('updated_at').defaultTo(k.fn.now())
    t.charset('utf8mb4'); t.collate('utf8mb4_unicode_ci')
  }).toString() + ';')
  const out = path.join(ROOT, 'database/schema.mysql.sql')
  fs.writeFileSync(out, parts.join('\n') + '\n')
  console.log('Skema MySQL ditulis ke', out)
  await k.destroy()
}

try {
  if (cmd === 'migrate' || cmd === 'setup') { console.log('Sinkronisasi skema…'); await syncSchema() }
  if (cmd === 'seed' || cmd === 'setup') { console.log('Mengisi data awal…'); await seedDatabase() }
  if (cmd === 'sql') await dumpMysql()
  console.log('Selesai.')
} catch (err) {
  console.error('Gagal:', err.message)
  process.exitCode = 1
} finally {
  await db.destroy()
}
