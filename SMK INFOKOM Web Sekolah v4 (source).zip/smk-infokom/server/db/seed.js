/**
 * Mengisi data awal (contoh) ke database. Hanya mengisi tabel yang masih kosong,
 * sehingga aman dijalankan berulang kali dan tidak menimpa data yang sudah diedit.
 */
import bcrypt from 'bcryptjs'
import { db } from './knex.js'
import { config } from '../config.js'
import { SETTING_FIELDS } from '../settings.js'
import * as D from './seed-data.js'

const BULAN = { JAN: '01', FEB: '02', MAR: '03', APR: '04', MEI: '05', MAY: '05', JUN: '06', JUL: '07', AGU: '08', AUG: '08', SEP: '09', OKT: '10', OCT: '10', NOV: '11', DES: '12', DEC: '12' }
const BULAN_PANJANG = { Januari: '01', Februari: '02', Maret: '03', April: '04', Mei: '05', Juni: '06', Juli: '07', Agustus: '08', September: '09', Oktober: '10', November: '11', Desember: '12' }

function tanggalPendek(s) {
  const [d, m, y] = s.split(' ')
  return `${y}-${BULAN[m.toUpperCase()] || '01'}-${d.padStart(2, '0')}`
}
function tanggalPeriode(s) {
  const [m, y] = s.split(' ')
  return `${y}-${BULAN_PANJANG[m] || '01'}-01`
}
const J = (arr) => JSON.stringify(arr || [])
const now = () => new Date().toISOString().slice(0, 19).replace('T', ' ')

const IMG_JURUSAN = { rpl: '/images/jurusan/rpl.jpg', tkj: '/images/jurusan/tkj.jpg', multimedia: '/images/jurusan/mm.jpg', pspt: '/images/jurusan/pspt.jpg' }
const IMG_BERITA = ['/images/gallery/gallery-10.jpg', '/images/gallery/gallery-13.jpg', '/images/gallery/gallery-7.jpg', '/images/gallery/gallery-11.jpg', '/images/gallery/gallery-12.jpg', '/images/gallery/gallery-3.jpg']

/** Menebak kelompok guru dari teks jabatan (untuk data lama). */
export function kategoriGuru(jabatan = '') {
  const j = String(jabatan).toLowerCase()
  if (/^kepala sekolah/.test(j)) return 'Kepala Sekolah'
  if (/wakil kepala|wakasek|waka\b/.test(j)) return 'Wakasek'
  if (/guru|kepala program|kaprog|pengajar/.test(j)) return 'Guru'
  return 'Staf'
}

async function seedTable(table, rows) {
  const [{ n }] = await db(table).count({ n: '*' })
  if (Number(n) > 0 || rows.length === 0) return false
  const stamp = now()
  const withTs = rows.map((r) => ({ created_at: stamp, updated_at: stamp, ...r }))
  for (let i = 0; i < withTs.length; i += 50) await db(table).insert(withTs.slice(i, i + 50))
  console.log(`  + ${rows.length} baris contoh → ${table}`)
  return true
}

export async function seedDatabase() {
  // Pengguna admin pertama
  const [{ n: users }] = await db('users').count({ n: '*' })
  if (Number(users) === 0) {
    await db('users').insert({
      username: config.admin.username,
      nama: config.admin.nama,
      password: await bcrypt.hash(config.admin.password, 10),
      role: 'admin',
      aktif: true,
      created_at: now(),
      updated_at: now(),
    })
    console.log(`  + pengguna admin dibuat → username: ${config.admin.username}`)
    if (config.admin.password === 'admin12345') {
      console.log('    (password bawaan "admin12345" — SEGERA ganti lewat menu Akun Saya)')
    }
  }

  // Pengaturan: isi key yang belum ada
  const existing = new Set((await db('settings').select('key')).map((r) => r.key))
  const missing = SETTING_FIELDS.filter((f) => !existing.has(f.key))
  if (missing.length) {
    await db('settings').insert(missing.map((f) => ({ key: f.key, value: String(f.default ?? ''), updated_at: now() })))
    console.log(`  + ${missing.length} pengaturan bawaan`)
  }

  await seedTable('jurusan', D.PROGRAMS.map((p, i) => ({
    nama: p.name, kode: p.code, slug: p.slug, tagline: p.tagline, deskripsi: p.desc,
    gambar: IMG_JURUSAN[p.slug] || null, skills: J(p.skills), kompetensi: J(p.kompetensi),
    mapel_x: J(p.mapel.X), mapel_xi: J(p.mapel.XI), mapel_xii: J(p.mapel.XII),
    karir: J(p.karir), mitra: J(p.mitra), aktif: true, urutan: i + 1,
  })))

  await seedTable('berita', D.BERITA.map((b, i) => ({
    judul: b.judul, slug: b.slug, kategori: b.kategori, tanggal: tanggalPendek(b.tanggal),
    gambar: IMG_BERITA[i % IMG_BERITA.length], ringkasan: b.ringkasan, isi: b.isi.join('\n\n'),
    penulis: 'Humas SMK INFOKOM', status: 'terbit',
  })))

  await seedTable('agenda', D.KALENDER.map((k) => ({ kegiatan: k.kegiatan, tanggal: tanggalPeriode(k.periode), periode: k.periode, lokasi: 'Kampus SMK INFOKOM' })))
  await seedTable('galeri', D.GALERI.map((g, i) => ({ judul: g.judul, kategori: g.kategori, gambar: `/images/gallery/gallery-${i + 1}.jpg`, urutan: i + 1 })))
  await seedTable('prestasi', D.PRESTASI.map((p, i) => ({
    judul: p.judul, tahun: p.tahun, urutan: i + 1,
    tingkat: /Nasional/i.test(p.judul) ? 'Nasional' : /Provinsi/i.test(p.judul) ? 'Provinsi' : 'Kota',
  })))
  await seedTable('ekskul', D.EKSKUL.map((e, i) => ({ nama: e.nama, jadwal: e.jadwal, deskripsi: e.desc, urutan: i + 1 })))
  await seedTable('testimoni', D.TESTIMONI.map((t, i) => ({ nama: t.nama, peran: t.peran, kutipan: t.kutipan, tampil: true, urutan: i + 1 })))
  await seedTable('guru', D.TIM_GURU.map((g, i) => ({ ...g, tampil: true, urutan: i + 1 })))
  // Kelompok guru: isi otomatis untuk data lama yang belum punya kelompok
  for (const row of await db('guru').whereNull('kategori').orWhere('kategori', '')) {
    await db('guru').where({ id: row.id }).update({ kategori: kategoriGuru(row.jabatan) })
  }
  const [{ n: nStaf }] = await db('guru').where({ kategori: 'Staf' }).count({ n: '*' })
  if (Number(nStaf) === 0) {
    await db('guru').insert(D.TIM_STAF.map((g, i) => ({ ...g, tampil: true, urutan: 100 + i, created_at: now(), updated_at: now() })))
    console.log('  + contoh data staf')
  }
  await seedTable('struktur', D.STRUKTUR.map((s, i) => ({ nama: s.nama, jabatan: s.jabatan, level: i === 0 ? '1' : i <= 3 ? '2' : '3', urutan: i + 1 })))
  await seedTable('fasilitas', D.FASILITAS.map((f, i) => ({ ruang: f.ruang, unit: f.unit, kapasitas: f.kapasitas, urutan: i + 1 })))
  await seedTable('sejarah', D.SEJARAH.map((s) => ({ tahun: s.tahun, teks: s.teks })))
  await seedTable('mitra', D.KEMITRAAN.map((k, i) => {
    const [nama, bidang] = k.split(' — ')
    return { nama, bidang, urutan: i + 1 }
  }))
  await seedTable('biaya', D.BIAYA.map((b, i) => ({ item: b.item, nominal: b.nominal, keterangan: b.keterangan, urutan: i + 1 })))
  await seedTable('tahapan', D.TAHAPAN_PPDB.map((t, i) => ({ label: t.label, waktu: t.waktu, urutan: i + 1 })))
  await seedTable('faq', D.FAQ.map((f, i) => ({ pertanyaan: f.q, jawaban: f.a, kategori: 'PPDB', urutan: i + 1 })))
  await db('faq').whereNull('kategori').update({ kategori: 'PPDB' })
  for (const [kat, rows] of [['BKK', D.FAQ_BKK], ['Magang Jepang', D.FAQ_MAGANG], ['Umum', D.FAQ_UMUM]]) {
    const [{ n }] = await db('faq').where({ kategori: kat }).count({ n: '*' })
    if (Number(n) === 0) {
      await db('faq').insert(rows.map((f, i) => ({ pertanyaan: f.q, jawaban: f.a, kategori: kat, urutan: i + 1, created_at: now(), updated_at: now() })))
      console.log(`  + FAQ ${kat}`)
    }
  }
  await db('mitra').whereNull('jenis').update({ jenis: 'Industri' })
  for (const [jenis, list] of [['Rekrutmen BKK', D.BKK_MITRA], ['Mitra Jepang', D.MAGANG_MITRA]]) {
    const [{ n }] = await db('mitra').where({ jenis }).count({ n: '*' })
    if (Number(n) === 0) await db('mitra').insert(list.map((nama, i) => ({ nama, jenis, bidang: jenis === 'Mitra Jepang' ? 'Penerima & penyelenggara magang' : 'Rekrutmen lulusan', urutan: 50 + i, created_at: now(), updated_at: now() })))
  }

  const iso = (d) => new Date(Date.now() + d * 86400000).toISOString().slice(0, 10)
  const slugify = (t) => t.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
  await seedTable('lowongan', D.LOWONGAN.map((l) => ({
    judul: l.judul, slug: slugify(`${l.judul}-${l.perusahaan}`), perusahaan: l.perusahaan, lokasi: l.lokasi, tipe: l.tipe, bidang: l.bidang,
    gaji: l.gaji, kuota: l.kuota, tanggal: iso(-l.hari), deadline: iso(l.sisa), deskripsi: l.deskripsi,
    kualifikasi: J(l.kualifikasi), benefit: J(l.benefit), cara_melamar: 'Lamar melalui formulir di halaman ini. Tim BKK akan memeriksa berkas lalu meneruskannya ke perusahaan.',
    status: l.sisa < 0 ? 'ditutup' : 'dibuka',
  })))
  await seedTable('magang_bidang', D.MAGANG_BIDANG.map((b, i) => ({ ...b, syarat: J(b.syarat), urutan: i + 1 })))
  await seedTable('magang_alumni', D.MAGANG_ALUMNI.map((a, i) => ({ ...a, tampil: true, urutan: i + 1 })))
  await seedTable('video_bkk', D.VIDEO_BKK.map((v, i) => ({ ...v, tanggal: iso(-7 * (i + 1)), tampil: true, urutan: i + 1 })))
  await seedTable('video_magang', D.VIDEO_MAGANG.map((v, i) => ({ ...v, tanggal: iso(-9 * (i + 1)), tampil: true, urutan: i + 1 })))
  await seedTable('unduhan', D.UNDUHAN.map((u, i) => ({ file: 'https://drive.google.com/', ...u, urutan: i + 1 })))
}
