import fs from 'node:fs'
import path from 'node:path'
import express from 'express'
import helmet from 'helmet'
import cors from 'cors'
import compression from 'compression'
import { config, ROOT } from './config.js'
import { db } from './db/knex.js'
import { syncSchema } from './db/sync.js'
import { seedDatabase } from './db/seed.js'
import publicRoutes from './routes/public.js'
import authRoutes from './routes/auth.js'
import adminRoutes from './routes/admin.js'

const app = express()
app.set('trust proxy', 1)
app.disable('x-powered-by')

app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'img-src': ["'self'", 'data:', 'blob:', 'https:'],
      'font-src': ["'self'", 'https://fonts.gstatic.com', 'https://cdn.fontshare.com', 'data:'],
      'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://api.fontshare.com'],
      // Instagram: video Reel di halaman BKK & Magang Jepang
      'frame-src': ["'self'", 'https://www.google.com', 'https://maps.google.com', 'https://www.youtube.com', 'https://www.youtube-nocookie.com', 'https://www.instagram.com'],
      'connect-src': ["'self'"],
    },
  },
}))
app.use(cors({ origin: config.corsOrigin }))
app.use(compression())
app.use(express.json({ limit: '1mb' }))

app.get('/api/health', async (req, res) => {
  try {
    await db.raw('select 1')
    res.json({ ok: true, db: 'connected' })
  } catch (e) {
    res.status(500).json({ ok: false, db: 'error', error: e.message })
  }
})

app.use('/api/public', publicRoutes)
app.use('/api/auth', authRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint tidak ditemukan.' }))

// File unggahan
app.use('/uploads', express.static(config.uploadDir, { maxAge: '30d', fallthrough: false }))

// Frontend hasil build (npm run build) — satu server untuk situs + API
const dist = path.join(ROOT, 'dist')
if (fs.existsSync(path.join(dist, 'index.html'))) {
  app.use('/assets', express.static(path.join(dist, 'assets'), { maxAge: '1y', immutable: true }))
  app.use(express.static(dist, { maxAge: '1d', index: false }))
  // SPA fallback: semua GET selain /api diarahkan ke index.html (React Router)
  app.use((req, res, next) => {
    if (req.method !== 'GET' || req.path.startsWith('/api')) return next()
    res.setHeader('Cache-Control', 'no-cache')
    res.sendFile(path.join(dist, 'index.html'))
  })
}

// Penanganan error
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || (err.type === 'entity.parse.failed' ? 400 : 500)
  if (status >= 500) console.error(err)
  res.status(status).json({ error: status >= 500 ? 'Terjadi kesalahan pada server.' : err.message, details: err.details })
})

async function start() {
  console.log(`Database: ${config.db.client}`)
  await syncSchema()
  if (config.autoSeed) await seedDatabase()
  app.listen(config.port, () => console.log(`Server SMK INFOKOM berjalan di http://localhost:${config.port}`))
}

start().catch((err) => {
  console.error('Gagal menjalankan server:', err.message)
  process.exit(1)
})
