import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Saat development, permintaan /api dan /uploads diteruskan ke server Express (port 4000)
const API = process.env.API_PROXY || 'http://localhost:4000'

export default defineConfig({
  plugins: [react()],
  base: process.env.VITE_BASE || '/',
  build: {
    chunkSizeWarningLimit: 700,
    rollupOptions: {
      output: {
        manualChunks: { vendor: ['react', 'react-dom', 'react-router-dom'] },
      },
    },
  },
  server: {
    port: 5175,
    strictPort: true,
    proxy: {
      '/api': { target: API, changeOrigin: true },
      '/uploads': { target: API, changeOrigin: true },
    },
  },
})
