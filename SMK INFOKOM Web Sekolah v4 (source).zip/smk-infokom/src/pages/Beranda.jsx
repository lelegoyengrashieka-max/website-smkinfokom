import LandingHero from '../components/landing/LandingHero.jsx'
import LandingMarquee from '../components/landing/LandingMarquee.jsx'
import LandingAbout from '../components/landing/LandingAbout.jsx'
import LandingPrograms from '../components/landing/LandingPrograms.jsx'
import LandingFeatures from '../components/landing/LandingFeatures.jsx'
import LandingTestimonials from '../components/landing/LandingTestimonials.jsx'
import LandingNews from '../components/landing/LandingNews.jsx'
import LandingKarier from '../components/landing/LandingKarier.jsx'
import LandingCta from '../components/landing/LandingCta.jsx'

export default function Beranda() {
  return (
    <>
      <LandingHero />
      <LandingMarquee />
      <LandingAbout />
      <LandingPrograms />
      <LandingKarier />
      <LandingFeatures />
      <LandingTestimonials />
      <LandingNews limit={3} />
      <LandingCta />
    </>
  )
}
