import { Link, useParams } from 'react-router-dom'
import PageHero from '../components/PageHero.jsx'
import { usePublic, useList, useSettings, usePageTitle } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

export default function JurusanDetail() {
  const { slug } = useParams()
  const st = useSettings()
  const { data: program, loading } = usePublic(`jurusan/${slug}`)
  const { items: PROGRAMS } = useList('jurusan')
  usePageTitle(program?.nama || 'Jurusan')

  if (loading) return <PageHero eyebrow="JURUSAN" title="Memuat…" />

  if (!program) {
    return (
      <>
        <PageHero eyebrow="404" title="Jurusan tidak ditemukan." />
        <div className="container-page py-16">
          <Link to="/jurusan" className="btn-outline">
            Kembali ke daftar jurusan
          </Link>
        </div>
      </>
    )
  }

  return (
    <>
      <PageHero
        eyebrow={`JURUSAN / ${program.kode}`}
        title={program.nama}
        desc={program.tagline}
        image={assetUrl(program.gambar || '/images/hero/jurusan.jpg')}
      />

      {program.deskripsi && (
        <section className="bg-paper pt-20 md:pt-24">
          <div className="container-page">
            <p className="max-w-3xl text-[16.5px] leading-relaxed text-ink/75 whitespace-pre-line">{program.deskripsi}</p>
          </div>
        </section>
      )}

      <section className="bg-paper py-20 md:py-24">
        <div className="container-page grid md:grid-cols-[1fr_1.2fr] gap-14">
          <div>
            <p className="eyebrow-code mb-4">KOMPETENSI UTAMA</p>
            <ul className="space-y-3.5">
              {program.kompetensi.map((k) => (
                <li key={k} className="flex gap-3 text-[14.5px] text-ink/75 leading-relaxed">
                  <span className="text-amber mt-1.5 shrink-0">—</span>
                  {k}
                </li>
              ))}
            </ul>

            <p className="eyebrow-code mt-10 mb-4">PROSPEK KARIER</p>
            <ul className="flex flex-wrap gap-2">
              {program.karir.map((k) => (
                <li key={k} className="text-[12.5px] font-mono px-2.5 py-1 border border-hairline text-ink/70">
                  {k}
                </li>
              ))}
            </ul>

            <p className="eyebrow-code mt-10 mb-4">MITRA INDUSTRI</p>
            <ul className="space-y-2">
              {program.mitra.map((m) => (
                <li key={m} className="text-[14.5px] text-ink/75">
                  {m}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="eyebrow-code mb-4">MATA PELAJARAN PER TINGKAT</p>
            <div className="border border-hairline">
              {['X', 'XI', 'XII'].filter((t) => program[`mapel_${t.toLowerCase()}`]?.length).map((tingkat) => (
                <div key={tingkat} className="border-b border-hairline last:border-0 p-6">
                  <span className="font-mono text-teal text-[13px]">KELAS {tingkat}</span>
                  <ul className="mt-3 grid sm:grid-cols-2 gap-x-6 gap-y-2">
                    {program[`mapel_${tingkat.toLowerCase()}`].map((m) => (
                      <li key={m} className="text-[14px] text-ink/75">
                        {m}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div className="mt-10 border border-hairline p-7 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
              <p className="text-[15px] text-ink/75 max-w-xs">
                Tertarik dengan program {program.kode}? Kuota pendaftaran terbatas.
              </p>
              <Link to={st.ppdb_dibuka === 'false' ? '/ppdb' : `/ppdb/daftar?jurusan=${program.slug}`} className="btn-primary shrink-0">
                Daftar Sekarang
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-navy py-16 border-t border-navy-line">
        <div className="container-page flex flex-wrap items-center justify-between gap-6">
          <Link to="/jurusan" className="text-paper/70 text-[14.5px] hover:text-amber transition-colors inline-flex items-center gap-2">
            <svg width="14" height="10" viewBox="0 0 14 10" fill="none">
              <path d="M14 5 H1 M6 1 L1 5 L6 9" stroke="currentColor" strokeWidth="1.4" />
            </svg>
            Semua jurusan
          </Link>
          <div className="flex flex-wrap gap-3">
            {PROGRAMS.filter((p) => p.slug !== program.slug).map((p) => (
              <Link
                key={p.slug}
                to={`/jurusan/${p.slug}`}
                className="font-mono text-[12.5px] text-paper/70 border border-navy-line px-3 py-2 hover:border-amber hover:text-amber transition-colors"
              >
                {p.kode}
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
