import { Link } from 'react-router-dom'
import PageHero from '../components/PageHero.jsx'
import { useList, useSettings, lines, pairs, usePageTitle } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

export default function Hubinmas() {
  usePageTitle('Hubinmas')
  const st = useSettings()
  const { items: KEMITRAAN } = useList('mitra', { jenis: 'Industri' })
  const BKK = { desc: st.bkk_desc, stats: pairs(st.bkk_stats) }
  const PKL_INFO = { desc: st.pkl_desc, tahapan: lines(st.pkl_tahapan) }
  const TRACER_STUDY = { desc: st.tracer_desc, stats: pairs(st.tracer_stats) }
  return (
    <>
      <PageHero
        image="/images/hero/hubinmas.jpg"
        banner="hubinmas"
        eyebrow="PROGRAM SEKOLAH / HUBINMAS"
        title="Menjembatani sekolah dengan dunia kerja."
        desc="Bursa Kerja Khusus, Praktik Kerja Lapangan, kemitraan industri, dan pemantauan alumni."
      />

      <section id="bkk" className="bg-paper py-20 md:py-24 scroll-mt-24">
        <div className="container-page grid md:grid-cols-[1fr_1fr] gap-14 items-start">
          <div>
            <p className="eyebrow-code mb-4">BKK / KARIER</p>
            <h2 className="section-heading max-w-md mb-5">Bursa Kerja Khusus.</h2>
            <p className="text-[15px] text-ink/70 leading-relaxed max-w-md">{BKK.desc}</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/bkk" className="btn-primary">Buka Portal BKK</Link>
              <Link to="/magang-jepang" className="btn-outline">Magang ke Jepang</Link>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-px bg-hairline border border-hairline">
            {BKK.stats.map((s) => (
              <div key={s.label} className="bg-paper p-5 text-center">
                <p className="font-display text-2xl text-navy">{s.value}</p>
                <p className="mt-1.5 font-mono text-[10.5px] text-ink/50 leading-tight">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="pkl" className="bg-navy py-20 md:py-24 border-t border-navy-line scroll-mt-24">
        <div className="container-page grid md:grid-cols-[1fr_1fr] gap-14">
          <div>
            <p className="eyebrow-code text-amber mb-4">PKL</p>
            <h2 className="section-heading text-paper max-w-md mb-5">Praktik Kerja Lapangan.</h2>
            <p className="text-[15px] text-paper/65 leading-relaxed max-w-md">{PKL_INFO.desc}</p>
          </div>
          <ol className="space-y-4">
            {PKL_INFO.tahapan.map((t, i) => (
              <li key={i} className="flex gap-4 border-t border-navy-line pt-4">
                <span className="font-mono text-amber text-[13px] shrink-0">{String(i + 1).padStart(2, '0')}</span>
                <p className="text-[14.5px] text-paper/75 leading-relaxed">{t}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section id="kemitraan" className="bg-paper py-20 md:py-24 border-t border-hairline scroll-mt-24">
        <div className="container-page">
          <p className="eyebrow-code mb-4">INDUSTRI / KEMITRAAN</p>
          <h2 className="section-heading max-w-lg mb-10">Mitra yang membentuk kelas industri kami.</h2>
          <ul className="grid sm:grid-cols-2 gap-x-10 gap-y-4">
            {KEMITRAAN.map((k) => (
              <li key={k.id} className="flex items-center gap-4 text-[14.5px] text-ink/75 border-t border-hairline pt-4">
                {k.logo && <img src={assetUrl(k.logo)} alt={k.nama} loading="lazy" className="h-10 w-10 shrink-0 rounded-lg object-contain bg-white border border-hairline p-1" />}
                <span>
                  {k.website ? (
                    <a href={k.website} target="_blank" rel="noopener noreferrer" className="font-medium text-ink hover:text-teal">{k.nama}</a>
                  ) : (
                    <span className="font-medium text-ink">{k.nama}</span>
                  )}
                  {k.bidang && <span className="text-ink/55"> — {k.bidang}</span>}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section id="tracer-study" className="bg-navy py-20 md:py-24 border-t border-navy-line scroll-mt-24">
        <div className="container-page grid md:grid-cols-[1fr_1fr] gap-14 items-center">
          <div>
            <p className="eyebrow-code text-amber mb-4">TRACER STUDY</p>
            <h2 className="section-heading text-paper max-w-md mb-5">Ke mana lulusan kami melangkah.</h2>
            <p className="text-[15px] text-paper/65 leading-relaxed max-w-md">{TRACER_STUDY.desc}</p>
          </div>
          <div className="grid grid-cols-3 gap-px bg-navy-line border border-navy-line">
            {TRACER_STUDY.stats.map((s) => (
              <div key={s.label} className="bg-navy p-5 text-center">
                <p className="font-display text-2xl text-amber">{s.value}</p>
                <p className="mt-1.5 font-mono text-[10.5px] text-paper/50 leading-tight">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
