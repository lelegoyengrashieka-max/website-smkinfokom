import { Link } from 'react-router-dom'
import PageHero from '../components/PageHero.jsx'
import Fasilitas from '../components/Fasilitas.jsx'

import { usePageTitle } from '../lib/data.jsx'

export default function FasilitasPage() {
  usePageTitle('Sarana & Prasarana')
  return (
    <>
      <PageHero
        image="/images/hero/fasilitas.jpg"
        banner="fasilitas"
        eyebrow="FASILITAS"
        title="Ruang belajar yang menyerupai tempat kerja."
        desc="Laboratorium dan studio yang diperbarui berkala mengikuti standar perangkat industri."
      />
      <Fasilitas />
      <section className="bg-navy py-16 border-t border-navy-line">
        <div className="container-page flex flex-wrap items-center justify-between gap-6">
          <p className="text-paper/70 text-[15px] max-w-sm">
            Lihat suasana langsung ruang praktik dan kegiatan siswa di galeri foto sekolah.
          </p>
          <Link to="/galeri" className="btn-outline-light">
            Buka Galeri
          </Link>
        </div>
      </section>
    </>
  )
}
