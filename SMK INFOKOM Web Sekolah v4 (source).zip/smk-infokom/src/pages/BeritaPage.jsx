import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import PageHero from '../components/PageHero.jsx'
import { useList, useSettings, formatTanggal, usePageTitle } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

const KATEGORI = ['Semua', 'PENGUMUMAN', 'PRESTASI', 'AKADEMIK', 'KEMITRAAN', 'KEGIATAN']
const PER_PAGE = 9

export default function BeritaPage() {
  usePageTitle('Berita')
  const st = useSettings()
  const [params, setParams] = useSearchParams()
  const active = params.get('kategori') || 'Semua'
  const page = Number(params.get('page') || 1)
  const q = params.get('q') || ''
  const [term, setTerm] = useState(q)
  useEffect(() => setTerm(q), [q])

  const { items, pages, total, loading } = useList('berita', {
    kategori: active === 'Semua' ? undefined : active,
    q: q || undefined,
    page,
    limit: PER_PAGE,
  })

  const update = (patch) => {
    const next = new URLSearchParams(params)
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)))
    setParams(next)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <>
      <PageHero
        image="/images/hero/berita.jpg"
        banner="berita"
        eyebrow="BERITA & AGENDA"
        title="Kabar dan pencapaian terbaru."
        desc={`Ringkasan kegiatan, pengumuman, kemitraan, dan prestasi siswa serta guru ${st.nama_sekolah}.`}
      />

      <section className="bg-paper py-16 md:py-20">
        <div className="container-page">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-12 border-b border-hairline pb-8">
            <div className="flex flex-wrap gap-2">
              {KATEGORI.map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => update({ kategori: k === 'Semua' ? '' : k, page: '' })}
                  className={`px-4 py-2 text-[13.5px] font-medium border transition-colors ${
                    active === k ? 'bg-navy text-paper border-navy' : 'border-hairline text-ink/60 hover:border-navy/40'
                  }`}
                >
                  {k === 'Semua' ? k : k.charAt(0) + k.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
            <form
              onSubmit={(e) => { e.preventDefault(); update({ q: term.trim(), page: '' }) }}
              className="flex w-full lg:w-80"
              role="search"
            >
              <input
                type="search"
                value={term}
                onChange={(e) => setTerm(e.target.value)}
                placeholder="Cari berita…"
                aria-label="Cari berita"
                className="flex-1 border border-hairline bg-paper px-4 py-2.5 text-[14px] outline-none focus:border-navy"
              />
              <button type="submit" className="bg-navy px-4 text-[13.5px] font-medium text-paper hover:bg-navy-light">Cari</button>
            </form>
          </div>

          {q && <p className="mb-6 text-[14px] text-ink/60">{total} hasil untuk “{q}”</p>}
          {loading && <p className="text-ink/50">Memuat berita…</p>}
          {!loading && items.length === 0 && <p className="py-10 text-center text-ink/50">Belum ada berita pada kategori ini.</p>}

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((b) => (
              <article key={b.id} className="group bg-white border border-hairline flex flex-col overflow-hidden rounded-2xl shadow-card">
                <Link to={`/berita/${b.slug}`} className="block aspect-[16/10] overflow-hidden bg-mist">
                  {b.gambar && (
                    <img src={assetUrl(b.gambar)} alt={b.judul} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  )}
                </Link>
                <div className="p-7 flex flex-col flex-1">
                  <div className="flex items-center justify-between font-mono text-[12px] text-ink/45">
                    <span>{formatTanggal(b.tanggal, 'pendek')}</span>
                    <span className="text-teal">{b.kategori}</span>
                  </div>
                  <h3 className="font-display text-[1.1rem] leading-snug mt-4">
                    <Link to={`/berita/${b.slug}`} className="hover:text-teal transition-colors">{b.judul}</Link>
                  </h3>
                  <p className="mt-3 text-[14px] text-ink/60 leading-relaxed flex-1">{b.ringkasan}</p>
                  <Link to={`/berita/${b.slug}`} className="mt-5 text-[14px] font-medium text-navy border-b border-navy/30 self-start hover:border-navy">
                    Baca selengkapnya
                  </Link>
                </div>
              </article>
            ))}
          </div>

          {pages > 1 && (
            <nav className="mt-12 flex flex-wrap items-center justify-center gap-2" aria-label="Halaman">
              <button type="button" disabled={page <= 1} onClick={() => update({ page: String(page - 1) })} className="btn-outline disabled:opacity-40">Sebelumnya</button>
              {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => update({ page: n === 1 ? '' : String(n) })}
                  className={`h-10 w-10 border text-[14px] ${n === page ? 'bg-navy text-paper border-navy' : 'border-hairline text-ink/70 hover:border-navy/40'}`}
                >
                  {n}
                </button>
              ))}
              <button type="button" disabled={page >= pages} onClick={() => update({ page: String(page + 1) })} className="btn-outline disabled:opacity-40">Berikutnya</button>
            </nav>
          )}
        </div>
      </section>
    </>
  )
}
