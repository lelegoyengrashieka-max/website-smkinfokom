import { useCallback, useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import PageHero from '../components/PageHero.jsx'
import { useList, usePageTitle } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

const KATEGORI = ['Semua', 'Profil Sekolah', 'OSIS', 'PKL', 'Akademik', 'Industri', 'Ekstrakurikuler', 'Kegiatan']

export default function Galeri() {
  usePageTitle('Galeri')
  const [params, setParams] = useSearchParams()
  const fromUrl = params.get('kategori')
  const active = KATEGORI.includes(fromUrl) ? fromUrl : 'Semua'
  const { items, loading } = useList('galeri', { kategori: active === 'Semua' ? undefined : active, limit: 300 })
  const [open, setOpen] = useState(-1)

  const close = useCallback(() => setOpen(-1), [])
  const move = useCallback((d) => setOpen((i) => (i + d + items.length) % items.length), [items.length])

  useEffect(() => {
    if (open < 0) return undefined
    const onKey = (e) => {
      if (e.key === 'Escape') close()
      if (e.key === 'ArrowRight') move(1)
      if (e.key === 'ArrowLeft') move(-1)
    }
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [open, close, move])

  const current = items[open]

  return (
    <>
      <PageHero
        image="/images/hero/galeri.jpg"
        banner="galeri"
        eyebrow="GALERI"
        title="Suasana belajar dan kegiatan siswa."
        desc="Dokumentasi kegiatan sehari-hari, fasilitas, acara sekolah, dan ekstrakurikuler."
      />

      <section className="bg-paper py-16 md:py-20">
        <div className="container-page">
          <div className="flex flex-wrap gap-2 mb-12 border-b border-hairline pb-8">
            {KATEGORI.map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => setParams(k === 'Semua' ? {} : { kategori: k })}
                className={`px-4 py-2 text-[13.5px] font-medium border transition-colors ${
                  active === k ? 'bg-navy text-paper border-navy' : 'border-hairline text-ink/60 hover:border-navy/40'
                }`}
              >
                {k}
              </button>
            ))}
          </div>

          {loading && <p className="text-ink/50">Memuat galeri…</p>}
          {!loading && items.length === 0 && <p className="py-10 text-center text-ink/50">Belum ada foto pada kategori ini.</p>}

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((g, i) => (
              <figure key={g.id} className="group rounded-2xl overflow-hidden shadow-card hover:shadow-elegant hover:-translate-y-1 transition-all duration-300">
                <button type="button" onClick={() => setOpen(i)} className="relative block aspect-[4/3] w-full overflow-hidden" aria-label={`Perbesar foto ${g.judul}`}>
                  <img src={assetUrl(g.gambar)} alt={g.judul} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy/70 via-transparent to-transparent" />
                  <span className="absolute top-3 left-3 pill bg-navy/60 text-paper backdrop-blur-sm">{g.kategori}</span>
                </button>
                <figcaption className="p-4 text-[14.5px] text-ink/75 leading-snug bg-paper">{g.judul}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {current && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-ink/90 p-4" role="dialog" aria-modal="true" onClick={close}>
          <button type="button" onClick={close} className="absolute right-5 top-5 text-paper/80 hover:text-amber text-sm font-mono" aria-label="Tutup">TUTUP ✕</button>
          {items.length > 1 && (
            <>
              <button type="button" onClick={(e) => { e.stopPropagation(); move(-1) }} className="absolute left-3 md:left-8 h-12 w-12 rounded-full bg-paper/10 text-paper hover:bg-paper/20" aria-label="Sebelumnya">‹</button>
              <button type="button" onClick={(e) => { e.stopPropagation(); move(1) }} className="absolute right-3 md:right-8 h-12 w-12 rounded-full bg-paper/10 text-paper hover:bg-paper/20" aria-label="Berikutnya">›</button>
            </>
          )}
          <figure className="max-w-5xl" onClick={(e) => e.stopPropagation()}>
            <img src={assetUrl(current.gambar)} alt={current.judul} className="max-h-[80vh] w-auto mx-auto rounded-xl object-contain" />
            <figcaption className="mt-4 text-center text-paper/80 text-[14.5px]">
              {current.judul} <span className="text-paper/40">· {current.kategori} · {open + 1}/{items.length}</span>
            </figcaption>
          </figure>
        </div>
      )}
    </>
  )
}
