import PageHero from '../components/PageHero.jsx'
import JurusanSection from '../components/Jurusan.jsx'

import { usePageTitle } from '../lib/data.jsx'

export default function JurusanPage() {
  usePageTitle('Jurusan')
  return (
    <>
      <PageHero
        image="/images/hero/jurusan.jpg"
        banner="jurusan"
        eyebrow="PROGRAM KEAHLIAN"
        title="Program keahlian menuju karier teknologi."
        desc="Setiap program dirancang bersama industri dan dilengkapi kurikulum berbasis proyek nyata. Pilih satu untuk melihat detail kompetensi dan prospek kariernya."
      />
      <JurusanSection dark={false} showIntro={false} />
    </>
  )
}
