import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, MapPin, CalendarClock, Wallet, Users, Briefcase, Check, Share2 } from 'lucide-react'
import { usePublic, useList, usePageTitle, paragraphs, formatTanggal, useSettings } from '../../lib/data.jsx'
import { api, assetUrl } from '../../lib/api.js'
import LowonganCard, { LowonganStatus, isExpired } from '../../components/LowonganCard.jsx'
import { Input, Select, Textarea, Honeypot, Alert, Skeleton, EmptyState, useForm } from '../../components/ui/index.jsx'

const JURUSAN = ['RPL', 'TKJ', 'Multimedia', 'PSPT', 'Lainnya']
const asList = (v) => (Array.isArray(v) ? v : String(v || '').split('\n').map((x) => x.trim()).filter(Boolean))

function ApplyForm({ l }) {
  const init = { nama: '', email: '', telepon: '', jurusan: '', tahun_lulus: '', alamat: '', link_cv: '', pesan: '', website: '' }
  const [form, set] = useForm(init)
  const [st, setSt] = useState({ loading: false, error: '', details: {}, ok: '' })
  const years = Array.from({ length: 12 }, (_, i) => String(new Date().getFullYear() + 1 - i))
  const submit = async (e) => {
    e.preventDefault()
    setSt({ loading: true, error: '', details: {}, ok: '' })
    try {
      const r = await api('/api/public/lamaran', { method: 'POST', body: { ...form, lowongan_id: l.id } })
      setSt({ loading: false, error: '', details: {}, ok: r.message || 'Lamaran terkirim.' })
    } catch (err) {
      setSt({ loading: false, error: err.message, details: err.details || {}, ok: '' })
    }
  }
  if (st.ok) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-7">
        <Check className="h-8 w-8 text-emerald-600" />
        <p className="mt-3 font-display text-xl font-bold text-emerald-900">Lamaran terkirim</p>
        <p className="mt-2 text-[14.5px] text-emerald-800">{st.ok} Pantau WhatsApp dan email kamu untuk jadwal seleksi.</p>
      </div>
    )
  }
  const d = st.details
  return (
    <form onSubmit={submit} noValidate className="space-y-4">
      {st.error && <Alert>{st.error}</Alert>}
      <Input label="Nama lengkap" name="nama" value={form.nama} onChange={set} error={d.nama} required autoComplete="name" />
      <Input label="Email" name="email" type="email" value={form.email} onChange={set} error={d.email} required autoComplete="email" />
      <Input label="No. HP / WhatsApp" name="telepon" type="tel" value={form.telepon} onChange={set} error={d.telepon} required placeholder="08xxxxxxxxxx" />
      <div className="grid grid-cols-2 gap-4">
        <Select label="Jurusan" name="jurusan" value={form.jurusan} onChange={set} error={d.jurusan} options={JURUSAN} required />
        <Select label="Tahun lulus" name="tahun_lulus" value={form.tahun_lulus} onChange={set} error={d.tahun_lulus} options={years} required />
      </div>
      <Input label="Domisili" name="alamat" value={form.alamat} onChange={set} error={d.alamat} placeholder="Kota / kecamatan" />
      <Input label="Tautan CV / portofolio" name="link_cv" type="url" value={form.link_cv} onChange={set} error={d.link_cv} required placeholder="https://drive.google.com/…" hint="Pastikan akses tautan terbuka untuk umum." />
      <Textarea label="Pesan singkat" name="pesan" rows={3} value={form.pesan} onChange={set} error={d.pesan} />
      <Honeypot value={form.website} onChange={set} />
      <button type="submit" disabled={st.loading} className="btn-primary w-full">{st.loading ? 'Mengirim…' : 'Kirim Lamaran'}</button>
    </form>
  )
}

export default function LowonganDetail() {
  const { slug } = useParams()
  const settings = useSettings()
  const { data: l, loading, error } = usePublic(`lowongan/${slug}`)
  const { items: lain } = useList('lowongan', { status: 'dibuka', limit: 4 })
  usePageTitle(l ? `${l.judul} — ${l.perusahaan}` : 'Lowongan Kerja')

  if (loading) return <div className="container-page py-16"><Skeleton className="h-10 w-2/3" /><Skeleton className="mt-6 h-96" /></div>
  if (error || !l) return <div className="container-page py-20"><EmptyState title="Lowongan tidak ditemukan" desc="Lowongan mungkin sudah dihapus atau tautannya salah." action={<Link to="/bkk#lowongan" className="btn-dark">Kembali ke daftar lowongan</Link>} /></div>

  const closed = l.status !== 'dibuka' || isExpired(l)
  const kualifikasi = asList(l.kualifikasi)
  const benefit = asList(l.benefit)
  const others = lain.filter((x) => x.id !== l.id).slice(0, 3)
  const share = 'https://wa.me/?text=' + encodeURIComponent(`Lowongan ${l.judul} di ${l.perusahaan} — info BKK ${settings.nama_sekolah}: ${window.location.href}`)

  return (
    <>
      <section className="border-b border-line bg-surface">
        <div className="container-page py-10 md:py-14">
          <Link to="/bkk#lowongan" className="inline-flex items-center gap-2 text-[14px] font-semibold text-brand-600 hover:text-accent"><ArrowLeft className="h-4 w-4" />Semua lowongan</Link>
          <div className="mt-6 flex flex-col gap-6 md:flex-row md:items-center">
            {l.logo ? <img src={assetUrl(l.logo)} alt="" className="h-20 w-20 rounded-2xl border border-line bg-white object-contain p-2" />
              : <span className="flex h-20 w-20 items-center justify-center rounded-2xl bg-brand font-display text-2xl font-extrabold text-white"><Briefcase className="h-8 w-8" /></span>}
            <div className="flex-1">
              <p className="text-[15px] font-semibold text-muted">{l.perusahaan}</p>
              <h1 className="mt-1 font-display text-[2rem] font-extrabold leading-tight tracking-tight text-brand md:text-[2.7rem]">{l.judul}</h1>
              <div className="mt-3 flex flex-wrap items-center gap-2"><LowonganStatus l={l} /><span className="pill bg-brand-50 text-brand-600">{l.tipe}</span><span className="pill bg-white text-ink/70">{l.bidang}</span></div>
            </div>
          </div>
          <dl className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
            {[[MapPin, 'Lokasi', l.lokasi], [Wallet, 'Gaji', l.gaji || 'Dirahasiakan'], [CalendarClock, 'Batas lamaran', l.deadline ? formatTanggal(l.deadline) : '-'], [Users, 'Kuota', l.kuota ? `${l.kuota} orang` : '-']].map(([I, k, v]) => (
              <div key={k} className="rounded-2xl border border-line bg-white p-4">
                <dt className="flex items-center gap-2 text-[12.5px] font-semibold text-muted"><I className="h-4 w-4" />{k}</dt>
                <dd className="mt-1 text-[15px] font-semibold text-ink">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      <section className="bg-white py-14 md:py-20">
        <div className="container-page grid gap-12 lg:grid-cols-[1.3fr_0.7fr]">
          <article className="min-w-0">
            <h2 className="font-display text-2xl font-bold text-brand">Deskripsi pekerjaan</h2>
            <div className="mt-4 space-y-4 text-[16px] leading-relaxed text-ink/80">{paragraphs(l.deskripsi).map((p, i) => <p key={i}>{p}</p>)}</div>
            {kualifikasi.length > 0 && <>
              <h2 className="mt-10 font-display text-2xl font-bold text-brand">Kualifikasi</h2>
              <ul className="mt-4 space-y-3">{kualifikasi.map((k) => <li key={k} className="flex gap-3 text-[15.5px] text-ink/80"><Check className="mt-1 h-4 w-4 shrink-0 text-accent" strokeWidth={2.5} />{k}</li>)}</ul>
            </>}
            {benefit.length > 0 && <>
              <h2 className="mt-10 font-display text-2xl font-bold text-brand">Benefit</h2>
              <ul className="mt-4 grid gap-3 sm:grid-cols-2">{benefit.map((k) => <li key={k} className="rounded-xl bg-surface px-4 py-3 text-[15px] text-ink/80">{k}</li>)}</ul>
            </>}
            {l.cara_melamar && <div className="mt-10 rounded-2xl bg-brand-50 p-6"><p className="text-[12px] font-bold uppercase tracking-[0.12em] text-brand-600">Cara melamar</p><p className="mt-2 whitespace-pre-line text-[15px] leading-relaxed text-ink/80">{l.cara_melamar}</p></div>}
            <a href={share} target="_blank" rel="noopener noreferrer" className="btn-outline mt-10"><Share2 className="h-4 w-4" />Bagikan ke WhatsApp</a>
          </article>

          <aside className="lg:sticky lg:top-24 lg:self-start">
            <div className="rounded-2xl border border-line bg-white p-6 shadow-card md:p-7">
              <p className="font-display text-xl font-bold text-brand">{closed ? 'Lowongan ditutup' : 'Lamar lewat BKK'}</p>
              {closed ? (
                <p className="mt-2 text-[14.5px] text-muted">Lowongan ini sudah tidak menerima lamaran. Lihat lowongan lain yang masih dibuka.</p>
              ) : (
                <><p className="mt-1 mb-5 text-[14px] text-muted">Lamaran diteruskan ke perusahaan setelah diverifikasi tim BKK.</p><ApplyForm l={l} /></>
              )}
            </div>
          </aside>
        </div>
      </section>

      {others.length > 0 && (
        <section className="bg-surface py-14 md:py-20">
          <div className="container-page">
            <h2 className="font-display text-2xl font-bold text-brand">Lowongan lainnya</h2>
            <div className="mt-6 grid gap-5 md:grid-cols-3">{others.map((o) => <LowonganCard key={o.id} l={o} />)}</div>
          </div>
        </section>
      )}
    </>
  )
}
