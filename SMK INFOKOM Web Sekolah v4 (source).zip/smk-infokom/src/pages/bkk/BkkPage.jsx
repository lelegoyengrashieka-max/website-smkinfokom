import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Search, ShieldCheck, Clock, UserRound, ArrowRight } from 'lucide-react'
import PageHero from '../../components/PageHero.jsx'
import LowonganCard, { isExpired } from '../../components/LowonganCard.jsx'
import { Section, SectionHeader, StatRow, Steps, FaqList, Skeleton, EmptyState } from '../../components/ui/index.jsx'
import { useSettings, useList, pairs, usePageTitle } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'
import AlumniForm from './AlumniForm.jsx'
import InstagramVideos from '../../components/InstagramVideos.jsx'

const TIPE = ['Semua', 'Penuh Waktu', 'Kontrak', 'Magang', 'Paruh Waktu']
const BIDANG = ['Semua bidang', 'Perangkat Lunak', 'Jaringan & IT Support', 'Multimedia & Desain', 'Broadcasting', 'Administrasi', 'Lainnya']

export default function BkkPage() {
  usePageTitle('Bursa Kerja Khusus (BKK)')
  const st = useSettings()
  const { items: lowongan, loading } = useList('lowongan', { limit: 100 })
  const { items: mitra } = useList('mitra', { jenis: 'Rekrutmen BKK', limit: 60 })
  const { items: faq } = useList('faq', { kategori: 'BKK' })
  const [tipe, setTipe] = useState('Semua')
  const [bidang, setBidang] = useState('Semua bidang')
  const [q, setQ] = useState('')
  const [tampilTutup, setTampilTutup] = useState(false)

  const filtered = useMemo(() => lowongan.filter((l) => {
    if (tipe !== 'Semua' && l.tipe !== tipe) return false
    if (bidang !== 'Semua bidang' && l.bidang !== bidang) return false
    if (!tampilTutup && (l.status !== 'dibuka' || isExpired(l))) return false
    const s = q.trim().toLowerCase()
    return !s || [l.judul, l.perusahaan, l.lokasi].join(' ').toLowerCase().includes(s)
  }), [lowongan, tipe, bidang, q, tampilTutup])
  const aktif = lowongan.filter((l) => l.status === 'dibuka' && !isExpired(l)).length

  const layanan = pairs(st.bkk_layanan)
  const stats = pairs(st.bkk_stats_full)
  const alur = pairs(st.bkk_alur)
  const pengurus = pairs(st.bkk_pengurus)

  return (
    <>
      <PageHero banner="bkk" image="/images/hero/bkk.jpg" eyebrow="Bursa Kerja Khusus" crumbs={[{ label: 'BKK' }]}
        title={st.bkk_heading || 'Bursa Kerja Khusus'} desc="Lowongan terverifikasi, rekrutmen di sekolah, dan pendampingan karier — gratis untuk siswa kelas XII dan alumni.">
        <a href="#lowongan" className="btn-primary">Lihat {aktif || ''} Lowongan Aktif <ArrowRight className="h-4 w-4" /></a>
        <a href="#registrasi" className="btn-outline-light">Registrasi Alumni</a>
      </PageHero>

      {/* Intro */}
      <Section>
        <div className="grid gap-12 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <p className="eyebrow">Tentang BKK</p>
            <h2 className="section-heading mt-3">Unit resmi sekolah yang menjembatani lulusan dengan dunia kerja.</h2>
            <p className="mt-5 text-[16.5px] leading-relaxed text-muted">{st.bkk_intro}</p>
            <ul className="mt-8 grid gap-4 sm:grid-cols-3">
              {st.bkk_izin && <li className="rounded-2xl bg-surface p-5"><ShieldCheck className="h-5 w-5 text-brand-600" /><p className="mt-3 text-[12px] font-bold uppercase tracking-[0.12em] text-muted">Izin Disnaker</p><p className="mt-1 text-[14px] font-semibold text-ink break-all">{st.bkk_izin}</p></li>}
              {st.bkk_ketua && <li className="rounded-2xl bg-surface p-5"><UserRound className="h-5 w-5 text-brand-600" /><p className="mt-3 text-[12px] font-bold uppercase tracking-[0.12em] text-muted">Ketua BKK</p><p className="mt-1 text-[14px] font-semibold text-ink">{st.bkk_ketua}</p></li>}
              {st.bkk_jam && <li className="rounded-2xl bg-surface p-5"><Clock className="h-5 w-5 text-brand-600" /><p className="mt-3 text-[12px] font-bold uppercase tracking-[0.12em] text-muted">Jam Layanan</p><p className="mt-1 text-[14px] font-semibold text-ink">{st.bkk_jam}</p></li>}
            </ul>
          </div>
          <div className="aspect-[4/5] overflow-hidden rounded-2xl lg:aspect-auto">
            <img src={assetUrl(st.bkk_image || '/images/hero/bkk.jpg')} alt="Kegiatan rekrutmen di BKK" loading="lazy" className="h-full w-full object-cover" />
          </div>
        </div>
        {stats.length > 0 && <div className="mt-16"><StatRow items={stats} /></div>}
      </Section>

      {/* Layanan */}
      {layanan.length > 0 && (
        <Section tone="surface">
          <SectionHeader eyebrow="Layanan" title="Apa saja yang bisa dibantu BKK?" />
          <div className="grid gap-px overflow-hidden rounded-2xl border border-line bg-line md:grid-cols-2 lg:grid-cols-3">
            {layanan.map((l, i) => (
              <div key={l.label} className="bg-white p-7 md:p-8">
                <p className="font-display text-[15px] font-extrabold text-accent tabular-nums">{String(i + 1).padStart(2, '0')}</p>
                <h3 className="mt-3 font-display text-[1.25rem] font-bold text-brand">{l.label}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-muted">{l.value}</p>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Lowongan */}
      <Section id="lowongan" className="scroll-mt-20">
        <SectionHeader eyebrow="Lowongan Kerja" title="Temukan pekerjaan yang cocok dengan keahlianmu." desc={`${aktif} lowongan aktif dari perusahaan mitra. Semua lowongan telah diverifikasi tim BKK.`} />
        <div className="mb-8 flex flex-col gap-4 rounded-2xl border border-line bg-surface p-4 lg:flex-row lg:items-center">
          <label className="relative flex-1">
            <span className="sr-only">Cari lowongan</span>
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari posisi, perusahaan, atau lokasi…" className="field-input !pl-11" />
          </label>
          <select value={bidang} onChange={(e) => setBidang(e.target.value)} className="field-input lg:!w-60" aria-label="Filter bidang">
            {BIDANG.map((b) => <option key={b}>{b}</option>)}
          </select>
          <label className="flex items-center gap-2 whitespace-nowrap text-[14px] font-medium text-ink/80">
            <input type="checkbox" checked={tampilTutup} onChange={(e) => setTampilTutup(e.target.checked)} className="h-4 w-4 rounded accent-brand" />
            Tampilkan yang ditutup
          </label>
        </div>
        <div className="mb-8 flex flex-wrap gap-2" role="tablist" aria-label="Tipe pekerjaan">
          {TIPE.map((t) => (
            <button key={t} type="button" role="tab" aria-selected={tipe === t} onClick={() => setTipe(t)}
              className={`rounded-full px-4 py-2 text-[14px] font-semibold transition-colors ${tipe === t ? 'bg-brand text-white' : 'border border-line bg-white text-ink/75 hover:border-brand/40'}`}>{t}</button>
          ))}
        </div>
        {loading ? (
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-60" />)}</div>
        ) : filtered.length === 0 ? (
          <EmptyState title="Belum ada lowongan yang cocok" desc="Coba ubah filter atau kata kunci. Lowongan baru ditambahkan setiap minggu." />
        ) : (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">{filtered.map((l) => <LowonganCard key={l.id} l={l} />)}</div>
        )}
      </Section>

      {/* Alur */}
      {alur.length > 0 && (
        <Section tone="brand">
          <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr]">
            <div>
              <p className="eyebrow !text-[#D4EE4E]">Alur Melamar</p>
              <h2 className="section-heading mt-3 !text-white">Lima langkah dari registrasi sampai diterima kerja.</h2>
              <p className="mt-5 max-w-md text-[16px] leading-relaxed text-white/70">BKK mendampingi di setiap tahap, termasuk pelatihan CV dan simulasi wawancara sebelum seleksi.</p>
            </div>
            <Steps items={alur} light />
          </div>
        </Section>
      )}

      {/* Video Instagram */}
      <InstagramVideos resource="video_bkk" eyebrow="Video Kegiatan BKK"
        title="Job fair, rekrutmen, dan cerita alumni — langsung dari Instagram."
        desc="Tonton dokumentasi kegiatan Bursa Kerja Khusus tanpa perlu keluar dari halaman ini." />

      {/* Mitra + pengurus */}
      <Section>
        <div className="grid gap-14 lg:grid-cols-[1.3fr_0.7fr]">
          <div>
            <SectionHeader eyebrow="Mitra Rekrutmen" title="Perusahaan yang rutin merekrut lulusan kami." className="!mb-8" />
            {mitra.length === 0 ? <p className="text-muted">Data mitra segera diperbarui.</p> : (
              <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {mitra.map((m) => (
                  <li key={m.id} className="flex min-h-[88px] flex-col justify-center rounded-2xl border border-line bg-white px-5 py-4">
                    {m.logo ? <img src={assetUrl(m.logo)} alt={m.nama} className="h-8 object-contain object-left" /> : <p className="font-display text-[15.5px] font-bold leading-tight text-brand">{m.nama}</p>}
                    {m.bidang && <p className="mt-1 line-clamp-2 text-[12.5px] text-muted">{m.bidang}</p>}
                  </li>
                ))}
              </ul>
            )}
          </div>
          {pengurus.length > 0 && (
            <div>
              <p className="eyebrow">Pengurus</p>
              <h3 className="mt-3 font-display text-[1.6rem] font-extrabold text-brand">Tim BKK</h3>
              <ul className="mt-6 divide-y divide-line rounded-2xl border border-line">
                {pengurus.map((p) => (
                  <li key={p.label} className="px-5 py-4">
                    <p className="text-[12.5px] font-semibold uppercase tracking-[0.1em] text-muted">{p.label}</p>
                    <p className="mt-1 text-[15px] font-semibold text-ink">{p.value}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </Section>

      {/* Registrasi */}
      <Section id="registrasi" tone="surface" className="scroll-mt-20">
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
          <div>
            <p className="eyebrow">Registrasi Alumni & Tracer Study</p>
            <h2 className="section-heading mt-3">Sudah lulus? Daftarkan dirimu di BKK.</h2>
            <p className="mt-5 text-[16px] leading-relaxed text-muted">Alumni yang terdaftar mendapat info lowongan lebih dulu lewat WhatsApp, undangan job fair, dan rekomendasi langsung ke perusahaan mitra. Data ini juga dipakai untuk tracer study sekolah.</p>
            <p className="mt-6 text-[14.5px] text-muted">Ingin magang ke luar negeri? <Link to="/magang-jepang" className="link-arrow">Lihat program Magang Jepang</Link></p>
          </div>
          <AlumniForm />
        </div>
      </Section>

      {faq.length > 0 && (
        <Section>
          <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
            <SectionHeader eyebrow="FAQ" title="Pertanyaan seputar BKK" desc="Belum terjawab? Datang ke ruang BKK atau hubungi kami lewat WhatsApp." />
            <FaqList items={faq} />
          </div>
        </Section>
      )}
    </>
  )
}
