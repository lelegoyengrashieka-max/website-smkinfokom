import { useState } from 'react'
import { api } from '../../lib/api.js'
import { Input, Select, Textarea, Honeypot, Alert, useForm } from '../../components/ui/index.jsx'

const JURUSAN = ['RPL', 'TKJ', 'Multimedia', 'PSPT', 'Lainnya']
const STATUS = ['Bekerja', 'Kuliah', 'Wirausaha', 'Kuliah & Bekerja', 'Magang Luar Negeri', 'Mencari Kerja']
const init = { nama: '', jurusan: '', tahun_lulus: '', telepon: '', email: '', status_kini: '', instansi: '', jabatan: '', kesesuaian: '', pendapatan: '', saran: '', website: '' }

export default function AlumniForm() {
  const [form, set, setForm] = useForm(init)
  const [st, setSt] = useState({ loading: false, error: '', details: {}, ok: '' })
  const submit = async (e) => {
    e.preventDefault()
    setSt({ loading: true, error: '', details: {}, ok: '' })
    try {
      const r = await api('/api/public/alumni', { method: 'POST', body: form })
      setSt({ loading: false, error: '', details: {}, ok: r.message || 'Data terkirim.' })
      setForm(init)
    } catch (err) {
      setSt({ loading: false, error: err.message, details: err.details || {}, ok: '' })
    }
  }
  const d = st.details
  const bekerja = form.status_kini && form.status_kini !== 'Mencari Kerja'
  const years = Array.from({ length: 12 }, (_, i) => String(new Date().getFullYear() - i))
  return (
    <form onSubmit={submit} noValidate className="rounded-2xl border border-line bg-white p-6 md:p-9">
      {st.ok && <div className="mb-6"><Alert tone="ok">{st.ok}</Alert></div>}
      {st.error && <div className="mb-6"><Alert>{st.error}</Alert></div>}
      <div className="grid gap-5 sm:grid-cols-2">
        <Input className="sm:col-span-2" label="Nama lengkap" name="nama" value={form.nama} onChange={set} error={d.nama} required autoComplete="name" />
        <Select label="Jurusan" name="jurusan" value={form.jurusan} onChange={set} error={d.jurusan} options={JURUSAN} required />
        <Select label="Tahun lulus" name="tahun_lulus" value={form.tahun_lulus} onChange={set} error={d.tahun_lulus} options={years} required />
        <Input label="No. HP / WhatsApp" name="telepon" type="tel" inputMode="tel" value={form.telepon} onChange={set} error={d.telepon} required placeholder="08xxxxxxxxxx" />
        <Input label="Email" name="email" type="email" value={form.email} onChange={set} error={d.email} placeholder="nama@email.com" />
        <Select className="sm:col-span-2" label="Status saat ini" name="status_kini" value={form.status_kini} onChange={set} error={d.status_kini} options={STATUS} required />
        {bekerja && <>
          <Input label="Instansi / kampus / usaha" name="instansi" value={form.instansi} onChange={set} error={d.instansi} />
          <Input label="Jabatan / program studi" name="jabatan" value={form.jabatan} onChange={set} error={d.jabatan} />
          <Select label="Kesesuaian dengan jurusan" name="kesesuaian" value={form.kesesuaian} onChange={set} options={['Sangat sesuai', 'Sesuai', 'Kurang sesuai', 'Tidak sesuai']} />
          <Select label="Pendapatan per bulan" name="pendapatan" value={form.pendapatan} onChange={set} options={['< Rp 3 juta', 'Rp 3 – 5 juta', 'Rp 5 – 8 juta', '> Rp 8 juta', 'Belum berpenghasilan']} />
        </>}
        <Textarea className="sm:col-span-2" label="Saran untuk sekolah" name="saran" rows={3} value={form.saran} onChange={set} error={d.saran} />
      </div>
      <Honeypot value={form.website} onChange={set} />
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4">
        <p className="max-w-sm text-[13px] text-muted">Data hanya dipakai BKK untuk penyaluran kerja dan laporan tracer study.</p>
        <button type="submit" disabled={st.loading} className="btn-primary">{st.loading ? 'Mengirim…' : 'Kirim Data Alumni'}</button>
      </div>
    </form>
  )
}
