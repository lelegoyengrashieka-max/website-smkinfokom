import { Link, useParams } from 'react-router-dom'
import PageHero from '../components/PageHero.jsx'
import { usePublic, useList, paragraphs, formatTanggal, usePageTitle } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

export default function BeritaDetail() {
  const { slug } = useParams()
  const { data: artikel, loading } = usePublic(`berita/${slug}`)
  const { items: lainnya } = useList('berita', { limit: 3, exclude: slug })
  usePageTitle(artikel?.judul || 'Berita')

  if (loading) return <PageHero eyebrow="BERITA" title="Memuat…" />

  if (!artikel) {
    return (
      <>
        <PageHero eyebrow="404" title="Berita tidak ditemukan." />
        <div className="container-page py-16">
          <Link to="/berita" className="btn-outline">Kembali ke daftar berita</Link>
        </div>
      </>
    )
  }

  const share = typeof window !== 'undefined' ? window.location.href : ''

  return (
    <>
      <PageHero eyebrow={`${artikel.kategori} · ${formatTanggal(artikel.tanggal)}`} title={artikel.judul} image="/images/hero/berita.jpg" banner="berita" />

      <article className="bg-paper py-16 md:py-20">
        <div className="container-page max-w-3xl">
          {artikel.gambar && (
            <img src={assetUrl(artikel.gambar)} alt={artikel.judul} className="mb-10 w-full rounded-2xl object-cover shadow-card aspect-[16/9]" />
          )}
          <div className="mb-8 flex flex-wrap items-center gap-x-6 gap-y-2 font-mono text-[12.5px] text-ink/50">
            <span>{formatTanggal(artikel.tanggal)}</span>
            {artikel.penulis && <span>Oleh {artikel.penulis}</span>}
            <span className="text-teal">{artikel.kategori}</span>
          </div>
          {artikel.ringkasan && <p className="mb-8 text-[17px] font-medium leading-relaxed text-ink/80">{artikel.ringkasan}</p>}
          {paragraphs(artikel.isi).map((p, i) => (
            <p key={i} className="text-[15.5px] text-ink/75 leading-[1.8] mb-6 whitespace-pre-line">{p}</p>
          ))}

          <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-hairline pt-6">
            <Link to="/berita" className="btn-outline">Kembali ke daftar berita</Link>
            <div className="flex items-center gap-3 text-[13.5px] text-ink/60">
              Bagikan:
              <a className="hover:text-teal" href={`https://wa.me/?text=${encodeURIComponent(`${artikel.judul} ${share}`)}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>
              <a className="hover:text-teal" href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(share)}`} target="_blank" rel="noopener noreferrer">Facebook</a>
            </div>
          </div>
        </div>
      </article>

      {lainnya.length > 0 && (
        <section className="bg-navy py-20 border-t border-navy-line">
          <div className="container-page">
            <p className="eyebrow-code text-amber mb-8">BERITA LAINNYA</p>
            <div className="grid md:grid-cols-3 gap-8">
              {lainnya.map((b) => (
                <Link key={b.id} to={`/berita/${b.slug}`} className="block group">
                  {b.gambar && <img src={assetUrl(b.gambar)} alt="" loading="lazy" className="mb-4 aspect-[16/10] w-full rounded-xl object-cover opacity-90 group-hover:opacity-100" />}
                  <span className="font-mono text-[12px] text-paper/40">{formatTanggal(b.tanggal, 'pendek')}</span>
                  <h3 className="font-display text-paper text-[1.05rem] leading-snug mt-2 group-hover:text-amber transition-colors">{b.judul}</h3>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  )
}
