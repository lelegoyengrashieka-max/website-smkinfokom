import { useState } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle2, Printer } from 'lucide-react'
import PageHero from '../../components/PageHero.jsx'
import { FormCard, Input, Select, Textarea, Honeypot, Alert, EmptyState, useForm } from '../../components/ui/index.jsx'
import { api } from '../../lib/api.js'
import { useSettings, useList, lines, usePageTitle } from '../../lib/data.jsx'

const JURUSAN = ['RPL', 'TKJ', 'Multimedia', 'PSPT', 'Lainnya']
const BAHASA = ['Belum pernah belajar', 'Dasar (kana)', 'Setara N5', 'Setara N4', 'N3 ke atas']
const SEHAT = ['Sehat, tidak ada riwayat penyakit', 'Memakai kacamata', 'Ada riwayat penyakit (jelaskan di motivasi)']
const init = { nama: '', jenis_kelamin: '', tanggal_lahir: '', tinggi_badan: '', berat_badan: '', status_peserta: '', jurusan: '', tahun_lulus: '', telepon: '', email: '', alamat: '', bidang_minat: '', level_bahasa: '', kesehatan: '', motivasi: '', website: '' }

export default function MagangDaftar() {
  usePageTitle('Pendaftaran Magang ke Jepang')
  const st = useSettings()
  const { items: bidang } = useList('magang_bidang')
  const [form, set] = useForm(init)
  const [setuju, setSetuju] = useState(false)
  const [s, setS] = useState({ loading: false, error: '', details: {}, result: null })
  const dibuka = st.magang_dibuka !== 'false'
  const years = Array.from({ length: 5 }, (_, i) => String(new Date().getFullYear() + 1 - i))

  const submit = async (e) => {
    e.preventDefault()
    if (!setuju) return setS((x) => ({ ...x, error: 'Centang pernyataan persetujuan orang tua dan kebenaran data.' }))
    setS({ loading: true, error: '', details: {}, result: null })
    try {
      const body = { ...form, tinggi_badan: Number(form.tinggi_badan) || 0, berat_badan: Number(form.berat_badan) || 0 }
      const result = await api('/api/public/pendaftaran-magang', { method: 'POST', body })
      setS({ loading: false, error: '', details: {}, result })
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } catch (err) {
      setS({ loading: false, error: err.message, details: err.details || {}, result: null })
      window.scrollTo({ top: 300, behavior: 'smooth' })
    }
  }
  const d = s.details

  return (
    <>
      <PageHero banner="magang" image="/images/hero/magang-jepang.jpg" eyebrow="Magang ke Jepang" crumbs={[{ label: 'Magang Jepang', to: '/magang-jepang' }, { label: 'Pendaftaran' }]}
        title="Formulir pendaftaran seleksi magang Jepang." desc={st.magang_angkatan ? `${st.magang_angkatan}. Isi data dengan jujur — data fisik dan kesehatan diverifikasi saat tes.` : ''} />

      <section className="bg-surface py-14 md:py-20">
        <div className="container-page grid gap-10 lg:grid-cols-[1fr_320px]">
          <div className="min-w-0">
            {!dibuka ? (
              <EmptyState title="Pendaftaran sedang ditutup" desc="Pendaftaran angkatan berikutnya akan diumumkan di halaman berita dan media sosial sekolah." action={<Link to="/magang-jepang" className="btn-dark">Kembali ke program</Link>} />
            ) : s.result ? (
              <div className="rounded-2xl border border-line bg-white p-8 text-center md:p-12">
                <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" />
                <p className="mt-4 font-display text-2xl font-extrabold text-brand md:text-3xl">Pendaftaran berhasil, {s.result.nama}.</p>
                <p className="mt-6 text-[14.5px] text-muted">Nomor pendaftaran kamu</p>
                <p className="mt-2 font-code text-3xl font-semibold tracking-wider text-brand md:text-4xl">{s.result.nomor}</p>
                <p className="mx-auto mt-6 max-w-lg whitespace-pre-line text-[15px] leading-relaxed text-muted">{st.magang_pesan_sukses}</p>
                <div className="mt-8 flex flex-wrap justify-center gap-3">
                  <button type="button" onClick={() => window.print()} className="btn-outline"><Printer className="h-4 w-4" />Cetak Bukti</button>
                  <Link to="/magang-jepang/cek-status" className="btn-primary">Cek Status Seleksi</Link>
                </div>
              </div>
            ) : (
              <form onSubmit={submit} noValidate className="space-y-6">
                {s.error && <Alert>{s.error}</Alert>}
                <FormCard title="Data diri" desc="Sesuai KTP / akta kelahiran.">
                  <Input className="sm:col-span-2" label="Nama lengkap" name="nama" value={form.nama} onChange={set} error={d.nama} required autoComplete="name" />
                  <Select label="Jenis kelamin" name="jenis_kelamin" value={form.jenis_kelamin} onChange={set} error={d.jenis_kelamin} options={[['L', 'Laki-laki'], ['P', 'Perempuan']]} required />
                  <Input label="Tanggal lahir" name="tanggal_lahir" type="date" value={form.tanggal_lahir} onChange={set} error={d.tanggal_lahir} required hint="Usia 17 — 27 tahun" />
                  <Input label="Tinggi badan (cm)" name="tinggi_badan" type="number" inputMode="numeric" min="120" max="220" value={form.tinggi_badan} onChange={set} error={d.tinggi_badan} />
                  <Input label="Berat badan (kg)" name="berat_badan" type="number" inputMode="numeric" min="30" max="150" value={form.berat_badan} onChange={set} error={d.berat_badan} />
                  <Select className="sm:col-span-2" label="Riwayat kesehatan" name="kesehatan" value={form.kesehatan} onChange={set} error={d.kesehatan} options={SEHAT} />
                </FormCard>
                <FormCard title="Pendidikan">
                  <Select label="Status peserta" name="status_peserta" value={form.status_peserta} onChange={set} error={d.status_peserta} options={['Siswa kelas XII', 'Alumni']} required />
                  <Select label="Jurusan" name="jurusan" value={form.jurusan} onChange={set} error={d.jurusan} options={JURUSAN} required />
                  <Select label="Tahun lulus" name="tahun_lulus" value={form.tahun_lulus} onChange={set} error={d.tahun_lulus} options={years} hint="Siswa kelas XII: perkiraan tahun lulus" />
                  <Select label="Kemampuan bahasa Jepang" name="level_bahasa" value={form.level_bahasa} onChange={set} error={d.level_bahasa} options={BAHASA} />
                </FormCard>
                <FormCard title="Kontak">
                  <Input label="No. HP / WhatsApp" name="telepon" type="tel" value={form.telepon} onChange={set} error={d.telepon} required placeholder="08xxxxxxxxxx" />
                  <Input label="Email" name="email" type="email" value={form.email} onChange={set} error={d.email} />
                  <Textarea className="sm:col-span-2" label="Alamat lengkap" name="alamat" rows={3} value={form.alamat} onChange={set} error={d.alamat} required />
                </FormCard>
                <FormCard title="Minat & motivasi">
                  <Select className="sm:col-span-2" label="Bidang kerja yang diminati" name="bidang_minat" value={form.bidang_minat} onChange={set} error={d.bidang_minat} options={[...bidang.map((b) => b.nama), 'Belum menentukan']} required />
                  <Textarea className="sm:col-span-2" label="Motivasi mengikuti program" name="motivasi" rows={5} value={form.motivasi} onChange={set} error={d.motivasi} required hint="Ceritakan tujuanmu ke Jepang dan rencana setelah kembali." />
                </FormCard>
                <Honeypot value={form.website} onChange={set} />
                <label className="flex items-start gap-3 rounded-2xl border border-line bg-white p-5 text-[14.5px] leading-relaxed text-ink/80">
                  <input type="checkbox" checked={setuju} onChange={(e) => setSetuju(e.target.checked)} className="mt-1 h-4 w-4 shrink-0 accent-brand" />
                  Saya menyatakan data di atas benar, sudah mendapat izin orang tua/wali, dan bersedia mengikuti seluruh tahapan seleksi serta pelatihan.
                </label>
                <div className="flex justify-end"><button type="submit" disabled={s.loading} className="btn-primary min-w-[220px]">{s.loading ? 'Mengirim…' : 'Kirim Pendaftaran'}</button></div>
              </form>
            )}
          </div>
          <aside className="space-y-5 lg:sticky lg:top-24 lg:self-start">
            <div className="rounded-2xl border border-line bg-white p-6">
              <p className="font-display text-lg font-bold text-brand">Persyaratan singkat</p>
              <ul className="mt-4 space-y-2.5 text-[14px] leading-relaxed text-muted">{lines(st.magang_syarat).slice(0, 5).map((x) => <li key={x} className="flex gap-2"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />{x}</li>)}</ul>
              <Link to="/magang-jepang" className="link-arrow mt-4 text-[14px]">Detail program</Link>
            </div>
            <div className="rounded-2xl bg-brand p-6 text-white">
              <p className="font-display text-lg font-bold">Sudah mendaftar?</p>
              <p className="mt-1.5 text-[14px] text-white/70">Pantau tahap seleksi dengan nomor pendaftaran dan tanggal lahir.</p>
              <Link to="/magang-jepang/cek-status" className="btn-outline-light mt-4 !py-2.5">Cek Status</Link>
            </div>
          </aside>
        </div>
      </section>
    </>
  )
}
