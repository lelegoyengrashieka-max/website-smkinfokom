import { Link } from 'react-router-dom'
import { ArrowRight, Check, FileText, Clock, Banknote, Info, ShieldCheck, MapPin } from 'lucide-react'
import PageHero from '../../components/PageHero.jsx'
import { Section, SectionHeader, StatRow, Steps, FaqList, Skeleton } from '../../components/ui/index.jsx'
import { useSettings, useList, pairs, lines, usePageTitle } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'
import { VideoPlayer } from '../../components/Media.jsx'
import InstagramVideos from '../../components/InstagramVideos.jsx'

const asList = (v) => (Array.isArray(v) ? v : String(v || '').split('\n').map((x) => x.trim()).filter(Boolean))
const initials = (n = '') => n.split(' ').map((w) => w[0]).slice(0, 2).join('')

export default function MagangPage() {
  usePageTitle('Magang ke Jepang')
  const st = useSettings()
  const dibuka = st.magang_dibuka !== 'false'
  const { items: bidang, loading } = useList('magang_bidang')
  const { items: alumni } = useList('magang_alumni')
  const { items: mitra } = useList('mitra', { jenis: 'Mitra Jepang', limit: 40 })
  const { items: faq } = useList('faq', { kategori: 'Magang Jepang' })
  const stats = pairs(st.magang_stats)
  const keunggulan = pairs(st.magang_keunggulan)
  const syarat = lines(st.magang_syarat)
  const dokumen = lines(st.magang_dokumen)
  const alur = pairs(st.magang_alur)
  const pelatihan = pairs(st.magang_pelatihan)
  const biaya = pairs(st.magang_biaya)
  const lpk = lines(st.magang_mitra_lpk)

  return (
    <>
      <PageHero banner="magang" image={st.magang_image || '/images/hero/magang-jepang.jpg'} video={st.magang_hero_video} eyebrow="Magang ke Jepang · 日本研修" crumbs={[{ label: 'Magang ke Jepang' }]}
        title={st.magang_heading || 'Program Magang ke Jepang'} desc={st.magang_angkatan ? `Pendaftaran ${dibuka ? 'dibuka' : 'ditutup'} — ${st.magang_angkatan}.` : ''}>
        {dibuka ? <Link to="/magang-jepang/daftar" className="btn-primary">Daftar Seleksi <ArrowRight className="h-4 w-4" /></Link>
          : <span className="btn-outline-light pointer-events-none opacity-70">Pendaftaran ditutup</span>}
        <Link to="/magang-jepang/cek-status" className="btn-outline-light">Cek Status Seleksi</Link>
      </PageHero>

      {/* Intro */}
      <Section>
        <div className="grid gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-start">
          <div>
            <p className="eyebrow">Tentang Program</p>
            <h2 className="section-heading mt-3">Jalur resmi bekerja sambil belajar di perusahaan Jepang.</h2>
            <p className="mt-5 text-[16.5px] leading-relaxed text-muted">{st.magang_desc}</p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-line p-5">
                <p className="font-display text-lg font-bold text-brand">Ginou Jisshu <span className="text-muted font-body text-[14px] font-medium">技能実習</span></p>
                <p className="mt-1.5 text-[14.5px] leading-relaxed text-muted">Pemagangan teknis 3 tahun (bisa diperpanjang). Cocok untuk lulusan baru tanpa pengalaman kerja.</p>
              </div>
              <div className="rounded-2xl border border-line p-5">
                <p className="font-display text-lg font-bold text-brand">Tokutei Ginou <span className="text-muted font-body text-[14px] font-medium">特定技能</span></p>
                <p className="mt-1.5 text-[14.5px] leading-relaxed text-muted">Visa pekerja berketerampilan khusus hingga 5 tahun. Syarat lulus tes keahlian dan JLPT N4.</p>
              </div>
            </div>
          </div>
          <div className="relative lg:pt-2">
            {st.magang_video ? (
              <VideoPlayer src={st.magang_video} poster={st.magang_video_poster || st.magang_image} title={st.magang_video_judul || 'Video profil program magang'} />
            ) : (
              <div className="aspect-[4/5] overflow-hidden rounded-2xl">
                <img src={assetUrl(st.magang_image || '/images/hero/magang-jepang.jpg')} alt="Alumni bekerja di Jepang" loading="lazy" className="h-full w-full object-cover" />
              </div>
            )}
            <div className="mt-5 grid gap-4 sm:grid-cols-[1.4fr_1fr]">
              <div className="rounded-2xl bg-brand p-5 text-white">
                <p className="flex items-center gap-2 text-[13px] font-semibold text-white/70"><ShieldCheck className="h-4 w-4 text-accent" />Terdaftar & diawasi</p>
                <p className="mt-1 text-[15px] font-semibold leading-snug">Bekerja sama dengan LPK berizin Kemnaker dan IM Japan.</p>
              </div>
              <div className="overflow-hidden rounded-2xl">
                <img src={assetUrl(st.magang_image || '/images/hero/magang-jepang.jpg')} alt="Peserta magang bekerja di pabrik Jepang" loading="lazy" className="h-full max-h-[140px] w-full object-cover sm:max-h-none" />
              </div>
            </div>
          </div>
        </div>
        {stats.length > 0 && <div className="mt-20"><StatRow items={stats} /></div>}
      </Section>

      {/* Keunggulan */}
      {keunggulan.length > 0 && (
        <Section tone="surface">
          <SectionHeader eyebrow="Kenapa Lewat Sekolah" title="Aman, transparan, dan didampingi sampai pulang." />
          <div className="grid gap-5 md:grid-cols-2">
            {keunggulan.map((k, i) => (
              <div key={k.label} className="flex gap-5 rounded-2xl bg-white p-7">
                <span className="font-display text-3xl font-extrabold leading-none text-accent tabular-nums">{String(i + 1).padStart(2, '0')}</span>
                <div><h3 className="font-display text-[1.25rem] font-bold text-brand">{k.label}</h3><p className="mt-2 text-[15px] leading-relaxed text-muted">{k.value}</p></div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Bidang */}
      <Section id="bidang" className="scroll-mt-20">
        <SectionHeader eyebrow="Bidang Kerja" title="Pilih bidang yang sesuai minat dan fisikmu." desc="Perkiraan gaji adalah gaji kotor per bulan sebelum pajak, asuransi, dan asrama. Nilai akhir mengikuti kontrak perusahaan." />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {loading && [0, 1, 2].map((i) => <Skeleton key={i} className="h-[440px]" />)}
          {bidang.map((b) => (
            <article key={b.id} className="flex flex-col overflow-hidden rounded-2xl border border-line bg-white">
              <div className="relative aspect-[16/10] overflow-hidden bg-surface">
                {b.gambar && <img src={assetUrl(b.gambar)} alt={b.nama} loading="lazy" className="h-full w-full object-cover" />}
                {b.istilah_jp && <span className="absolute left-4 top-4 rounded-full bg-white/95 px-3 py-1 text-[13px] font-semibold text-brand">{b.istilah_jp}</span>}
              </div>
              <div className="flex flex-1 flex-col p-6">
                <h3 className="font-display text-[1.3rem] font-bold text-brand">{b.nama}</h3>
                <p className="mt-2 text-[14.5px] leading-relaxed text-muted">{b.deskripsi}</p>
                <dl className="mt-5 grid grid-cols-2 gap-3">
                  <div className="rounded-xl bg-surface p-3"><dt className="flex items-center gap-1.5 text-[12px] font-semibold text-muted"><Clock className="h-3.5 w-3.5" />Durasi</dt><dd className="mt-1 text-[14px] font-semibold text-ink">{b.durasi}</dd></div>
                  <div className="rounded-xl bg-surface p-3"><dt className="flex items-center gap-1.5 text-[12px] font-semibold text-muted"><Banknote className="h-3.5 w-3.5" />Gaji</dt><dd className="mt-1 text-[14px] font-semibold text-ink">{b.gaji}</dd></div>
                </dl>
                {asList(b.syarat).length > 0 && (
                  <ul className="mt-5 space-y-2 border-t border-line pt-5">
                    {asList(b.syarat).map((s) => <li key={s} className="flex gap-2.5 text-[14px] text-ink/75"><Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" strokeWidth={2.5} />{s}</li>)}
                  </ul>
                )}
              </div>
            </article>
          ))}
        </div>
      </Section>

      {/* Syarat & dokumen */}
      <Section tone="tint">
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl bg-white p-7 md:p-9">
            <p className="eyebrow">Persyaratan</p>
            <h2 className="mt-3 font-display text-[1.7rem] font-extrabold text-brand">Siapa yang boleh mendaftar?</h2>
            <ul className="mt-6 space-y-3.5">{syarat.map((s) => <li key={s} className="flex gap-3 text-[15.5px] leading-relaxed text-ink/80"><Check className="mt-1 h-4 w-4 shrink-0 text-accent" strokeWidth={2.5} />{s}</li>)}</ul>
          </div>
          <div className="rounded-2xl bg-white p-7 md:p-9">
            <p className="eyebrow">Dokumen</p>
            <h2 className="mt-3 font-display text-[1.7rem] font-extrabold text-brand">Berkas yang perlu disiapkan</h2>
            <ul className="mt-6 space-y-3.5">{dokumen.map((s) => <li key={s} className="flex gap-3 text-[15.5px] leading-relaxed text-ink/80"><FileText className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" strokeWidth={1.8} />{s}</li>)}</ul>
            <Link to="/unduhan" className="link-arrow mt-7">Unduh formulir & surat izin orang tua <ArrowRight className="h-4 w-4" /></Link>
          </div>
        </div>
      </Section>

      {/* Alur */}
      {alur.length > 0 && (
        <Section tone="brand">
          <div className="grid gap-14 lg:grid-cols-[0.85fr_1.15fr]">
            <div className="lg:sticky lg:top-28 lg:self-start">
              <p className="eyebrow !text-[#D4EE4E]">Alur Seleksi</p>
              <h2 className="section-heading mt-3 !text-white">Dari pendaftaran sampai berangkat ke Jepang.</h2>
              <p className="mt-5 max-w-md text-[16px] leading-relaxed text-white/70">Rata-rata proses 8 — 12 bulan, tergantung jadwal interview perusahaan dan penerbitan COE.</p>
              <Link to="/magang-jepang/cek-status" className="btn-outline-light mt-8">Cek status seleksi</Link>
            </div>
            <Steps items={alur} light />
          </div>
        </Section>
      )}

      {/* Pelatihan */}
      {pelatihan.length > 0 && (
        <Section>
          <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
            <div className="aspect-[4/3] overflow-hidden rounded-2xl">
              <img src={assetUrl(st.magang_image_pelatihan || '/images/magang/pelatihan.jpg')} alt="Kelas bahasa Jepang di sekolah" loading="lazy" className="h-full w-full object-cover" />
            </div>
            <div>
              <p className="eyebrow">Pelatihan Pra-Keberangkatan</p>
              <h2 className="section-heading mt-3">Siap bahasa, siap budaya, siap kerja.</h2>
              <dl className="mt-8 divide-y divide-line border-y border-line">
                {pelatihan.map((p) => (
                  <div key={p.label} className="grid gap-1 py-5 sm:grid-cols-[0.8fr_1.2fr] sm:gap-6">
                    <dt className="font-display text-[1.1rem] font-bold text-brand">{p.label}</dt>
                    <dd className="text-[15px] leading-relaxed text-muted">{p.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </Section>
      )}

      {/* Biaya */}
      {biaya.length > 0 && (
        <Section tone="surface">
          <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
            <div>
              <p className="eyebrow">Biaya Program</p>
              <h2 className="section-heading mt-3">Rincian biaya tertulis, tanpa pungutan tersembunyi.</h2>
              {st.magang_biaya_catatan && <p className="mt-5 flex gap-3 rounded-2xl bg-white p-5 text-[14.5px] leading-relaxed text-muted"><Info className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />{st.magang_biaya_catatan}</p>}
            </div>
            <div className="overflow-hidden rounded-2xl border border-line bg-white">
              <table className="w-full text-left">
                <thead className="bg-brand text-white"><tr><th className="px-6 py-4 text-[13px] font-semibold uppercase tracking-[0.08em]">Komponen</th><th className="px-6 py-4 text-right text-[13px] font-semibold uppercase tracking-[0.08em]">Nominal</th></tr></thead>
                <tbody className="divide-y divide-line">
                  {biaya.map((b) => <tr key={b.label}><td className="px-6 py-4 text-[15px] text-ink/85">{b.label}</td><td className="px-6 py-4 text-right text-[15px] font-semibold text-brand tabular-nums">{b.value}</td></tr>)}
                </tbody>
              </table>
            </div>
          </div>
        </Section>
      )}

      {/* Video Instagram */}
      <InstagramVideos resource="video_magang" tone="cream" eyebrow="Video Instagram · 動画"
        title="Lihat langsung suasana pelatihan dan kerja di Jepang."
        desc="Kumpulan Reel dari Instagram: kelas bahasa, seleksi, keberangkatan, hingga keseharian alumni di Jepang." />

      {/* Alumni */}
      {alumni.length > 0 && (
        <Section>
          <SectionHeader eyebrow="Alumni di Jepang" title="Mereka sudah berangkat. Giliranmu berikutnya." />
          <div className="grid gap-5 md:grid-cols-2">
            {alumni.map((a) => (
              <figure key={a.id} className="flex flex-col rounded-2xl border border-line bg-white p-7">
                <blockquote className="flex-1 text-[16px] leading-relaxed text-ink/80">“{a.kutipan}”</blockquote>
                <figcaption className="mt-6 flex items-center gap-4 border-t border-line pt-5">
                  {a.foto ? <img src={assetUrl(a.foto)} alt={a.nama} className="h-12 w-12 rounded-full object-cover" /> : <span className="flex h-12 w-12 items-center justify-center rounded-full bg-accent-soft font-display font-bold text-accent">{initials(a.nama)}</span>}
                  <div className="min-w-0">
                    <p className="font-semibold text-ink">{a.nama} <span className="font-normal text-muted">· {a.jurusan} · {a.angkatan}</span></p>
                    <p className="flex items-center gap-1.5 text-[13.5px] text-muted"><MapPin className="h-3.5 w-3.5 shrink-0" />{[a.bidang, a.perusahaan, a.prefektur].filter(Boolean).join(' · ')}</p>
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </Section>
      )}

      {/* Mitra */}
      {(lpk.length > 0 || mitra.length > 0) && (
        <Section tone="surface">
          <SectionHeader eyebrow="Mitra Penyelenggara" title="Lembaga resmi yang bekerja sama dengan sekolah." />
          <div className="grid gap-3 sm:grid-cols-2">
            {lpk.map((m) => <div key={m} className="flex items-center gap-3 rounded-2xl bg-white px-5 py-4 text-[15px] font-semibold text-ink"><ShieldCheck className="h-5 w-5 shrink-0 text-brand-600" />{m}</div>)}
            {mitra.map((m) => <div key={m.id} className="rounded-2xl bg-white px-5 py-4"><p className="text-[15px] font-semibold text-ink">{m.nama}</p>{m.bidang && <p className="text-[13.5px] text-muted">{m.bidang}</p>}</div>)}
          </div>
        </Section>
      )}

      {faq.length > 0 && (
        <Section>
          <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
            <SectionHeader eyebrow="FAQ" title="Pertanyaan seputar Magang Jepang" desc="Masih ragu? Konsultasi gratis di ruang BKK setiap hari kerja." />
            <FaqList items={faq} />
          </div>
        </Section>
      )}

      <section className="bg-white pb-20 md:pb-28">
        <div className="container-page">
          <div className="flex flex-col gap-6 rounded-2xl bg-accent p-8 text-white md:flex-row md:items-center md:justify-between md:p-12">
            <div>
              <p className="text-[13px] font-bold uppercase tracking-[0.14em] text-white/80">{st.magang_angkatan}</p>
              <h2 className="mt-2 font-display text-[2rem] font-extrabold leading-tight md:text-[2.4rem]">Siap memulai perjalanan ke Jepang?</h2>
            </div>
            <div className="flex flex-wrap gap-3">
              {dibuka && <Link to="/magang-jepang/daftar" className="btn-dark">Daftar Sekarang <ArrowRight className="h-4 w-4" /></Link>}
              <Link to="/kontak" className="btn-outline-light">Konsultasi</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
