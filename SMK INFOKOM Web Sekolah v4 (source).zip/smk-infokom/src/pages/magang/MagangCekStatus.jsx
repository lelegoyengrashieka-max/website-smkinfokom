import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Check, X } from 'lucide-react'
import PageHero from '../../components/PageHero.jsx'
import { Input, Alert } from '../../components/ui/index.jsx'
import { api } from '../../lib/api.js'
import { formatTanggal, usePageTitle } from '../../lib/data.jsx'

const STAGES = ['baru', 'seleksi administrasi', 'tes tertulis', 'wawancara', 'pelatihan', 'lolos', 'berangkat']
const LABEL = { baru: 'Pendaftaran diterima', 'seleksi administrasi': 'Seleksi administrasi', 'tes tertulis': 'Tes tertulis & fisik', wawancara: 'Wawancara', pelatihan: 'Pelatihan bahasa', lolos: 'Lolos interview perusahaan', berangkat: 'Berangkat ke Jepang' }

export default function MagangCekStatus() {
  usePageTitle('Cek Status Seleksi Magang Jepang')
  const [q, setQ] = useState({ nomor: '', tanggal_lahir: '' })
  const [s, setS] = useState({ loading: false, error: '', data: null })
  const submit = async (e) => {
    e.preventDefault()
    setS({ loading: true, error: '', data: null })
    try {
      const data = await api('/api/public/pendaftaran-magang/cek', { query: q })
      setS({ loading: false, error: '', data })
    } catch (err) { setS({ loading: false, error: err.message, data: null }) }
  }
  const r = s.data
  const gagal = r?.status === 'tidak lolos'
  const idx = r ? STAGES.indexOf(r.status) : -1

  return (
    <>
      <PageHero banner="magang" image="/images/magang/pelatihan.jpg" eyebrow="Magang ke Jepang" crumbs={[{ label: 'Magang Jepang', to: '/magang-jepang' }, { label: 'Cek Status' }]}
        title="Cek status seleksi magang." desc="Masukkan nomor pendaftaran (format MJ-TAHUN-0000) dan tanggal lahir." />
      <section className="bg-surface py-14 md:py-20">
        <div className="container-page grid max-w-5xl gap-8 lg:grid-cols-[380px_1fr]">
          <form onSubmit={submit} className="space-y-5 self-start rounded-2xl border border-line bg-white p-6 md:p-8">
            <Input label="Nomor pendaftaran" name="nomor" value={q.nomor} onChange={(e) => setQ({ ...q, nomor: e.target.value.toUpperCase() })} placeholder="MJ-2026-0001" required className="[&_input]:font-code" />
            <Input label="Tanggal lahir" name="tanggal_lahir" type="date" value={q.tanggal_lahir} onChange={(e) => setQ({ ...q, tanggal_lahir: e.target.value })} required />
            <button type="submit" disabled={s.loading} className="btn-primary w-full">{s.loading ? 'Memeriksa…' : 'Cek Status'}</button>
            <p className="text-[13px] text-muted">Belum mendaftar? <Link to="/magang-jepang/daftar" className="font-semibold text-brand-600 hover:text-accent">Daftar di sini</Link></p>
          </form>
          <div className="min-w-0">
            {s.error && <Alert>{s.error}</Alert>}
            {!r && !s.error && (
              <div className="flex h-full min-h-[240px] items-center justify-center rounded-2xl border border-dashed border-line bg-white p-8 text-center text-[15px] text-muted">Hasil pengecekan akan tampil di sini.</div>
            )}
            {r && (
              <div className="rounded-2xl border border-line bg-white p-6 md:p-8">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-line pb-6">
                  <div>
                    <p className="font-code text-[14px] font-semibold text-brand-600">{r.nomor}</p>
                    <p className="mt-1 font-display text-2xl font-extrabold text-brand">{r.nama}</p>
                    <p className="mt-1 text-[14px] text-muted">{r.bidang} · Daftar {formatTanggal(r.tanggal_daftar, 'pendek')}</p>
                  </div>
                  <span className={`rounded-full px-3 py-1.5 text-[13px] font-bold capitalize ${gagal ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'}`}>{r.status}</span>
                </div>
                {gagal ? (
                  <div className="mt-6 flex gap-3 rounded-2xl bg-red-50 p-5 text-[15px] text-red-800"><X className="mt-0.5 h-5 w-5 shrink-0" />Mohon maaf, kamu belum lolos pada seleksi kali ini. Kamu tetap bisa mendaftar di angkatan berikutnya.</div>
                ) : (
                  <ol className="mt-6 space-y-0">
                    {STAGES.map((stg, i) => {
                      const done = i < idx, cur = i === idx
                      return (
                        <li key={stg} className="relative flex gap-4 pb-5 last:pb-0">
                          {i < STAGES.length - 1 && <span className={`absolute left-[13px] top-7 bottom-0 w-0.5 ${done ? 'bg-emerald-500' : 'bg-line'}`} />}
                          <span className={`relative z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[12px] font-bold ${done ? 'bg-emerald-500 text-white' : cur ? 'bg-accent text-white ring-4 ring-accent-soft' : 'bg-surface text-muted'}`}>
                            {done ? <Check className="h-4 w-4" strokeWidth={3} /> : i + 1}
                          </span>
                          <span className={`pt-0.5 text-[15px] ${cur ? 'font-bold text-ink' : done ? 'font-medium text-ink/80' : 'text-muted'}`}>{LABEL[stg]}{cur && <span className="ml-2 text-[12.5px] font-semibold text-accent">Tahap saat ini</span>}</span>
                        </li>
                      )
                    })}
                  </ol>
                )}
                {r.catatan && <div className="mt-6 rounded-2xl bg-brand-50 p-5"><p className="text-[12px] font-bold uppercase tracking-[0.12em] text-brand-600">Catatan panitia</p><p className="mt-1.5 whitespace-pre-line text-[15px] text-ink/85">{r.catatan}</p></div>}
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  )
}
