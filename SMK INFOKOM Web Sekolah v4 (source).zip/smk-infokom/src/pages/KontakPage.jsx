import PageHero from '../components/PageHero.jsx'
import Kontak from '../components/Kontak.jsx'

import { usePageTitle } from '../lib/data.jsx'

export default function KontakPage() {
  usePageTitle('Kontak')
  return (
    <>
      <PageHero
        image="/images/hero/kontak.jpg"
        banner="kontak"
        eyebrow="KONTAK"
        title="Ada pertanyaan seputar pendaftaran?"
        desc="Tim kesiswaan kami siap membantu, dari jam 08.00 hingga 16.00 WIB setiap hari kerja."
      />
      <Kontak />
    </>
  )
}
