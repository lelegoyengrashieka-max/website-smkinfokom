import { useState } from 'react'
import { Link } from 'react-router-dom'
import PageHero from '../components/PageHero.jsx'
import { api } from '../lib/api.js'
import { useSettings, usePageTitle, formatTanggal } from '../lib/data.jsx'

const STATUS = {
  baru: { label: 'Menunggu Verifikasi', cls: 'bg-mist text-ink', desc: 'Data Anda sudah kami terima dan sedang menunggu verifikasi panitia.' },
  diverifikasi: { label: 'Terverifikasi', cls: 'bg-blue-50 text-blue-800', desc: 'Berkas telah diverifikasi. Ikuti tahap seleksi sesuai jadwal.' },
  diterima: { label: 'Diterima', cls: 'bg-teal/10 text-teal', desc: 'Selamat, Anda dinyatakan diterima. Silakan lakukan daftar ulang sesuai jadwal.' },
  cadangan: { label: 'Cadangan', cls: 'bg-amber/15 text-[#8a5a12]', desc: 'Anda masuk daftar cadangan. Panitia akan menghubungi bila ada kuota tersedia.' },
  ditolak: { label: 'Belum Diterima', cls: 'bg-red-50 text-red-700', desc: 'Mohon maaf, Anda belum dapat diterima pada periode ini.' },
}

export default function PpdbCekStatus() {
  usePageTitle('Cek Status PPDB')
  const st = useSettings()
  const [form, setForm] = useState({ nomor: '', tanggal_lahir: '' })
  const [state, setState] = useState({ loading: false, error: '', data: null })

  const submit = async (e) => {
    e.preventDefault()
    setState({ loading: true, error: '', data: null })
    try {
      const data = await api('/api/public/pendaftaran/cek', { query: form })
      setState({ loading: false, error: '', data })
    } catch (err) {
      setState({ loading: false, error: err.message, data: null })
    }
  }

  const d = state.data
  const s = d ? STATUS[d.status] || STATUS.baru : null

  return (
    <>
      <PageHero
        image="/images/hero/ppdb.jpg"
        banner="ppdb"
        eyebrow={`PPDB ${st.ppdb_tahun} / CEK STATUS`}
        title="Cek status pendaftaran."
        desc="Masukkan nomor pendaftaran dan tanggal lahir calon siswa untuk melihat hasil verifikasi dan seleksi."
      />
      <section className="bg-paper py-16 md:py-20">
        <div className="container-page grid md:grid-cols-[0.9fr_1.1fr] gap-10 max-w-5xl">
          <form onSubmit={submit} className="rounded-2xl border border-hairline p-7 space-y-5 self-start">
            <div>
              <label htmlFor="nomor" className="font-mono text-[12px] text-ink/55">NOMOR PENDAFTARAN</label>
              <input id="nomor" required placeholder="PPDB-2026-0001" value={form.nomor} onChange={(e) => setForm({ ...form, nomor: e.target.value })} className="mt-2 w-full border border-hairline bg-white px-4 py-3 font-mono uppercase outline-none focus:border-navy" />
            </div>
            <div>
              <label htmlFor="tgl" className="font-mono text-[12px] text-ink/55">TANGGAL LAHIR</label>
              <input id="tgl" type="date" required value={form.tanggal_lahir} onChange={(e) => setForm({ ...form, tanggal_lahir: e.target.value })} className="mt-2 w-full border border-hairline bg-white px-4 py-3 outline-none focus:border-navy" />
            </div>
            {state.error && <p className="rounded-lg bg-red-50 px-4 py-3 text-[13.5px] text-red-700">{state.error}</p>}
            <button type="submit" disabled={state.loading} className="btn-primary w-full justify-center disabled:opacity-60">{state.loading ? 'Memeriksa…' : 'Cek Status'}</button>
            <p className="text-[13px] text-ink/50">Belum mendaftar? <Link to="/ppdb/daftar" className="text-navy underline">Isi formulir online</Link></p>
          </form>

          <div className="rounded-2xl border border-hairline p-7 md:p-9 min-h-[260px]">
            {!d ? (
              <div className="flex h-full flex-col items-center justify-center text-center text-ink/45">
                <p className="font-display text-lg text-ink/60">Hasil pengecekan akan tampil di sini.</p>
                <p className="mt-2 text-[14px]">Lupa nomor pendaftaran? Hubungi panitia melalui halaman <Link to="/kontak" className="underline">Kontak</Link>.</p>
              </div>
            ) : (
              <div>
                <span className={`inline-block rounded-full px-4 py-1.5 text-[13px] font-semibold ${s.cls}`}>{s.label}</span>
                <p className="mt-5 font-display text-2xl text-ink">{d.nama}</p>
                <dl className="mt-5 grid grid-cols-[140px_1fr] gap-y-3 text-[14.5px]">
                  <dt className="text-ink/50">No. Pendaftaran</dt><dd className="font-mono">{d.nomor}</dd>
                  <dt className="text-ink/50">Asal Sekolah</dt><dd>{d.asal_sekolah}</dd>
                  <dt className="text-ink/50">Jurusan</dt><dd>{d.jurusan}</dd>
                  <dt className="text-ink/50">Tanggal Daftar</dt><dd>{formatTanggal(d.tanggal_daftar)}</dd>
                </dl>
                <p className="mt-6 border-t border-hairline pt-5 text-[14.5px] leading-relaxed text-ink/70">{s.desc}</p>
                {d.catatan && <p className="mt-4 rounded-lg bg-mist/70 px-4 py-3 text-[14px] text-ink/75 whitespace-pre-line"><strong>Catatan panitia:</strong> {d.catatan}</p>}
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  )
}
