import { FileDown } from 'lucide-react'
import { assetUrl } from '../lib/api.js'
import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import PageHero from '../components/PageHero.jsx'
import { api } from '../lib/api.js'
import { useList, useSettings, usePageTitle, lines } from '../lib/data.jsx'

const AGAMA = ['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Konghucu']

const FORM_PDF = '/files/formulir-pendaftaran-ppdb-2027-2028.pdf'

export default function PpdbDaftar() {
  usePageTitle('Formulir Pendaftaran PPDB')
  const st = useSettings()
  const [params] = useSearchParams()
  const { items: jurusan } = useList('jurusan')
  const [form, setForm] = useState({
    nama: '', nisn: '', jenis_kelamin: '', tempat_lahir: '', tanggal_lahir: '', agama: '',
    asal_sekolah: '', jurusan_1: params.get('jurusan') || '', jurusan_2: '', nama_ortu: '',
    telepon: '', email: '', alamat: '', website: '', setuju: false,
  })
  const [state, setState] = useState({ loading: false, error: '', details: {}, result: null })
  const dibuka = st.ppdb_dibuka !== 'false'

  const set = (e) => {
    const { name, value, type, checked } = e.target
    setForm((f) => ({ ...f, [name]: type === 'checkbox' ? checked : value }))
  }

  const submit = async (e) => {
    e.preventDefault()
    if (!form.setuju) return setState((s) => ({ ...s, error: 'Centang pernyataan kebenaran data terlebih dahulu.' }))
    setState({ loading: true, error: '', details: {}, result: null })
    try {
      const { setuju, ...body } = form
      const result = await api('/api/public/pendaftaran', { method: 'POST', body })
      setState({ loading: false, error: '', details: {}, result })
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } catch (err) {
      setState({ loading: false, error: err.message, details: err.details || {}, result: null })
    }
  }

  const err = (k) => state.details[k]

  return (
    <>
      <PageHero
        image="/images/hero/ppdb.jpg"
        banner="ppdb"
        eyebrow={`PPDB ${st.ppdb_tahun} · Formulir Online`}
        crumbs={[{ label: "PPDB", to: "/ppdb" }, { label: "Formulir Online" }]}
        title="Formulir pendaftaran siswa baru."
        desc="Isi data dengan benar sesuai dokumen resmi. Simpan nomor pendaftaran yang muncul setelah formulir terkirim."
      />

      <section className="bg-paper py-16 md:py-20">
        <div className="container-page max-w-4xl">
          {!dibuka ? (
            <div className="rounded-2xl border border-hairline p-10 text-center">
              <p className="font-display text-2xl text-ink">Pendaftaran online sedang ditutup.</p>
              <p className="mt-3 text-ink/60">Pantau informasi terbaru di halaman berita atau hubungi panitia PPDB.</p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <Link to="/ppdb" className="btn-primary">Informasi PPDB</Link>
                <Link to="/kontak" className="btn-outline">Hubungi Kami</Link>
              </div>
            </div>
          ) : state.result ? (
            <div className="rounded-2xl border border-teal/30 bg-teal/5 p-8 md:p-12 text-center">
              <p className="eyebrow-code text-teal">PENDAFTARAN BERHASIL</p>
              <p className="mt-4 font-display text-2xl md:text-3xl text-ink">Terima kasih, {state.result.nama}.</p>
              <p className="mt-6 text-ink/60 text-[14.5px]">Nomor pendaftaran Anda:</p>
              <p className="mt-2 font-mono text-3xl md:text-4xl font-semibold tracking-wider text-navy">{state.result.nomor}</p>
              <p className="mx-auto mt-6 max-w-lg text-[14.5px] leading-relaxed text-ink/70 whitespace-pre-line">{st.ppdb_pesan_sukses}</p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <button type="button" onClick={() => window.print()} className="btn-outline">Cetak Bukti</button>
                <Link to="/ppdb/cek-status" className="btn-primary">Cek Status Pendaftaran</Link>
              </div>
            </div>
          ) : (
            <>
            <div className="mb-8 flex flex-col gap-4 rounded-2xl bg-brand p-5 text-white sm:flex-row sm:items-center sm:justify-between md:p-6">
              <div className="flex items-start gap-4">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/10"><FileDown className="h-5 w-5 text-[#D4EE4E]" /></span>
                <div><p className="font-display text-[1.1rem] font-bold">Lebih suka daftar offline?</p><p className="mt-0.5 text-[14px] text-white/70">Unduh formulir pendaftaran PDF, isi, cetak, lalu serahkan ke sekretariat PPDB.</p></div>
              </div>
              <a href={assetUrl(FORM_PDF)} download className="btn-primary shrink-0">Unduh Formulir PDF</a>
            </div>
            <form onSubmit={submit} noValidate className="space-y-10">
              {lines(st.ppdb_syarat).length > 0 && (
                <div className="rounded-2xl bg-mist/60 border border-hairline p-6">
                  <p className="font-mono text-[12px] text-teal mb-3">SIAPKAN DOKUMEN BERIKUT</p>
                  <ul className="grid sm:grid-cols-2 gap-x-8 gap-y-2 text-[14px] text-ink/70">
                    {lines(st.ppdb_syarat).map((s, i) => <li key={i}>— {s}</li>)}
                  </ul>
                </div>
              )}

              <Fieldset title="Data Calon Siswa">
                <Input label="Nama Lengkap" name="nama" value={form.nama} onChange={set} error={err('nama')} required className="sm:col-span-2" />
                <Input label="NISN (10 digit)" name="nisn" value={form.nisn} onChange={set} error={err('nisn')} required inputMode="numeric" maxLength={10} pattern="\d{10}" />
                <Select label="Jenis Kelamin" name="jenis_kelamin" value={form.jenis_kelamin} onChange={set} error={err('jenis_kelamin')} required options={[['L', 'Laki-laki'], ['P', 'Perempuan']]} />
                <Input label="Tempat Lahir" name="tempat_lahir" value={form.tempat_lahir} onChange={set} error={err('tempat_lahir')} required />
                <Input label="Tanggal Lahir" name="tanggal_lahir" type="date" value={form.tanggal_lahir} onChange={set} error={err('tanggal_lahir')} required />
                <Select label="Agama" name="agama" value={form.agama} onChange={set} error={err('agama')} options={AGAMA.map((a) => [a, a])} />
                <Input label="Asal Sekolah (SMP/MTs)" name="asal_sekolah" value={form.asal_sekolah} onChange={set} error={err('asal_sekolah')} required />
              </Fieldset>

              <Fieldset title="Pilihan Program Keahlian">
                <Select label="Pilihan Jurusan 1" name="jurusan_1" value={form.jurusan_1} onChange={set} error={err('jurusan_1')} required options={jurusan.map((j) => [j.slug, `${j.kode} — ${j.nama}`])} />
                <Select label="Pilihan Jurusan 2 (opsional)" name="jurusan_2" value={form.jurusan_2} onChange={set} error={err('jurusan_2')} options={jurusan.filter((j) => j.slug !== form.jurusan_1).map((j) => [j.slug, `${j.kode} — ${j.nama}`])} />
              </Fieldset>

              <Fieldset title="Data Orang Tua & Kontak">
                <Input label="Nama Orang Tua / Wali" name="nama_ortu" value={form.nama_ortu} onChange={set} error={err('nama_ortu')} required />
                <Input label="No. HP / WhatsApp" name="telepon" type="tel" value={form.telepon} onChange={set} error={err('telepon')} required />
                <Input label="Email (opsional)" name="email" type="email" value={form.email} onChange={set} error={err('email')} className="sm:col-span-2" />
                <div className="sm:col-span-2">
                  <Label name="alamat" required>Alamat Lengkap</Label>
                  <textarea id="alamat" name="alamat" rows={3} value={form.alamat} onChange={set} className={inputCls(err('alamat'))} />
                  <Err msg={err('alamat')} />
                </div>
              </Fieldset>

              <input type="text" name="website" value={form.website} onChange={set} tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />

              <label className="flex items-start gap-3 text-[14px] text-ink/70">
                <input type="checkbox" name="setuju" checked={form.setuju} onChange={set} className="mt-1 h-4 w-4 accent-navy" />
                Saya menyatakan data yang diisi adalah benar dan dapat dipertanggungjawabkan.
              </label>

              {state.error && (
                <p className="rounded-lg bg-red-50 px-4 py-3 text-[14px] text-red-700">
                  {state.error}
                  {state.error.includes('Cek Status') && <> <Link to="/ppdb/cek-status" className="underline">Buka Cek Status</Link></>}
                </p>
              )}
              <div className="flex flex-wrap items-center gap-4">
                <button type="submit" disabled={state.loading} className="btn-primary disabled:opacity-60">
                  {state.loading ? 'Mengirim…' : 'Kirim Pendaftaran'}
                </button>
                <Link to="/ppdb" className="text-[14px] text-ink/60 hover:text-navy">Kembali ke informasi PPDB</Link>
              </div>
            </form>
            </>
          )}
        </div>
      </section>
    </>
  )
}

const inputCls = (error) => `mt-2 w-full border bg-white px-4 py-3 text-[15px] outline-none transition-colors focus:border-navy ${error ? 'border-red-400' : 'border-hairline'}`

function Fieldset({ title, children }) {
  return (
    <fieldset className="rounded-2xl border border-hairline p-6 md:p-8">
      <legend className="px-2 font-display text-lg text-ink">{title}</legend>
      <div className="grid sm:grid-cols-2 gap-6">{children}</div>
    </fieldset>
  )
}

function Label({ name, required, children }) {
  return (
    <label htmlFor={name} className="font-mono text-[12px] text-ink/55">
      {String(children).toUpperCase()}{required ? ' *' : ''}
    </label>
  )
}

const Err = ({ msg }) => (msg ? <p className="mt-1.5 text-[12.5px] text-red-600">{msg}</p> : null)

function Input({ label, name, error, required, className = '', ...rest }) {
  return (
    <div className={className}>
      <Label name={name} required={required}>{label}</Label>
      <input id={name} name={name} required={required} className={inputCls(error)} {...rest} />
      <Err msg={error} />
    </div>
  )
}

function Select({ label, name, error, required, options, className = '', ...rest }) {
  return (
    <div className={className}>
      <Label name={name} required={required}>{label}</Label>
      <select id={name} name={name} required={required} className={inputCls(error)} {...rest}>
        <option value="">— Pilih —</option>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
      <Err msg={error} />
    </div>
  )
}
