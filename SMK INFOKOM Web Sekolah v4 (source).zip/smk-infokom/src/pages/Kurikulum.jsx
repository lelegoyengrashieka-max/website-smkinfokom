import PageHero from '../components/PageHero.jsx'
import { useList, useSettings, lines, formatTanggal, usePageTitle } from '../lib/data.jsx'

export default function Kurikulum() {
  usePageTitle('Kurikulum')
  const st = useSettings()
  const { items: KALENDER } = useList('agenda', { limit: 200 })
  const AKADEMIK = lines(st.akademik)
  const NON_AKADEMIK = lines(st.non_akademik)
  return (
    <>
      <PageHero
        image="/images/hero/kurikulum.jpg"
        banner="kurikulum"
        eyebrow="PROGRAM SEKOLAH / KURIKULUM"
        title="Kurikulum yang terus disesuaikan dengan dunia kerja."
        desc="Kalender pendidikan, program akademik, dan pembinaan non-akademik sepanjang tahun ajaran."
      />

      <section id="kalender" className="bg-paper py-20 md:py-24 scroll-mt-24">
        <div className="container-page">
          <p className="eyebrow-code mb-4">KALENDER PENDIDIKAN</p>
          <h2 className="section-heading max-w-lg mb-10">Ringkasan agenda tahun ajaran {st.tahun_ajaran}.</h2>

          {KALENDER.length === 0 && <p className="text-ink/50">Belum ada agenda.</p>}
          <div className="border border-hairline">
            {KALENDER.map((k) => (
              <div
                key={k.id}
                className="grid grid-cols-[110px_1fr] sm:grid-cols-[160px_1fr] gap-4 px-5 py-4 border-b border-hairline last:border-0"
              >
                <span className="font-mono text-teal text-[12.5px]">
                  {k.periode || (k.tanggal_selesai && k.tanggal_selesai !== k.tanggal
                    ? `${formatTanggal(k.tanggal)} – ${formatTanggal(k.tanggal_selesai)}`
                    : formatTanggal(k.tanggal))}
                </span>
                <div>
                  <p className="text-[14.5px] text-ink/75">{k.kegiatan}</p>
                  {(k.lokasi || k.keterangan) && <p className="mt-1 text-[13px] text-ink/45">{[k.lokasi, k.keterangan].filter(Boolean).join(' · ')}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="akademik" className="bg-navy py-20 md:py-24 border-t border-navy-line scroll-mt-24">
        <div className="container-page">
          <p className="eyebrow-code text-amber mb-4">AKADEMIK</p>
          <h2 className="section-heading text-paper max-w-lg mb-10">Struktur pembelajaran di dalam kelas.</h2>
          <ul className="grid sm:grid-cols-2 gap-6">
            {AKADEMIK.map((a, i) => (
              <li key={i} className="flex gap-3 text-[14.5px] text-paper/75 leading-relaxed border-t border-navy-line pt-4">
                <span className="text-amber shrink-0">—</span>
                {a}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section id="non-akademik" className="bg-paper py-20 md:py-24 border-t border-hairline scroll-mt-24">
        <div className="container-page">
          <p className="eyebrow-code mb-4">NON AKADEMIK</p>
          <h2 className="section-heading max-w-lg mb-10">Pembinaan di luar jam pelajaran.</h2>
          <ul className="grid sm:grid-cols-2 gap-6">
            {NON_AKADEMIK.map((a, i) => (
              <li key={i} className="flex gap-3 text-[14.5px] text-ink/70 leading-relaxed border-t border-hairline pt-4">
                <span className="text-teal shrink-0">—</span>
                {a}
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  )
}
