import PageHero from '../components/PageHero.jsx'
import { useSettings, lines, usePageTitle } from '../lib/data.jsx'

export default function ManajemenMutu() {
  usePageTitle('Manajemen Mutu')
  const st = useSettings()
  const MANAJEMEN_MUTU = { desc: st.mutu_desc, poin: lines(st.mutu_poin) }
  return (
    <>
      <PageHero
        image="/images/hero/manajemen-mutu.jpg"
        banner="mutu"
        eyebrow="PROGRAM SEKOLAH / MANAJEMEN MUTU"
        title="Mutu yang terukur, bukan sekadar slogan."
        desc={MANAJEMEN_MUTU.desc}
      />

      <section className="bg-paper py-20 md:py-24">
        <div className="container-page max-w-2xl">
          <p className="eyebrow-code mb-4">PILAR PENJAMINAN MUTU</p>
          <ul className="space-y-4">
            {MANAJEMEN_MUTU.poin.map((p, i) => (
              <li key={i} className="flex gap-4 border-t border-hairline pt-4">
                <span className="font-mono text-teal text-[13px] shrink-0">{String(i + 1).padStart(2, '0')}</span>
                <p className="text-[14.5px] text-ink/75 leading-relaxed">{p}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  )
}
