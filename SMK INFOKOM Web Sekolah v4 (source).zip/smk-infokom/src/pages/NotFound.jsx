import { Link } from 'react-router-dom'
import { usePageTitle } from '../lib/data.jsx'

export default function NotFound() {
  usePageTitle('Halaman tidak ditemukan')
  return (
    <section className="bg-navy min-h-[70vh] flex items-center">
      <div className="container-page py-20 text-center">
        <p className="eyebrow-code text-amber mb-4">ERROR 404</p>
        <h1 className="font-display text-paper text-4xl md:text-5xl">Halaman tidak ditemukan.</h1>
        <p className="mt-5 text-paper/60 max-w-md mx-auto">
          Tautan yang kamu tuju mungkin sudah dipindahkan atau tidak pernah ada.
        </p>
        <Link to="/" className="btn-primary bg-amber text-navy hover:bg-paper mt-9 inline-flex">
          Kembali ke Beranda
        </Link>
      </div>
    </section>
  )
}
