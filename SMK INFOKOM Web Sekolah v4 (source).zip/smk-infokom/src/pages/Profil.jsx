import PageHero from '../components/PageHero.jsx'
import Tentang from '../components/Tentang.jsx'
import OrgChart from '../components/OrgChart.jsx'
import TimGuru from '../components/TimGuru.jsx'
import SambutanKepsek from '../components/SambutanKepsek.jsx'
import { useList, useSettings, lines, usePageTitle } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

export default function Profil() {
  usePageTitle('Profil Sekolah')
  const st = useSettings()
  const { items: SEJARAH } = useList('sejarah')
  const { items: EKSKUL } = useList('ekskul')
  const { items: PRESTASI } = useList('prestasi')
  const TATA_TERTIB = lines(st.tata_tertib)
  return (
    <>
      <PageHero
        image="/images/hero/profil.jpg"
        banner="profil"
        eyebrow="PROFIL SEKOLAH"
        title={`Mengenal ${st.nama_sekolah} lebih dekat.`}
        desc="Sejarah, struktur kepemimpinan, dan kehidupan siswa di luar kelas."
      />

      <SambutanKepsek />

      <Tentang />

      <section className="bg-navy py-24 md:py-28 border-t border-navy-line">
        <div className="container-page">
          <p className="eyebrow-code text-amber mb-4">PERJALANAN SEKOLAH</p>
          <h2 className="section-heading text-paper max-w-lg mb-14">
            Lebih dari dua dekade membentuk lulusan siap kerja.
          </h2>

          <div className="border-t border-navy-line">
            {SEJARAH.map((s) => (
              <div key={s.id} className="grid grid-cols-[80px_1fr] md:grid-cols-[120px_1fr] gap-6 py-6 border-b border-navy-line">
                <span className="font-mono text-amber text-[15px]">{s.tahun}</span>
                <p className="text-paper/70 text-[15px] leading-relaxed max-w-lg">{s.teks}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-paper py-24 md:py-28 border-t border-hairline">
        <div className="container-page">
          <p className="eyebrow-code mb-4">STRUKTUR ORGANISASI</p>
          <h2 className="section-heading max-w-lg mb-14">Tim di balik operasional sekolah.</h2>
          <OrgChart />
        </div>
      </section>

      <TimGuru />

      <section id="ekstrakurikuler" className="bg-paper py-24 md:py-28 border-t border-hairline scroll-mt-24">
        <div className="container-page">
          <p className="eyebrow-code mb-4">EKSTRAKURIKULER</p>
          <h2 className="section-heading max-w-lg mb-14">
            Ruang berkembang di luar jam pelajaran.
          </h2>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {EKSKUL.map((e) => (
              <div key={e.id} className="border-t-2 border-navy pt-5">
                {e.gambar && <img src={assetUrl(e.gambar)} alt={e.nama} loading="lazy" className="mb-5 aspect-[16/10] w-full rounded-xl object-cover" />}
                <div className="flex items-baseline justify-between">
                  <h3 className="font-display text-[1.05rem]">{e.nama}</h3>
                </div>
                <p className="font-mono text-[12px] text-teal mt-2">{e.jadwal}</p>
                <p className="mt-3 text-[14px] text-ink/65 leading-relaxed">{e.deskripsi}</p>
                {e.pembina && <p className="mt-2 text-[12.5px] text-ink/45">Pembina: {e.pembina}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="prestasi" className="bg-navy py-24 md:py-28 border-t border-navy-line scroll-mt-24">
        <div className="container-page">
          <p className="eyebrow-code text-amber mb-4">PRESTASI</p>
          <h2 className="section-heading text-paper max-w-lg mb-14">Catatan pencapaian terkini.</h2>

          <div className="border-t border-navy-line">
            {PRESTASI.map((p) => (
              <div key={p.id} className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-8 py-5 border-b border-navy-line">
                <span className="font-mono text-amber text-[13px] w-14 shrink-0">{p.tahun}</span>
                <div className="flex-1">
                  <p className="text-paper/80 text-[15px]">{p.judul}</p>
                  {(p.peraih || p.keterangan) && (
                    <p className="mt-1 text-paper/45 text-[13px]">{[p.peraih, p.keterangan].filter(Boolean).join(' — ')}</p>
                  )}
                </div>
                {p.tingkat && <span className="pill border border-navy-line text-paper/60 self-start sm:self-center">{p.tingkat}</span>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="tata-tertib" className="bg-paper py-24 md:py-28 border-t border-hairline scroll-mt-24">
        <div className="container-page max-w-2xl">
          <p className="eyebrow-code mb-4">TATA TERTIB</p>
          <h2 className="section-heading mb-10">Disiplin sebagai fondasi budaya sekolah.</h2>
          <ul className="space-y-4">
            {TATA_TERTIB.map((t, i) => (
              <li key={i} className="flex gap-4 border-t border-hairline pt-4">
                <span className="font-mono text-teal text-[13px] shrink-0">{String(i + 1).padStart(2, '0')}</span>
                <p className="text-[14.5px] text-ink/75 leading-relaxed">{t}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  )
}
