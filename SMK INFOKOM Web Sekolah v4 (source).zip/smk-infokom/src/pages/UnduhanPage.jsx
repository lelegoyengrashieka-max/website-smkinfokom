import { useMemo, useState } from 'react'
import { FileDown, Search } from 'lucide-react'
import PageHero from '../components/PageHero.jsx'
import { Skeleton, EmptyState } from '../components/ui/index.jsx'
import { useList, usePageTitle } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

const ORDER = ['PPDB', 'Akademik', 'BKK', 'Magang Jepang', 'Umum']

export default function UnduhanPage() {
  usePageTitle('Pusat Unduhan')
  const { items, loading } = useList('unduhan', { limit: 200 })
  const [kat, setKat] = useState('Semua')
  const [q, setQ] = useState('')
  const groups = useMemo(() => {
    const s = q.trim().toLowerCase()
    const f = items.filter((d) => (kat === 'Semua' || d.kategori === kat) && (!s || `${d.judul} ${d.keterangan || ''}`.toLowerCase().includes(s)))
    return ORDER.map((k) => [k, f.filter((d) => d.kategori === k)]).filter(([, v]) => v.length)
  }, [items, kat, q])
  const cats = ['Semua', ...ORDER.filter((k) => items.some((d) => d.kategori === k))]

  return (
    <>
      <PageHero banner="unduhan" image="/images/hero/kurikulum.jpg" eyebrow="Pusat Unduhan" crumbs={[{ label: 'Unduhan' }]} title="Formulir, panduan, dan dokumen resmi sekolah." desc="Semua berkas yang dibutuhkan calon siswa, siswa, alumni, dan orang tua dalam satu tempat." />
      <section className="bg-white py-14 md:py-20">
        <div className="container-page">
          <div className="mb-10 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex flex-wrap gap-2">
              {cats.map((c) => <button key={c} type="button" onClick={() => setKat(c)} aria-pressed={kat === c} className={`rounded-full px-4 py-2 text-[14px] font-semibold transition-colors ${kat === c ? 'bg-brand text-white' : 'border border-line text-ink/75 hover:border-brand/40'}`}>{c}</button>)}
            </div>
            <label className="relative md:w-80">
              <span className="sr-only">Cari dokumen</span>
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari dokumen…" className="field-input !pl-11" />
            </label>
          </div>
          {loading ? <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-20" />)}</div>
            : groups.length === 0 ? <EmptyState title="Dokumen tidak ditemukan" desc="Coba kata kunci lain atau pilih kategori berbeda." />
            : (
              <div className="space-y-12">
                {groups.map(([k, docs]) => (
                  <div key={k} className="grid gap-5 lg:grid-cols-[220px_1fr]">
                    <div><p className="font-display text-xl font-bold text-brand">{k}</p><p className="text-[13.5px] text-muted">{docs.length} dokumen</p></div>
                    <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line">
                      {docs.map((d) => (
                        <li key={d.id}>
                          <a href={assetUrl(d.file)} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-4 px-5 py-4 transition-colors hover:bg-surface">
                            <FileDown className="h-6 w-6 shrink-0 text-brand-600" strokeWidth={1.7} />
                            <span className="min-w-0 flex-1"><span className="block font-semibold text-ink group-hover:text-brand-600">{d.judul}</span>{d.keterangan && <span className="block text-[13.5px] text-muted">{d.keterangan}</span>}</span>
                            <span className="hidden text-[13.5px] font-semibold text-brand-600 sm:block">Unduh</span>
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
        </div>
      </section>
    </>
  )
}
