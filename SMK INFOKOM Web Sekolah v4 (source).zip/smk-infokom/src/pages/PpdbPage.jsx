import { Link } from 'react-router-dom'
import { ArrowRight, Check, FileText, Download, Printer, MonitorSmartphone, ClipboardCheck, Info, CalendarDays } from 'lucide-react'
import PageHero from '../components/PageHero.jsx'
import { Section, SectionHeader, FaqList, Skeleton } from '../components/ui/index.jsx'
import { useList, useSettings, lines, usePageTitle } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

const isForm = (d) => /formulir pendaftaran/i.test(d.judul)

function DocCard({ d, featured = false }) {
  const href = assetUrl(d.file)
  if (featured) {
    return (
      <div className="grain relative overflow-hidden rounded-2xl bg-brand p-7 text-white md:p-9">
        <div aria-hidden="true" className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-accent/30 blur-[80px]" />
        <div className="relative grid gap-8 md:grid-cols-[auto_1fr] md:items-center">
          {/* Miniatur dokumen */}
          <div className="relative mx-auto h-[190px] w-[146px] shrink-0 md:mx-0" aria-hidden="true">
            <div className="absolute inset-0 translate-x-3 translate-y-3 rotate-6 rounded-xl bg-white/15" />
            <div className="absolute inset-0 rounded-xl bg-white p-3.5 shadow-elegant">
              <div className="flex items-center gap-1.5"><span className="h-4 w-3.5 rounded-sm bg-brand" /><span className="h-1.5 w-14 rounded bg-brand/80" /></div>
              <div className="mt-2 h-px bg-accent" />
              <div className="mx-auto mt-2.5 h-1.5 w-20 rounded bg-brand/70" />
              <div className="mt-3 h-2.5 rounded bg-brand" />
              {[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="mt-2 flex gap-2"><span className="h-1.5 w-8 rounded bg-slate-300" /><span className="h-1.5 flex-1 rounded bg-brand-50" /></div>)}
              <div className="mt-3 h-2.5 rounded bg-brand" />
              {[0, 1, 2].map((i) => <div key={i} className="mt-2 flex gap-2"><span className="h-1.5 w-8 rounded bg-slate-300" /><span className="h-1.5 flex-1 rounded bg-brand-50" /></div>)}
              <span className="absolute -right-3 -top-3 rounded-lg bg-accent px-2 py-1 text-[10px] font-extrabold text-white shadow-glow">PDF</span>
            </div>
          </div>
          <div>
            <p className="eyebrow !text-[#D4EE4E]">Formulir resmi</p>
            <h3 className="mt-2 font-display text-[1.7rem] font-extrabold leading-tight md:text-[2rem]">{d.judul}</h3>
            <p className="mt-3 max-w-lg text-[15px] leading-relaxed text-white/70">
              Formulir isian dua halaman: data calon siswa, sekolah asal, pilihan jurusan, data orang tua, dan daftar kelengkapan berkas.
              Bisa diisi langsung di PDF lalu dicetak, atau dicetak dan diisi tulis tangan.
            </p>
            <ul className="mt-5 flex flex-wrap gap-x-6 gap-y-2 text-[13.5px] text-white/75">
              <li className="flex items-center gap-2"><MonitorSmartphone className="h-4 w-4 text-[#D4EE4E]" />Bisa diisi di komputer/HP</li>
              <li className="flex items-center gap-2"><Printer className="h-4 w-4 text-[#D4EE4E]" />Siap cetak A4</li>
            </ul>
            <div className="mt-7 flex flex-wrap gap-3">
              <a href={href} download className="btn-primary btn-shine"><Download className="h-4 w-4" />Unduh Formulir PDF</a>
              <a href={href} target="_blank" rel="noopener noreferrer" className="btn-outline-light">Lihat dulu</a>
            </div>
          </div>
        </div>
      </div>
    )
  }
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="card card-hover group flex items-start gap-4 p-6">
      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600 transition-colors group-hover:bg-accent group-hover:text-white">
        <FileText className="h-6 w-6" strokeWidth={1.7} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block font-display text-[1.1rem] font-bold leading-snug text-brand">{d.judul}</span>
        {d.keterangan && <span className="mt-1 block text-[13.5px] leading-snug text-muted">{d.keterangan}</span>}
        <span className="mt-3 inline-flex items-center gap-1.5 text-[13.5px] font-semibold text-brand-600 group-hover:text-accent">Unduh PDF <Download className="h-3.5 w-3.5" /></span>
      </span>
    </a>
  )
}

export default function PpdbPage() {
  usePageTitle('PPDB')
  const st = useSettings()
  const { items: BIAYA } = useList('biaya')
  const { items: TAHAPAN } = useList('tahapan')
  const { items: FAQ } = useList('faq', { kategori: 'PPDB' })
  const { items: DOCS, loading: docsLoading } = useList('unduhan', { kategori: 'PPDB', limit: 20 })
  const SYARAT = lines(st.ppdb_syarat)
  const dibuka = st.ppdb_dibuka !== 'false'
  const formDoc = DOCS.find(isForm)
  const otherDocs = DOCS.filter((d) => d !== formDoc)

  return (
    <>
      <PageHero image="/images/hero/ppdb.jpg" banner="ppdb" eyebrow={`PPDB ${st.ppdb_tahun}`} crumbs={[{ label: 'PPDB' }]}
        title="Penerimaan Peserta Didik Baru."
        desc="Semua yang perlu kamu siapkan sebelum mendaftar: syarat, jadwal, biaya, dan formulir yang bisa diunduh.">
        {dibuka ? <Link to="/ppdb/daftar" className="btn-primary btn-shine">Daftar Online <ArrowRight className="h-4 w-4" /></Link>
          : <span className="btn-outline-light pointer-events-none opacity-70">Pendaftaran online ditutup</span>}
        <a href="#dokumen" className="btn-outline-light"><Download className="h-4 w-4" />Unduh Formulir PDF</a>
      </PageHero>

      {/* Dua cara mendaftar */}
      <Section>
        <SectionHeader eyebrow="Cara Mendaftar" title="Pilih cara yang paling mudah untukmu." desc="Kedua jalur diproses dengan tahapan seleksi dan jadwal yang sama." />
        <div className="grid gap-5 md:grid-cols-3">
          {[
            { icon: MonitorSmartphone, t: 'Daftar online', d: 'Isi formulir di situs ini sekitar 10 menit. Kamu langsung mendapat nomor pendaftaran.', to: '/ppdb/daftar', cta: 'Isi formulir online', internal: true },
            { icon: Printer, t: 'Daftar offline', d: 'Unduh formulir PDF, isi dan cetak, lalu serahkan bersama berkas ke sekretariat PPDB.', to: '#dokumen', cta: 'Unduh formulir PDF' },
            { icon: ClipboardCheck, t: 'Cek status', d: 'Pantau hasil verifikasi berkas dan pengumuman memakai nomor pendaftaran dan tanggal lahir.', to: '/ppdb/cek-status', cta: 'Cek status', internal: true },
          ].map((c, i) => {
            const inner = (
              <>
                <span className="flex items-center justify-between">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand text-white transition-colors group-hover:bg-accent"><c.icon className="h-6 w-6" strokeWidth={1.8} /></span>
                  <span className="font-display text-4xl font-extrabold text-brand/10">0{i + 1}</span>
                </span>
                <span className="mt-6 block font-display text-[1.35rem] font-bold text-brand">{c.t}</span>
                <span className="mt-2 block text-[15px] leading-relaxed text-muted">{c.d}</span>
                <span className="link-arrow mt-5 text-[14.5px]">{c.cta} <ArrowRight className="h-4 w-4" /></span>
              </>
            )
            return c.internal
              ? <Link key={c.t} to={c.to} className="card card-hover group block p-7">{inner}</Link>
              : <a key={c.t} href={c.to} className="card card-hover group block p-7">{inner}</a>
          })}
        </div>
      </Section>

      {/* Syarat & jadwal */}
      <Section tone="surface">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <p className="eyebrow">Syarat Pendaftaran</p>
            <h2 className="section-heading mt-3">Berkas yang perlu disiapkan.</h2>
            <ul className="mt-8 space-y-3">
              {SYARAT.map((s, i) => (
                <li key={i} className="flex gap-4 rounded-2xl bg-white p-4 text-[15px] leading-relaxed text-ink/85">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-accent-soft text-accent"><Check className="h-4 w-4" strokeWidth={2.6} /></span>
                  {s}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="eyebrow">Jadwal Seleksi</p>
            <h2 className="section-heading mt-3">Tahapan PPDB {st.ppdb_tahun}.</h2>
            <ol className="relative mt-8 space-y-3">
              {TAHAPAN.map((t, i) => (
                <li key={t.id} className="relative flex items-center gap-5 rounded-2xl bg-white p-5">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-brand font-display text-lg font-extrabold text-white tabular-nums">{String(i + 1).padStart(2, '0')}</span>
                  <span className="flex-1 font-display text-[1.15rem] font-bold text-brand">{t.label}</span>
                  <span className="flex items-center gap-2 rounded-full bg-brand-50 px-3 py-1.5 text-[13px] font-semibold text-brand-600"><CalendarDays className="h-3.5 w-3.5" />{t.waktu}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </Section>

      {/* Dokumen PDF */}
      <section id="dokumen" className="scroll-mt-24 bg-white py-16 md:py-24">
        <div className="container-page">
          <SectionHeader eyebrow="Dokumen PPDB (PDF)" title="Formulir pendaftaran & berkas pendukung."
            desc="Unduh, isi, lalu bawa ke sekretariat PPDB (Senin–Jumat, 08.00–15.00 WIB). Kalau daftar online, formulir PDF tidak perlu dicetak."
            action={<Link to="/unduhan" className="link-arrow">Semua dokumen sekolah <ArrowRight className="h-4 w-4" /></Link>} />
          {docsLoading ? <Skeleton className="h-64 rounded-2xl" /> : (
            <div className="grid gap-5 lg:grid-cols-[1.5fr_1fr]">
              {formDoc ? <DocCard d={formDoc} featured /> : <div />}
              <div className="grid content-start gap-5">
                {otherDocs.map((d) => <DocCard key={d.id} d={d} />)}
                <p className="flex gap-3 rounded-2xl bg-surface p-5 text-[13.5px] leading-relaxed text-muted">
                  <Info className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" />
                  Surat pernyataan orang tua wajib ditandatangani di atas meterai Rp 10.000 dan diserahkan saat verifikasi berkas.
                </p>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Biaya */}
      <Section tone="surface">
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:items-start">
          <div>
            <p className="eyebrow">Rincian Biaya</p>
            <h2 className="section-heading mt-3">Transparan sejak awal.</h2>
            <p className="lead mt-5">Sumbangan pengembangan pendidikan dapat dicicil. Tersedia beasiswa prestasi dan keringanan untuk penerima KIP / PKH / KKS.</p>
          </div>
          <div className="overflow-hidden rounded-2xl border border-line bg-white">
            <div className="flex justify-between bg-brand px-6 py-3.5 text-[12px] font-bold uppercase tracking-[0.12em] text-white"><span>Komponen</span><span>Nominal</span></div>
            {BIAYA.map((b) => (
              <div key={b.id} className="flex items-center justify-between gap-4 border-b border-line px-6 py-4 last:border-0">
                <div>
                  <p className="text-[15px] font-semibold text-ink">{b.item}</p>
                  {b.keterangan && <p className="mt-0.5 text-[13px] text-muted">{b.keterangan}</p>}
                </div>
                <span className="shrink-0 font-display text-[1.05rem] font-bold text-brand tabular-nums">{b.nominal}</span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* FAQ */}
      {FAQ.length > 0 && (
        <section id="faq" className="scroll-mt-24 bg-white py-16 md:py-24">
          <div className="container-page grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
            <div>
              <p className="eyebrow">Pertanyaan Umum</p>
              <h2 className="section-heading mt-3">Masih ada yang ingin ditanyakan?</h2>
              <Link to="/kontak" className="btn-dark mt-8">Hubungi panitia <ArrowRight className="h-4 w-4" /></Link>
            </div>
            <FaqList items={FAQ} />
          </div>
        </section>
      )}
    </>
  )
}
