import { lazy, Suspense } from 'react'
import { BrowserRouter, HashRouter, Routes, Route } from 'react-router-dom'

// VITE_HASH_ROUTER=1 untuk hosting statis tanpa fallback SPA (mis. pratinjau)
const Router = import.meta.env.VITE_HASH_ROUTER ? HashRouter : BrowserRouter
import BkkPage from './pages/bkk/BkkPage.jsx'
import LowonganDetail from './pages/bkk/LowonganDetail.jsx'
import MagangPage from './pages/magang/MagangPage.jsx'
import MagangDaftar from './pages/magang/MagangDaftar.jsx'
import MagangCekStatus from './pages/magang/MagangCekStatus.jsx'
import UnduhanPage from './pages/UnduhanPage.jsx'
import Layout from './components/Layout.jsx'
import Beranda from './pages/Beranda.jsx'
import Profil from './pages/Profil.jsx'
import JurusanPage from './pages/JurusanPage.jsx'
import JurusanDetail from './pages/JurusanDetail.jsx'
import FasilitasPage from './pages/FasilitasPage.jsx'
import Kurikulum from './pages/Kurikulum.jsx'
import Hubinmas from './pages/Hubinmas.jsx'
import ManajemenMutu from './pages/ManajemenMutu.jsx'
import Galeri from './pages/Galeri.jsx'
import BeritaPage from './pages/BeritaPage.jsx'
import BeritaDetail from './pages/BeritaDetail.jsx'
import PpdbPage from './pages/PpdbPage.jsx'
import KontakPage from './pages/KontakPage.jsx'
import NotFound from './pages/NotFound.jsx'
import PpdbDaftar from './pages/PpdbDaftar.jsx'
import PpdbCekStatus from './pages/PpdbCekStatus.jsx'
import { SettingsProvider } from './lib/data.jsx'
import { ADMIN_PATH } from './lib/adminPath.js'

const AdminApp = lazy(() => import('./admin/AdminApp.jsx'))

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path={`${ADMIN_PATH}/*`} element={<Suspense fallback={<div className="min-h-screen bg-slate-100" />}><AdminApp /></Suspense>} />

        <Route element={<SettingsProvider><Layout /></SettingsProvider>}>
          <Route path="/" element={<Beranda />} />
          <Route path="/profil" element={<Profil />} />
          <Route path="/jurusan" element={<JurusanPage />} />
          <Route path="/jurusan/:slug" element={<JurusanDetail />} />
          <Route path="/fasilitas" element={<FasilitasPage />} />
          <Route path="/kurikulum" element={<Kurikulum />} />
          <Route path="/hubinmas" element={<Hubinmas />} />
          <Route path="/manajemen-mutu" element={<ManajemenMutu />} />
          <Route path="/galeri" element={<Galeri />} />
          <Route path="/berita" element={<BeritaPage />} />
          <Route path="/berita/:slug" element={<BeritaDetail />} />
          <Route path="/ppdb" element={<PpdbPage />} />
          <Route path="/ppdb/daftar" element={<PpdbDaftar />} />
          <Route path="/ppdb/cek-status" element={<PpdbCekStatus />} />
          <Route path="/kontak" element={<KontakPage />} />
          <Route path="/bkk" element={<BkkPage />} />
          <Route path="/bkk/lowongan/:slug" element={<LowonganDetail />} />
          <Route path="/magang-jepang" element={<MagangPage />} />
          <Route path="/magang-jepang/daftar" element={<MagangDaftar />} />
          <Route path="/magang-jepang/cek-status" element={<MagangCekStatus />} />
          <Route path="/unduhan" element={<UnduhanPage />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </Router>
  )
}
