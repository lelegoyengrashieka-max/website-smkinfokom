import { useState } from 'react'

export default function Faq({ items }) {
  const [openIndex, setOpenIndex] = useState(0)

  return (
    <div className="border-t border-hairline">
      {items.map((item, i) => {
        const isOpen = openIndex === i
        return (
          <div key={item.id || i} className="border-b border-hairline">
            <button
              onClick={() => setOpenIndex(isOpen ? -1 : i)}
              aria-expanded={isOpen}
              className="w-full flex items-center justify-between gap-6 py-5 text-left"
            >
              <span className="font-display text-[16px] md:text-[17px] text-ink">{item.pertanyaan || item.q}</span>
              <span
                className={`shrink-0 w-6 h-6 flex items-center justify-center border border-ink/25 transition-transform duration-200 ${
                  isOpen ? 'rotate-45' : ''
                }`}
              >
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                  <path d="M6 1 V11 M1 6 H11" stroke="#17181A" strokeWidth="1.4" />
                </svg>
              </span>
            </button>
            <div
              className={`grid transition-all duration-200 ease-out ${
                isOpen ? 'grid-rows-[1fr] opacity-100 pb-5' : 'grid-rows-[0fr] opacity-0'
              }`}
              style={{ display: 'grid' }}
            >
              <div className="overflow-hidden">
                <p className="text-ink/65 text-[14.5px] leading-relaxed max-w-xl whitespace-pre-line">{item.jawaban || item.a}</p>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
