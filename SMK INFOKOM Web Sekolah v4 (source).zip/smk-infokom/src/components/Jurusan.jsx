import { Link } from 'react-router-dom'
import { useList } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

export default function Jurusan({ dark = true, showIntro = true }) {
  const { items: PROGRAMS, loading } = useList('jurusan')
  return (
    <section id="jurusan" className={dark ? 'bg-navy py-24 md:py-28' : 'bg-paper py-24 md:py-28'}>
      <div className="container-page">
        {showIntro && (
          <div className="flex items-end justify-between flex-wrap gap-6 mb-14">
            <div>
              <p className={`eyebrow-code mb-4 ${dark ? 'text-amber' : ''}`}>02 / PROGRAM KEAHLIAN</p>
              <h2 className={`section-heading max-w-lg ${dark ? 'text-paper' : ''}`}>
                Jalur keahlian dengan satu tujuan: siap kerja sejak hari pertama.
              </h2>
            </div>
            <p className={`max-w-xs text-[15px] leading-relaxed ${dark ? 'text-paper/60' : 'text-ink/60'}`}>
              Setiap program keahlian memiliki kelas industri dengan kurikulum yang
              disusun bersama mitra perusahaan.
            </p>
          </div>
        )}

        {loading && <p className={dark ? 'text-paper/50' : 'text-ink/50'}>Memuat program keahlian…</p>}
        <div className="grid md:grid-cols-2 gap-6">
          {PROGRAMS.map((p) => (
            <Link
              key={p.kode}
              to={`/jurusan/${p.slug}`}
              className={`group block rounded-2xl overflow-hidden shadow-card hover:shadow-elegant hover:-translate-y-1 transition-all duration-300 ${
                dark ? 'bg-navy-light' : 'bg-paper border border-hairline'
              }`}
            >
              <div className="relative aspect-[16/8] overflow-hidden">
                <img
                  src={assetUrl(p.gambar || '/images/hero/jurusan.jpg')}
                  alt={p.nama}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/90 via-navy/10 to-transparent" />
                <span className="absolute top-4 left-4 pill bg-amber text-navy font-semibold">{p.kode}</span>
              </div>

              <div className="p-7 md:p-8">
                <h3 className={`font-display text-xl md:text-[1.4rem] ${dark ? 'text-paper' : 'text-ink'}`}>
                  {p.nama}
                </h3>
                <p className={`mt-3 text-[14.5px] leading-relaxed ${dark ? 'text-paper/60' : 'text-ink/60'}`}>
                  {p.deskripsi}
                </p>
                <ul className="mt-6 flex flex-wrap gap-2">
                  {p.skills.map((s) => (
                    <li
                      key={s}
                      className={`pill border ${
                        dark ? 'text-paper/70 border-navy-line' : 'text-ink/70 border-hairline'
                      }`}
                    >
                      {s}
                    </li>
                  ))}
                </ul>
                <span
                  className={`inline-flex items-center gap-2 mt-6 text-[13.5px] font-medium ${
                    dark ? 'text-amber' : 'text-teal group-hover:text-amber'
                  }`}
                >
                  Lihat detail jurusan
                  <svg width="14" height="10" viewBox="0 0 14 10" fill="none" className="transition-transform group-hover:translate-x-1">
                    <path d="M0 5 H13 M8 1 L13 5 L8 9" stroke="currentColor" strokeWidth="1.4" />
                  </svg>
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
