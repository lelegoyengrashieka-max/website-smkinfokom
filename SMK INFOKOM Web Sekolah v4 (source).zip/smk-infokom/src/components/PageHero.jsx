import { Link } from 'react-router-dom'
import { useSettings } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'
import { AutoVideo } from './Media.jsx'

const tc = (x) => String(x).toLowerCase().replace(/(^|\s)\S/g, (m) => m.toUpperCase()).replace(/\bppdb\b/gi, 'PPDB')

/**
 * Header halaman: latar krem bergaris kisi, judul serif besar di kiri,
 * foto/video berbingkai dengan bayangan keras di kanan.
 */
export default function PageHero({ eyebrow, title, desc, image, video, banner, crumbs, children }) {
  const st = useSettings()
  if (banner && st[`banner_${banner}`]) image = st[`banner_${banner}`]
  image = assetUrl(image)
  const trail = crumbs || [{ label: eyebrow ? tc(String(eyebrow).split('/')[0].split('·')[0].trim()) : title }]
  const hasMedia = image || video
  return (
    <section data-noreveal className="relative overflow-hidden border-b-[1.5px] border-brand bg-cream">
      <div aria-hidden="true" className="bg-grid-dark pointer-events-none absolute inset-0" />
      <div className={`container-page relative grid gap-10 py-12 md:py-16 ${hasMedia ? 'lg:grid-cols-[1.15fr_0.85fr] lg:items-center lg:gap-14' : ''}`}>
        <div>
          <nav aria-label="Breadcrumb" className="mb-8 flex flex-wrap items-center gap-2 font-mono text-[11.5px] uppercase tracking-[0.12em] text-muted animate-[reveal_0.5s_ease-out_both]">
            <Link to="/" className="hover:text-brand">Beranda</Link>
            {trail.map((c, i) => (
              <span key={i} className="flex items-center gap-2">
                <span aria-hidden="true" className="text-brand/30">/</span>
                {c.to ? <Link to={c.to} className="hover:text-brand">{c.label}</Link> : <span className="text-brand">{c.label}</span>}
              </span>
            ))}
          </nav>
          {eyebrow && <p className="eyebrow animate-[reveal_0.6s_ease-out_0.05s_both]">{eyebrow}</p>}
          <h1 className="mt-5 max-w-3xl font-display text-[2.6rem] font-bold leading-[1] tracking-[-0.025em] text-brand md:text-[4.2rem] animate-[reveal_0.7s_cubic-bezier(.16,1,.3,1)_0.1s_both]">{title}</h1>
          {desc && <p className="mt-6 max-w-xl text-[17.5px] leading-relaxed text-ink/70 animate-[reveal_0.7s_ease-out_0.2s_both]">{desc}</p>}
          {children && <div className="page-hero-actions mt-9 flex flex-wrap gap-3 animate-[reveal_0.7s_ease-out_0.3s_both]">{children}</div>}
        </div>
        {hasMedia && (
          <div className="relative animate-[reveal_0.8s_cubic-bezier(.16,1,.3,1)_0.2s_both]">
            <div aria-hidden="true" className="absolute -right-3 -top-3 h-24 w-24 bg-lime md:-right-5 md:-top-5" />
            <div className="relative aspect-[4/3] overflow-hidden border-[1.5px] border-brand bg-brand shadow-hard md:aspect-[5/4]">
              {video ? <AutoVideo src={video} poster={image} className="absolute inset-0 h-full w-full object-cover" />
                : <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" loading="eager" />}
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
