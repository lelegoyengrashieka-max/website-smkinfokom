import { useEffect, useRef, useState } from 'react'
import { Play } from 'lucide-react'
import { assetUrl } from '../lib/api.js'

const reduced = () => typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

/** Mengenali tautan YouTube dan mengembalikan ID videonya. */
export function youtubeId(url = '') {
  const m = String(url).match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/)
  return m ? m[1] : null
}

/** Video latar tanpa suara, berulang. Menampilkan poster saja bila pengguna memilih kurangi gerakan. */
export function AutoVideo({ src, poster, className = '', alt = '' }) {
  const ref = useRef(null)
  const [still] = useState(reduced)
  useEffect(() => {
    const v = ref.current
    if (!v) return
    const io = new IntersectionObserver(([e]) => { e.isIntersecting ? v.play().catch(() => {}) : v.pause() }, { threshold: 0.1 })
    io.observe(v)
    return () => io.disconnect()
  }, [src])
  if (!src || still || youtubeId(src)) return poster ? <img src={assetUrl(poster)} alt={alt} className={className} /> : null
  return (
    <video ref={ref} className={className} src={assetUrl(src)} poster={assetUrl(poster)} muted loop playsInline autoPlay preload="metadata" aria-hidden="true" />
  )
}

/** Pemutar video profil: poster + tombol putar, mendukung file .mp4 maupun tautan YouTube. */
export function VideoPlayer({ src, poster, title = 'Video', caption, className = '' }) {
  const [playing, setPlaying] = useState(false)
  const yt = youtubeId(src)
  const vref = useRef(null)
  useEffect(() => { if (playing && vref.current) vref.current.play().catch(() => {}) }, [playing])
  if (!src) return null
  const posterUrl = assetUrl(poster) || (yt ? `https://i.ytimg.com/vi/${yt}/hqdefault.jpg` : '')
  return (
    <figure className={`group relative overflow-hidden rounded-2xl bg-brand shadow-elegant ${className}`}>
      <div className="relative aspect-video">
        {playing ? (
          yt ? (
            <iframe className="absolute inset-0 h-full w-full" src={`https://www.youtube-nocookie.com/embed/${yt}?autoplay=1&rel=0`} title={title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
          ) : (
            <video ref={vref} className="absolute inset-0 h-full w-full bg-black object-cover" src={assetUrl(src)} poster={posterUrl} controls playsInline />
          )
        ) : (
          <button type="button" onClick={() => setPlaying(true)} className="absolute inset-0 block w-full text-left" aria-label={`Putar ${title}`}>
            {posterUrl && <img src={posterUrl} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-105" />}
            <span className="absolute inset-0 bg-gradient-to-t from-brand/85 via-brand/20 to-transparent" />
            <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <span className="absolute inset-0 rounded-full bg-white/40 animate-ping-slow" />
              <span className="relative grid h-14 w-14 place-items-center sm:h-20 sm:w-20 rounded-full bg-accent text-white shadow-glow transition-transform duration-300 group-hover:scale-110">
                <Play className="ml-1 h-6 w-6 fill-current sm:h-8 sm:w-8" />
              </span>
            </span>
            <span className="absolute bottom-0 left-0 right-0 hidden p-6 sm:block">
              <span className="block text-[12px] font-bold uppercase tracking-[0.14em] text-[#D4EE4E]">Tonton video</span>
              <span className="mt-1 block font-display text-xl font-bold text-white md:text-2xl">{title}</span>
            </span>
          </button>
        )}
      </div>
      {!playing && <figcaption className="bg-brand px-5 py-4 sm:hidden"><span className="block text-[11px] font-bold uppercase tracking-[0.14em] text-[#D4EE4E]">Tonton video</span><span className="mt-1 block font-display text-[1.05rem] font-bold leading-snug text-white">{title}</span></figcaption>}
      {caption && <figcaption className="bg-white px-6 py-4 text-[14px] text-muted">{caption}</figcaption>}
    </figure>
  )
}
