import { useSettings } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

/** Logo: huruf "i" di dalam kotak + dua gelombang sinyal — informatika & komunikasi. */
export function LogoMark({ className = 'h-10 w-10' }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true" fill="none">
      <rect x="1" y="1" width="38" height="38" rx="3" fill="#0E3326" />
      <rect x="9" y="16" width="6" height="16" fill="#F5F1E8" />
      <rect x="9" y="8" width="6" height="5.5" fill="#D4EE4E" />
      <path d="M21 32a11 11 0 0 1 11-11" stroke="#D4EE4E" strokeWidth="3.2" />
      <path d="M26.5 32a5.5 5.5 0 0 1 5.5-5.5" stroke="#F5F1E8" strokeWidth="3.2" />
    </svg>
  )
}

export default function Logo({ light = false }) {
  const st = useSettings()
  return (
    <span className="flex items-center gap-3" aria-label={st.nama_sekolah || 'SMK INFOKOM'}>
      {st.logo ? <img src={assetUrl(st.logo)} alt="" className="h-10 w-10 object-contain" /> : <LogoMark />}
      <span className="leading-none">
        <span className={`block font-display text-[21px] font-bold tracking-[-0.01em] ${light ? 'text-cream' : 'text-brand'}`}>{st.nama_sekolah || 'SMK INFOKOM'}</span>
        <span className={`mt-1 block font-mono text-[10.5px] font-medium uppercase tracking-[0.18em] ${light ? 'text-cream/55' : 'text-muted'}`}>Informatika · Komunikasi</span>
      </span>
    </span>
  )
}
