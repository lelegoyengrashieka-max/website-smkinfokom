import { useList } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

export default function Fasilitas() {
  const { items: FASILITAS } = useList('fasilitas')
  const withImg = FASILITAS.filter((f) => f.gambar)
  return (
    <>
    {withImg.length > 0 && (
      <section className="bg-paper pt-20">
        <div className="container-page grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {withImg.map((f) => (
            <figure key={f.id} className="card-elegant overflow-hidden rounded-2xl bg-white">
              <img src={assetUrl(f.gambar)} alt={f.ruang} loading="lazy" className="aspect-[4/3] w-full object-cover" />
              <figcaption className="p-5">
                <p className="font-display text-lg text-ink">{f.ruang}</p>
                {f.deskripsi && <p className="mt-1.5 text-[14px] leading-relaxed text-ink/60">{f.deskripsi}</p>}
              </figcaption>
            </figure>
          ))}
        </div>
      </section>
    )}
    <section id="fasilitas" className="bg-paper py-24 md:py-28 border-t border-hairline">
      <div className="container-page grid md:grid-cols-[1fr_1.2fr] gap-14">
        <div>
          <p className="eyebrow-code mb-4">DAFTAR RUANG</p>
          <h2 className="section-heading max-w-sm">
            Ruang praktik yang menyerupai tempat kerja sesungguhnya.
          </h2>
          <p className="mt-6 text-ink/65 leading-relaxed max-w-sm text-[15px]">
            Seluruh laboratorium terhubung jaringan gigabit dan diperbarui berkala
            mengikuti standar perangkat yang dipakai mitra industri kami.
          </p>
        </div>

        <div>
          <div className="grid grid-cols-[1fr_auto_auto] gap-x-6 gap-y-0 border-t border-ink/15 font-mono text-[12px] text-ink/40 pb-3 pt-3">
            <span>RUANG</span>
            <span>UNIT</span>
            <span>KAPASITAS</span>
          </div>
          {FASILITAS.map((f) => (
            <div
              key={f.id}
              className="grid grid-cols-[1fr_auto_auto] gap-x-6 items-center border-t border-hairline py-4"
            >
              <span className="text-[15px] text-ink">
                {f.ruang}
                {f.deskripsi && !f.gambar && <span className="block text-[13px] text-ink/50 mt-0.5">{f.deskripsi}</span>}
              </span>
              <span className="font-mono text-[13px] text-ink/50 justify-self-end">{f.unit}</span>
              <span className="font-mono text-[13px] text-ink/50 justify-self-end w-20 text-right">
                {f.kapasitas}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
    </>
  )
}
