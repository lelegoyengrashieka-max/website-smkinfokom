import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { ChevronDown, Menu, X, ArrowUpRight } from 'lucide-react'
import { useSettings, useList, pairs } from '../lib/data.jsx'
import Logo from './Logo.jsx'

function buildMenu(jurusan, portal) {
  return [
    { label: 'Beranda', to: '/' },
    {
      label: 'Profil',
      groups: [
        { heading: 'Tentang Sekolah', items: [
          { label: 'Profil & Sejarah', to: '/profil' },
          { label: 'Visi & Misi', to: '/profil#visi-misi' },
          { label: 'Struktur Organisasi', to: '/profil#struktur' },
          { label: 'Tim Guru', to: '/profil#tim-guru' },
        ] },
        { heading: 'Kesiswaan', items: [
          { label: 'Ekstrakurikuler', to: '/profil#ekstrakurikuler' },
          { label: 'Prestasi', to: '/profil#prestasi' },
          { label: 'Tata Tertib', to: '/profil#tata-tertib' },
        ] },
        { heading: 'Akademik', items: [
          { label: 'Kurikulum', to: '/kurikulum' },
          { label: 'Sarana & Prasarana', to: '/fasilitas' },
          { label: 'Manajemen Mutu', to: '/manajemen-mutu' },
        ] },
      ],
    },
    {
      label: 'Jurusan',
      items: [...jurusan.map((p) => ({ label: p.nama, to: `/jurusan/${p.slug}` })), { label: 'Semua Jurusan', to: '/jurusan' }],
    },
    {
      label: 'Karier',
      groups: [
        { heading: 'Bursa Kerja Khusus', items: [
          { label: 'Tentang BKK', to: '/bkk' },
          { label: 'Lowongan Kerja', to: '/bkk#lowongan' },
          { label: 'Video Kegiatan BKK', to: '/bkk#video' },
          { label: 'Registrasi Alumni', to: '/bkk#registrasi' },
          { label: 'Tracer Study', to: '/hubinmas#tracer-study' },
        ] },
        { heading: 'Magang ke Jepang', items: [
          { label: 'Tentang Program', to: '/magang-jepang' },
          { label: 'Bidang Kerja', to: '/magang-jepang#bidang' },
          { label: 'Video Magang', to: '/magang-jepang#video' },
          { label: 'Daftar Magang', to: '/magang-jepang/daftar' },
          { label: 'Cek Status Seleksi', to: '/magang-jepang/cek-status' },
        ] },
        { heading: 'Hubungan Industri', items: [
          { label: 'Hubinmas', to: '/hubinmas' },
          { label: 'Praktik Kerja Lapangan', to: '/hubinmas#pkl' },
          { label: 'Mitra Industri', to: '/hubinmas#kemitraan' },
        ] },
      ],
    },
    {
      label: 'PPDB',
      items: [
        { label: 'Informasi Pendaftaran', to: '/ppdb' },
        { label: 'Daftar Online', to: '/ppdb/daftar' },
        { label: 'Cek Status Pendaftaran', to: '/ppdb/cek-status' },
      ],
    },
    {
      label: 'Informasi',
      items: [
        { label: 'Berita & Pengumuman', to: '/berita' },
        { label: 'Galeri', to: '/galeri' },
        { label: 'Pusat Unduhan', to: '/unduhan' },
        ...portal.map((p) => ({ label: p.label, to: p.value, external: true })),
      ],
    },
    { label: 'Kontak', to: '/kontak' },
  ]
}

function MenuLink({ it, onClick, className }) {
  if (it.external) {
    return (
      <a href={it.to} target="_blank" rel="noopener noreferrer" className={`${className} flex items-center justify-between gap-3`}>
        {it.label}<ArrowUpRight className="h-3.5 w-3.5 opacity-60" />
      </a>
    )
  }
  return <Link to={it.to} onClick={onClick} className={className}>{it.label}</Link>
}

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const [mobileGroup, setMobileGroup] = useState(null)
  const settings = useSettings()
  const { items: jurusan } = useList('jurusan')
  const MENU = buildMenu(jurusan, pairs(settings.portal_links))
  const loc = useLocation()

  useEffect(() => { setOpen(false) }, [loc.pathname, loc.hash])
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const isActive = (m) => {
    const paths = [m.to, ...(m.items || []).map((i) => i.to), ...(m.groups || []).flatMap((g) => g.items.map((i) => i.to))]
      .filter(Boolean).map((p) => p.split('#')[0].split('?')[0])
    return paths.some((p) => (p === '/' ? loc.pathname === '/' : loc.pathname === p || loc.pathname.startsWith(p + '/')))
  }

  return (
    <header className={`sticky top-0 z-40 border-b-[1.5px] border-brand bg-cream/95 backdrop-blur transition-shadow ${scrolled ? 'shadow-[0_6px_0_-4px_rgba(14,51,38,0.12)]' : ''}`}>
      <div className="container-page flex h-[76px] items-center justify-between gap-6">
        <Link to="/" className="shrink-0"><Logo /></Link>

        <nav className="hidden xl:flex h-full items-stretch" aria-label="Menu utama">
          {MENU.map((m) => (
            <div key={m.label} className="group relative flex items-stretch">
              {m.to ? (
                <NavLink to={m.to} end={m.to === '/'}
                  className={({ isActive: a }) => `relative flex items-center px-3.5 text-[14.5px] font-bold transition-colors ${a ? 'text-brand after:absolute after:inset-x-3.5 after:bottom-0 after:h-[4px] after:bg-lime' : 'text-ink/70 hover:text-brand'}`}>
                  {m.label}
                </NavLink>
              ) : (
                <button type="button" className={`relative inline-flex items-center gap-1 px-3.5 text-[14.5px] font-bold transition-colors ${isActive(m) ? 'text-brand after:absolute after:inset-x-3.5 after:bottom-0 after:h-[4px] after:bg-lime' : 'text-ink/70 hover:text-brand'}`}>
                  {m.label}<ChevronDown className="h-3.5 w-3.5 transition-transform group-hover:rotate-180" />
                </button>
              )}
              {m.items && (
                <div className="invisible absolute left-0 top-full z-50 pt-0 opacity-0 transition-all duration-150 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                  <div className="min-w-[260px] border-[1.5px] border-brand bg-cream shadow-hard">
                    {m.items.map((it, i) => (
                      <MenuLink key={it.label} it={it} className={`flex items-center gap-3 px-4 py-3 text-[14px] font-medium text-ink/85 hover:bg-lime hover:text-brand ${i ? 'border-t border-brand/10' : ''}`} />
                    ))}
                  </div>
                </div>
              )}
              {m.groups && (
                <div className="invisible absolute left-1/2 top-full z-50 -translate-x-1/2 opacity-0 transition-all duration-150 group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                  <div className="grid w-[760px] grid-cols-3 divide-x divide-brand/15 border-[1.5px] border-brand bg-cream shadow-hard">
                    {m.groups.map((g, gi) => (
                      <div key={g.heading} className="p-4">
                        <p className="flex items-center gap-2 px-2 pb-3 font-mono text-[11px] font-medium uppercase tracking-[0.16em] text-muted"><span className="text-brand-600">0{gi + 1}</span>{g.heading}</p>
                        {g.items.map((it) => (
                          <MenuLink key={it.label} it={it} className="block px-2 py-2 text-[14px] font-medium text-ink/85 hover:bg-lime hover:text-brand" />
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="hidden xl:flex items-center gap-2">
          <Link to="/ppdb/daftar" className="btn-primary !py-2.5 !px-5 !text-[14px]">Daftar PPDB</Link>
        </div>

        <button type="button" aria-label={open ? 'Tutup menu' : 'Buka menu'} aria-expanded={open} onClick={() => setOpen((v) => !v)}
          className="xl:hidden -mr-1 grid h-11 w-11 place-items-center border-[1.5px] border-brand text-brand hover:bg-lime">
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="xl:hidden max-h-[calc(100vh-76px)] overflow-y-auto border-t-[1.5px] border-brand bg-cream">
          <nav className="container-page flex flex-col py-3" aria-label="Menu seluler">
            {MENU.map((m, mi) => (
              <div key={m.label} className="border-b border-brand/15 last:border-0">
                {m.to ? (
                  <Link to={m.to} className="flex items-baseline gap-4 py-4 font-display text-[22px] font-bold text-brand"><span className="idx">0{mi + 1}</span>{m.label}</Link>
                ) : (
                  <>
                    <button type="button" onClick={() => setMobileGroup(mobileGroup === m.label ? null : m.label)} aria-expanded={mobileGroup === m.label}
                      className="flex w-full items-center justify-between py-4 font-display text-[22px] font-bold text-brand">
                      <span className="flex items-baseline gap-4"><span className="idx">0{mi + 1}</span>{m.label}</span><ChevronDown className={`h-5 w-5 transition-transform ${mobileGroup === m.label ? 'rotate-180' : ''}`} />
                    </button>
                    {mobileGroup === m.label && (
                      <div className="space-y-0.5 pb-4 pl-9">
                        {(m.items || []).map((it) => <MenuLink key={it.label} it={it} className="block px-3 py-2 text-[15px] text-ink/75 hover:bg-lime" />)}
                        {(m.groups || []).map((g) => (
                          <div key={g.heading} className="pt-2">
                            <p className="px-3 pb-1 font-mono text-[11px] uppercase tracking-[0.16em] text-muted">{g.heading}</p>
                            {g.items.map((it) => <MenuLink key={it.label} it={it} className="block px-3 py-2 text-[15px] text-ink/75 hover:bg-lime" />)}
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            ))}
            <Link to="/ppdb/daftar" className="btn-primary mt-4 mb-3">Daftar PPDB {settings.ppdb_tahun}</Link>
          </nav>
        </div>
      )}
    </header>
  )
}
