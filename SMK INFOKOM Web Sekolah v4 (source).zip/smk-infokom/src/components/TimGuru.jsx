import { useMemo, useState } from 'react'
import { useList, useSettings } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

/** Urutan & label kelompok. Kepala Sekolah tampil bersama Wakasek di bagian "Pimpinan". */
const GROUPS = [
  { key: 'pimpinan', label: 'Pimpinan & Wakasek', title: 'Kepala Sekolah & Wakil Kepala Sekolah', desc: 'Memimpin arah kurikulum, kesiswaan, sarana, dan hubungan industri.', match: ['Kepala Sekolah', 'Wakasek'] },
  { key: 'guru', label: 'Guru', title: 'Guru', desc: 'Guru produktif, normatif, dan adaptif — banyak di antaranya praktisi aktif di industri.', match: ['Guru'] },
  { key: 'staf', label: 'Staf', title: 'Staf & Tenaga Kependidikan', desc: 'Tata usaha, operator, perpustakaan, dan layanan yang menjaga sekolah tetap berjalan.', match: ['Staf'] },
]

/** Cadangan untuk data lama yang belum punya kelompok. */
function kelompok(g) {
  if (g.kategori) return g.kategori
  const j = String(g.jabatan || '').toLowerCase()
  if (/^kepala sekolah/.test(j)) return 'Kepala Sekolah'
  if (/wakil kepala|wakasek/.test(j)) return 'Wakasek'
  if (/guru|kepala program|pengajar/.test(j)) return 'Guru'
  return 'Staf'
}

const initials = (n = '') => n.replace(/^(Dr|Drs|Ir|Hj?)\.?\s+/i, '').split(' ').map((w) => w[0]).slice(0, 2).join('')

function PersonCard({ g, big = false }) {
  return (
    <figure className="group">
      <div className={`relative overflow-hidden border-[1.5px] border-brand bg-brand-100 transition-all duration-300 group-hover:-translate-x-[3px] group-hover:-translate-y-[3px] group-hover:shadow-hard ${big ? 'aspect-[4/5]' : 'aspect-[4/5]'}`}>
        {g.foto ? (
          <img src={assetUrl(g.foto)} alt={g.nama} loading="lazy" className="h-full w-full object-cover grayscale-[35%] transition-all duration-500 group-hover:grayscale-0" />
        ) : (
          <div className="grid h-full w-full place-items-center bg-brand font-display text-5xl font-bold text-lime">{initials(g.nama)}</div>
        )}
        {kelompok(g) === 'Kepala Sekolah' && <span className="absolute left-0 top-0 border-b-[1.5px] border-r-[1.5px] border-brand bg-lime px-2.5 py-1 font-mono text-[10.5px] uppercase tracking-[0.12em] text-brand">Kepala Sekolah</span>}
      </div>
      <figcaption className="mt-3 border-l-[3px] border-lime pl-3">
        <p className={`font-display font-bold leading-snug text-brand ${big ? 'text-[1.25rem]' : 'text-[1.05rem]'}`}>{g.nama}</p>
        <p className="mt-1 text-[13px] font-medium leading-snug text-ink/75">{g.jabatan}</p>
        {g.bidang && <p className="mt-0.5 font-mono text-[11px] uppercase tracking-[0.06em] text-muted">{g.bidang}</p>}
      </figcaption>
    </figure>
  )
}

export default function TimGuru() {
  const { items } = useList('guru', { limit: 200 })
  const st = useSettings()
  const [tab, setTab] = useState('semua')

  const grouped = useMemo(() => GROUPS.map((gr) => {
    const list = items.filter((g) => gr.match.includes(kelompok(g)))
    // Kepala Sekolah selalu paling depan di kelompok pimpinan
    list.sort((a, b) => (kelompok(a) === 'Kepala Sekolah' ? -1 : 0) - (kelompok(b) === 'Kepala Sekolah' ? -1 : 0))
    return { ...gr, list }
  }).filter((gr) => gr.list.length), [items])

  const shown = tab === 'semua' ? grouped : grouped.filter((g) => g.key === tab)

  return (
    <section id="tim-guru" className="scroll-mt-24 border-y-[1.5px] border-brand bg-cream py-20 md:py-28">
      <div className="container-page">
        <div className="flex flex-col gap-8 border-b-[1.5px] border-brand pb-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <p className="eyebrow">Guru & Staf</p>
            <h2 className="section-heading mt-4">Orang-orang di balik {st.nama_sekolah || 'sekolah'}.</h2>
            <p className="mt-4 text-[16px] leading-relaxed text-ink/70">Pimpinan, guru bersertifikat kompetensi, dan tenaga kependidikan yang mendampingi siswa dari kelas hingga dunia kerja.</p>
          </div>
          <div role="tablist" aria-label="Kelompok guru dan staf" className="flex flex-wrap border-[1.5px] border-brand bg-white">
            {[{ key: 'semua', label: 'Semua', n: items.length }, ...grouped.map((g) => ({ key: g.key, label: g.label, n: g.list.length }))].map((t, i) => (
              <button key={t.key} type="button" role="tab" aria-selected={tab === t.key} onClick={() => setTab(t.key)}
                className={`flex items-center gap-2 px-4 py-2.5 text-[14px] font-bold transition-colors ${i ? 'border-l-[1.5px] border-brand' : ''} ${tab === t.key ? 'bg-brand text-cream' : 'text-brand hover:bg-lime'}`}>
                {t.label}<span className={`font-mono text-[11px] ${tab === t.key ? 'text-lime' : 'text-muted'}`}>{t.n}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 space-y-16">
          {shown.map((gr, gi) => (
            <div key={gr.key} className="pt-10">
              <div className="mb-8 grid gap-3 md:grid-cols-[auto_1fr_auto] md:items-baseline md:gap-6">
                <span className="font-mono text-[12px] text-brand-600">{String(GROUPS.findIndex((x) => x.key === gr.key) + 1).padStart(2, '0')}</span>
                <div>
                  <h3 className="font-display text-[1.9rem] font-bold leading-tight text-brand md:text-[2.3rem]">{gr.title}</h3>
                  <p className="mt-1 max-w-xl text-[14.5px] text-ink/65">{gr.desc}</p>
                </div>
                <span className="idx">{gr.list.length} orang</span>
              </div>
              <div className={`grid gap-x-6 gap-y-10 ${gr.key === 'pimpinan' ? 'grid-cols-2 md:grid-cols-4' : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'}`}>
                {gr.list.map((g) => <PersonCard key={g.id} g={g} big={gr.key === 'pimpinan'} />)}
              </div>
              {gi < shown.length - 1 && <div className="mt-16 border-b border-dashed border-brand/30" aria-hidden="true" />}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
