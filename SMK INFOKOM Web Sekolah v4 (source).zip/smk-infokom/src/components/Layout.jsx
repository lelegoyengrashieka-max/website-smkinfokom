import { Outlet, useLocation } from 'react-router-dom'
import { useAutoReveal } from '../lib/motion.jsx'
import TopBar from './TopBar.jsx'
import Navbar from './Navbar.jsx'
import Footer from './Footer.jsx'
import ScrollToTop from './ScrollToTop.jsx'
import WhatsAppButton from './WhatsAppButton.jsx'

export default function Layout() {
  const { pathname } = useLocation()
  useAutoReveal(pathname)
  return (
    <div className="flex min-h-screen flex-col bg-cream font-body text-ink">
      <a href="#konten" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-brand focus:px-4 focus:py-2 focus:text-white">Lewati ke konten</a>
      <ScrollToTop />
      <TopBar />
      <Navbar />
      <main id="konten" className="flex-1"><Outlet /></main>
      <Footer />
      <WhatsAppButton />
    </div>
  )
}
