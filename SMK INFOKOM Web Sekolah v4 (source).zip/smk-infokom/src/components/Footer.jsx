import { Link } from 'react-router-dom'
import { MapPin, Phone, Mail, Facebook, Instagram, Youtube, Music2, ArrowUpRight } from 'lucide-react'
import { useSettings } from '../lib/data.jsx'
import Logo from './Logo.jsx'

const COLUMNS = [
  { h: 'Sekolah', items: [['Profil', '/profil'], ['Guru & Staf', '/profil#tim-guru'], ['Jurusan', '/jurusan'], ['Kurikulum', '/kurikulum'], ['Sarana & Prasarana', '/fasilitas'], ['Manajemen Mutu', '/manajemen-mutu']] },
  { h: 'Karier', items: [['Bursa Kerja Khusus', '/bkk'], ['Lowongan Kerja', '/bkk#lowongan'], ['Magang ke Jepang', '/magang-jepang'], ['Daftar Magang Jepang', '/magang-jepang/daftar'], ['Hubinmas & PKL', '/hubinmas']] },
  { h: 'Layanan', items: [['PPDB Online', '/ppdb'], ['Cek Status PPDB', '/ppdb/cek-status'], ['Berita', '/berita'], ['Galeri', '/galeri'], ['Pusat Unduhan', '/unduhan'], ['Kontak', '/kontak']] },
]
const SOS = { facebook: Facebook, instagram: Instagram, youtube: Youtube, tiktok: Music2 }

export default function Footer() {
  const st = useSettings()
  const nama = st.nama_sekolah || 'SMK INFOKOM'
  return (
    <footer className="grain relative overflow-hidden bg-brand text-cream">
      <div className="container-page relative z-[1]">
        <div className="grid gap-8 border-b border-cream/15 py-14 md:grid-cols-[1.4fr_1fr] md:items-end">
          <p className="font-display text-[2.3rem] font-bold leading-[1.02] tracking-[-0.02em] md:text-[3.4rem]">
            Masa depanmu dimulai <span className="hl-dark">di sini.</span>
          </p>
          <div className="flex flex-wrap gap-3 md:justify-end">
            <Link to="/ppdb/daftar" className="btn-primary !border-lime !shadow-none">Daftar PPDB <ArrowUpRight className="h-4 w-4" /></Link>
            <Link to="/kontak" className="btn-outline-light">Hubungi Kami</Link>
          </div>
        </div>
        <div className="grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo light />
            <p className="mt-5 max-w-xs text-[14.5px] leading-relaxed text-cream/60">{st.deskripsi_footer}</p>
            <ul className="mt-6 space-y-3 text-[14px] text-cream/75">
              {st.alamat && <li className="flex gap-3"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-lime" />{st.alamat}</li>}
              {st.telepon && <li className="flex gap-3"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-lime" />{st.telepon}</li>}
              {st.email && <li className="flex gap-3"><Mail className="mt-0.5 h-4 w-4 shrink-0 text-lime" />{st.email}</li>}
            </ul>
            <div className="mt-6 flex gap-2">
              {Object.entries(SOS).filter(([k]) => st[k]).map(([k, I]) => (
                <a key={k} href={st[k]} target="_blank" rel="noopener noreferrer" aria-label={k}
                  className="grid h-10 w-10 place-items-center border border-cream/25 text-cream/80 transition-colors hover:border-lime hover:bg-lime hover:text-brand">
                  <I className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          {COLUMNS.map((c, ci) => (
            <div key={c.h}>
              <p className="font-mono text-[11.5px] uppercase tracking-[0.16em] text-cream/45"><span className="text-lime">0{ci + 1}</span> / {c.h}</p>
              <ul className="mt-5 space-y-3">
                {c.items.map(([l, to]) => <li key={l}><Link to={to} className="text-[14.5px] text-cream/80 transition-colors hover:text-lime">{l}</Link></li>)}
              </ul>
            </div>
          ))}
        </div>
        <div className="flex flex-col gap-2 border-t border-cream/15 py-6 font-mono text-[11.5px] uppercase tracking-[0.08em] text-cream/45 sm:flex-row sm:justify-between">
          <span>© {new Date().getFullYear()} {nama}</span>
          <span>NPSN {st.npsn} · Akreditasi {st.akreditasi} · {st.kota}</span>
        </div>
      </div>
      <p aria-hidden="true" className="pointer-events-none relative z-0 -mb-[0.22em] select-none whitespace-nowrap text-center font-display text-[18vw] font-bold leading-none tracking-[-0.04em] text-cream/[0.05]">{nama}</p>
    </footer>
  )
}
