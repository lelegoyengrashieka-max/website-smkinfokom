import { useState } from 'react'
import { api } from '../lib/api.js'
import { useSettings, waLink } from '../lib/data.jsx'

const EMPTY = { nama: '', email: '', telepon: '', subjek: '', pesan: '', website: '' }

export default function Kontak() {
  const st = useSettings()
  const [form, setForm] = useState(EMPTY)
  const [status, setStatus] = useState({ state: 'idle', error: '', details: {} })

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus({ state: 'loading', error: '', details: {} })
    try {
      await api('/api/public/pesan', { method: 'POST', body: form })
      setStatus({ state: 'sent', error: '', details: {} })
    } catch (err) {
      setStatus({ state: 'idle', error: err.message, details: err.details || {} })
    }
  }

  const maps = st.maps_query || st.alamat
  const wa = waLink(st.whatsapp)

  return (
    <section id="kontak" className="bg-paper py-24 md:py-28 border-t border-hairline">
      <div className="container-page grid md:grid-cols-[0.9fr_1.1fr] gap-14">
        <div>
          <p className="eyebrow-code mb-4">INFORMASI SEKOLAH</p>

          <div className="space-y-8">
            <dl className="space-y-5 font-mono text-[13.5px]">
              <div>
                <dt className="text-ink/40">ALAMAT</dt>
                <dd className="text-ink mt-1 whitespace-pre-line">{st.alamat}</dd>
              </div>
              <div>
                <dt className="text-ink/40">TELEPON</dt>
                <dd className="text-ink mt-1"><a href={`tel:${String(st.telepon || '').replace(/[^\d+]/g, '')}`} className="hover:text-teal">{st.telepon}</a></dd>
              </div>
              {wa && (
                <div>
                  <dt className="text-ink/40">WHATSAPP</dt>
                  <dd className="text-ink mt-1"><a href={wa} target="_blank" rel="noopener noreferrer" className="hover:text-teal">+{String(st.whatsapp).replace(/\D/g, '')}</a></dd>
                </div>
              )}
              <div>
                <dt className="text-ink/40">EMAIL</dt>
                <dd className="text-ink mt-1"><a href={`mailto:${st.email}`} className="hover:text-teal">{st.email}</a></dd>
              </div>
            </dl>

            <div>
              <p className="font-mono text-ink/40 text-[13px] mb-2">JAM LAYANAN</p>
              <p className="text-[14.5px] text-ink">{st.jam_layanan}</p>
            </div>

            {maps && (
              <div className="relative aspect-[4/3] border border-hairline overflow-hidden">
                <iframe
                  title={`Lokasi ${st.nama_sekolah}`}
                  src={`https://www.google.com/maps?q=${encodeURIComponent(maps)}&output=embed`}
                  width="100%"
                  height="100%"
                  style={{ border: 0, filter: 'grayscale(0.15) contrast(1.05)' }}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="border border-hairline p-8 self-start" noValidate>
          {status.state === 'sent' ? (
            <div className="py-10 text-center">
              <p className="font-display text-xl">Pesan terkirim.</p>
              <p className="mt-2 text-ink/60 text-[14.5px]">Tim kami akan membalas ke {form.email} dalam 1×24 jam kerja.</p>
              <button type="button" className="btn-outline mt-6" onClick={() => { setForm(EMPTY); setStatus({ state: 'idle', error: '', details: {} }) }}>
                Kirim pesan lain
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <p className="font-display text-xl text-ink">Kirim pesan</p>
              <Field label="Nama Lengkap" name="nama" value={form.nama} onChange={handleChange} error={status.details.nama} required />
              <div className="grid sm:grid-cols-2 gap-6">
                <Field label="Email" name="email" type="email" value={form.email} onChange={handleChange} error={status.details.email} required />
                <Field label="No. HP (opsional)" name="telepon" value={form.telepon} onChange={handleChange} error={status.details.telepon} />
              </div>
              <Field label="Subjek" name="subjek" value={form.subjek} onChange={handleChange} error={status.details.subjek} />
              <div>
                <label className="font-mono text-[12px] text-ink/50" htmlFor="pesan">PESAN *</label>
                <textarea
                  id="pesan"
                  name="pesan"
                  rows={5}
                  value={form.pesan}
                  onChange={handleChange}
                  required
                  className="mt-2 w-full border border-hairline bg-transparent px-4 py-3 text-[15px] focus:border-navy outline-none transition-colors resize-none"
                />
                {status.details.pesan && <p className="mt-1.5 text-[12.5px] text-red-600">{status.details.pesan}</p>}
              </div>
              {/* honeypot anti-spam: disembunyikan dari pengguna */}
              <input type="text" name="website" value={form.website} onChange={handleChange} tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />
              {status.error && <p className="rounded-lg bg-red-50 px-4 py-3 text-[13.5px] text-red-700">{status.error}</p>}
              <button type="submit" disabled={status.state === 'loading'} className="btn-primary w-full justify-center disabled:opacity-60">
                {status.state === 'loading' ? 'Mengirim…' : 'Kirim Pesan'}
              </button>
            </div>
          )}
        </form>
      </div>
    </section>
  )
}

function Field({ label, name, value, onChange, type = 'text', error, required }) {
  return (
    <div>
      <label className="font-mono text-[12px] text-ink/50" htmlFor={name}>
        {label.toUpperCase()}{required ? ' *' : ''}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        required={required}
        className={`mt-2 w-full border bg-transparent px-4 py-3 text-[15px] focus:border-navy outline-none transition-colors ${error ? 'border-red-400' : 'border-hairline'}`}
      />
      {error && <p className="mt-1.5 text-[12.5px] text-red-600">{error}</p>}
    </div>
  )
}
