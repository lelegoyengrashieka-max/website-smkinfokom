import { useSettings, paragraphs } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

export default function SambutanKepsek() {
  const st = useSettings()
  const SAMBUTAN_KEPSEK = paragraphs(st.sambutan)
  return (
    <section className="bg-paper py-24 md:py-28">
      <div className="container-page grid md:grid-cols-[0.8fr_1.2fr] gap-14 items-start">
        <div className="md:sticky md:top-28">
          {st.kepsek_foto ? (
            <img src={assetUrl(st.kepsek_foto)} alt={st.kepsek_nama} className="aspect-[3/4] w-full object-cover rounded-2xl shadow-card" />
          ) : (
          <div className="aspect-[3/4] bg-navy border border-navy-line flex items-center justify-center">
            <svg width="120" height="140" viewBox="0 0 120 140" fill="none">
              <circle cx="60" cy="48" r="30" fill="#33456B" />
              <path d="M12 138 C12 100 32 82 60 82 C88 82 108 100 108 138 Z" fill="#33456B" />
              <circle cx="60" cy="48" r="30" fill="none" stroke="#E3A23C" strokeWidth="1.5" />
              <path d="M12 138 C12 100 32 82 60 82 C88 82 108 100 108 138" fill="none" stroke="#E3A23C" strokeWidth="1.5" />
            </svg>
          </div>
          )}
          <p className="mt-4 font-display text-[1.05rem]">{st.kepsek_nama}</p>
          <p className="font-mono text-teal text-[12.5px] mt-1">KEPALA SEKOLAH</p>
          {st.kepsek_keterangan && <p className="mt-2 text-[13px] text-ink/55">{st.kepsek_keterangan}</p>}
        </div>

        <div>
          <p className="eyebrow-code mb-4">SAMBUTAN</p>
          <h2 className="section-heading max-w-lg mb-8">
            {st.sambutan_judul}
          </h2>
          <div className="space-y-5">
            {SAMBUTAN_KEPSEK.map((p, i) => (
              <p key={i} className="text-[15px] text-ink/70 leading-[1.8]">
                {p}
              </p>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
