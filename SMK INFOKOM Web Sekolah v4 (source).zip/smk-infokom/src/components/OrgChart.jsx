import { useList } from '../lib/data.jsx'

function NodeBox({ nama, jabatan, accent = false }) {
  return (
    <div
      className={`w-[200px] px-4 py-4 text-center border ${
        accent ? 'bg-navy border-navy text-paper' : 'bg-paper border-hairline text-ink'
      }`}
    >
      <p className={`font-display text-[14px] leading-snug ${accent ? 'text-paper' : 'text-ink'}`}>{nama}</p>
      <p className={`mt-1.5 font-mono text-[11px] ${accent ? 'text-amber' : 'text-teal'}`}>{jabatan}</p>
    </div>
  )
}

export default function OrgChart() {
  const { items } = useList('struktur')
  const levels = [1, 2, 3, 4]
    .map((lv) => items.filter((x) => String(x.level) === String(lv)))
    .filter((row) => row.length)
  if (!levels.length) return null

  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex flex-col items-center min-w-[680px]">
        {levels.map((row, i) => (
          <div key={i} className="flex flex-col items-center">
            {i > 0 && <div className="w-px h-8 bg-hairline" />}
            <div className={`flex flex-wrap justify-center gap-10 ${i > 0 ? 'pt-8 border-t border-hairline' : ''}`}>
              {row.map((n) => (
                <NodeBox key={n.id} nama={n.nama} jabatan={n.jabatan} accent={i === 0} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
