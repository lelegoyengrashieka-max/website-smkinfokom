import { Link } from 'react-router-dom'
import { MapPin, CalendarClock, Wallet, Users } from 'lucide-react'
import { formatTanggal } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'

export function isExpired(l) {
  return l.deadline && l.deadline < new Date().toISOString().slice(0, 10)
}

export function LowonganStatus({ l }) {
  const closed = l.status !== 'dibuka' || isExpired(l)
  return closed
    ? <span className="rounded-full bg-surface px-2.5 py-1 text-[12px] font-semibold text-muted">Ditutup</span>
    : <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[12px] font-semibold text-emerald-700">Dibuka</span>
}

const initials = (n = '') => n.replace(/^PT\.?\s*/i, '').split(' ').map((w) => w[0]).slice(0, 2).join('')

export default function LowonganCard({ l }) {
  const closed = l.status !== 'dibuka' || isExpired(l)
  return (
    <Link to={`/bkk/lowongan/${l.slug}`} className={`group flex min-w-0 flex-col rounded-2xl border border-line bg-white p-6 transition-all hover:-translate-y-0.5 hover:border-brand/25 hover:shadow-card ${closed ? 'opacity-70' : ''}`}>
      <div className="flex items-start gap-4">
        {l.logo ? <img src={assetUrl(l.logo)} alt="" className="h-12 w-12 shrink-0 rounded-xl border border-line object-contain p-1" />
          : <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-50 font-display text-[15px] font-extrabold text-brand">{initials(l.perusahaan)}</span>}
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13.5px] font-semibold text-muted">{l.perusahaan}</p>
          <h3 className="mt-0.5 font-display text-[1.15rem] font-bold leading-snug text-brand group-hover:text-brand-600">{l.judul}</h3>
        </div>
        <LowonganStatus l={l} />
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <span className="pill bg-brand-50 text-brand-600">{l.tipe}</span>
        <span className="pill bg-surface text-ink/70">{l.bidang}</span>
      </div>
      <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-2 border-t border-line pt-4 text-[13.5px] text-muted">
        {l.lokasi && <div className="flex items-center gap-2"><MapPin className="h-4 w-4 shrink-0" /><span className="truncate">{l.lokasi}</span></div>}
        {l.gaji && <div className="flex items-center gap-2"><Wallet className="h-4 w-4 shrink-0" /><span className="truncate">{l.gaji}</span></div>}
        {l.deadline && <div className="flex items-center gap-2"><CalendarClock className="h-4 w-4 shrink-0" />s.d. {formatTanggal(l.deadline, 'pendek')}</div>}
        {l.kuota > 0 && <div className="flex items-center gap-2"><Users className="h-4 w-4 shrink-0" />{l.kuota} orang</div>}
      </dl>
    </Link>
  )
}
