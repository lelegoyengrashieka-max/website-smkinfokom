import { useSettings, lines } from '../lib/data.jsx'

export default function Tentang() {
  const st = useSettings()
  return (
    <section id="profil" className="bg-paper py-24 md:py-28">
      <div className="container-page">
        <div className="grid md:grid-cols-[0.85fr_1.15fr] gap-14">
          <div>
            <p className="eyebrow-code mb-4">01 / PROFIL SEKOLAH</p>
            <h2 className="section-heading">
              {st.about_heading}
            </h2>
            <p className="mt-6 text-ink/70 leading-relaxed max-w-sm">{st.about_desc}</p>
          </div>

          <div className="grid sm:grid-cols-2 gap-px bg-hairline border border-hairline">
            {[
              { k: 'VISI', v: st.visi },
              { k: 'AKREDITASI', v: `Terakreditasi ${st.akreditasi} — ${st.akreditasi_keterangan}.` },
              { k: 'KEPALA SEKOLAH', v: [st.kepsek_nama, st.kepsek_keterangan].filter(Boolean).join(' — ') },
              { k: 'NPSN', v: `${st.npsn} · Berdiri ${st.tahun_berdiri}` },
            ].map((item) => (
              <div key={item.k} className="bg-paper p-7">
                <p className="eyebrow-code text-navy/60">{item.k}</p>
                <p className="mt-3 text-[15px] text-ink/75 leading-relaxed">{item.v}</p>
              </div>
            ))}
          </div>
        </div>
        {lines(st.misi).length > 0 && (
          <div className="mt-14 border-t border-hairline pt-10">
            <p className="eyebrow-code mb-5">MISI</p>
            <ol className="grid md:grid-cols-2 gap-x-10 gap-y-4">
              {lines(st.misi).map((m, i) => (
                <li key={i} className="flex gap-4 text-[15px] text-ink/75 leading-relaxed">
                  <span className="font-mono text-[12px] text-teal pt-1">{String(i + 1).padStart(2, '0')}</span>
                  {m}
                </li>
              ))}
            </ol>
          </div>
        )}
      </div>
    </section>
  )
}
