import { Link } from 'react-router-dom'
import { useList, useSettings } from '../lib/data.jsx'

export default function Ppdb() {
  const st = useSettings()
  const { items: TAHAPAN_PPDB } = useList('tahapan')
  const dibuka = st.ppdb_dibuka !== 'false'
  return (
    <section id="ppdb" className="bg-ink py-20 md:py-24">
      <div className="container-page grid md:grid-cols-[1fr_1fr] gap-12 items-center">
        <div>
          <p className="eyebrow-code text-amber mb-4">PPDB {st.ppdb_tahun}</p>
          <h2 className="font-display text-paper text-3xl md:text-[2.4rem] leading-tight">
            {st.ppdb_heading}
          </h2>
          <p className="mt-5 text-paper/60 text-[15px] leading-relaxed max-w-sm">{st.ppdb_desc}</p>
          <Link to={dibuka ? '/ppdb/daftar' : '/kontak'} className="btn-primary bg-amber text-navy hover:bg-paper mt-8">
            {dibuka ? 'Mulai Pendaftaran' : 'Hubungi Kami'}
          </Link>
        </div>

        <div className="rounded-2xl border border-paper/15 bg-navy/40 overflow-hidden shadow-card">
          {TAHAPAN_PPDB.map((t, i) => (
            <div
              key={t.id}
              className="flex items-center justify-between px-6 py-4 border-b border-paper/15 last:border-0"
            >
              <div className="flex items-center gap-4">
                <span className="font-mono text-amber text-[12px]">{String(i + 1).padStart(2, '0')}</span>
                <span className="text-paper/85 text-[14.5px]">{t.label}</span>
              </div>
              <span className="font-mono text-paper/45 text-[12.5px]">{t.waktu}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
