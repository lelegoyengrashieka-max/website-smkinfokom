import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { useSettings, useList } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'

export default function LandingCta() {
  const st = useSettings()
  const { items: tahapan } = useList('tahapan')
  const dibuka = st.ppdb_dibuka !== 'false'
  return (
    <section className="bg-white pb-20 md:pb-28">
      <div className="container-page">
        <div className="grid border-[1.5px] border-brand bg-lime shadow-hard lg:grid-cols-[1.15fr_0.85fr]">
          <div className="p-8 text-brand md:p-14">
            <p className="font-mono text-[12px] uppercase tracking-[0.16em]">PPDB {st.ppdb_tahun} · {dibuka ? 'Dibuka' : 'Ditutup'}</p>
            <h2 className="mt-4 font-display text-[2.4rem] font-bold leading-[1.02] tracking-[-0.02em] md:text-[3.4rem]">{st.ppdb_heading}</h2>
            <p className="mt-5 max-w-md text-[16.5px] leading-relaxed text-brand/80">{st.ppdb_desc}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to={dibuka ? '/ppdb/daftar' : '/ppdb'} className="btn-dark">{dibuka ? 'Mulai Pendaftaran' : 'Info Pendaftaran'} <ArrowRight className="h-4 w-4" /></Link>
              <Link to="/ppdb/cek-status" className="btn-outline">Cek Status</Link>
            </div>
            {tahapan.length > 0 && (
              <ol className="mt-10 grid border-l-[1.5px] border-t-[1.5px] border-brand sm:grid-cols-2">
                {tahapan.slice(0, 4).map((t, i) => (
                  <li key={t.id} className="border-b-[1.5px] border-r-[1.5px] border-brand p-4">
                    <p className="font-mono text-[11px] uppercase tracking-[0.08em] text-brand/70">Tahap {i + 1} · {t.waktu}</p>
                    <p className="mt-1 text-[15px] font-bold">{t.label}</p>
                  </li>
                ))}
              </ol>
            )}
          </div>
          <div className="relative min-h-[300px] border-t-[1.5px] border-brand lg:border-l-[1.5px] lg:border-t-0">
            <img src={assetUrl(st.ppdb_image || '/images/hero/ppdb.jpg')} alt="Calon siswa mendaftar" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
          </div>
        </div>
      </div>
    </section>
  )
}
