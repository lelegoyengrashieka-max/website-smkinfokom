import { Link } from 'react-router-dom'
import { useList, useSettings, formatTanggal } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'
import { ArrowLink, Skeleton } from '../ui/index.jsx'

export default function LandingNews({ limit = 3 }) {
  const st = useSettings()
  const { items, loading } = useList('berita', { limit })
  const { items: agenda } = useList('agenda', { limit: 50 })
  const today = new Date().toISOString().slice(0, 10)
  const upcoming = agenda.filter((a) => (a.tanggal_selesai || a.tanggal) >= today).slice(0, 4)
  const [first, ...rest] = items

  return (
    <section className="border-t-[1.5px] border-brand bg-white py-20 md:py-28">
      <div className="container-page">
        <div className="flex flex-col gap-6 border-b-[3px] border-double border-brand pb-6 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="eyebrow">06 · Berita & Agenda</p>
            <h2 className="section-heading mt-4">Kabar terbaru dari {st.nama_sekolah || 'sekolah'}.</h2>
          </div>
          <ArrowLink to="/berita">Semua berita</ArrowLink>
        </div>
        {loading && <div className="mt-10 grid gap-6 lg:grid-cols-3"><Skeleton className="h-96" /><Skeleton className="h-96" /><Skeleton className="h-96" /></div>}
        {!loading && !items.length && <p className="mt-10 text-muted">Belum ada berita.</p>}
        {first && (
          <div className="mt-10 grid gap-10 lg:grid-cols-12">
            <article className="group lg:col-span-5">
              <Link to={`/berita/${first.slug}`} className="block aspect-[16/10] overflow-hidden border-[1.5px] border-brand bg-surface">
                {first.gambar && <img src={assetUrl(first.gambar)} alt={first.judul} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]" />}
              </Link>
              <p className="mt-5 font-mono text-[11.5px] uppercase tracking-[0.1em] text-muted"><span className="bg-lime px-1.5 py-0.5 text-brand">{first.kategori}</span> · {formatTanggal(first.tanggal, 'panjang')}</p>
              <h3 className="mt-3 font-display text-[2rem] font-bold leading-[1.1] text-brand"><Link to={`/berita/${first.slug}`} className="hover:underline hover:decoration-lime hover:decoration-4 hover:underline-offset-4">{first.judul}</Link></h3>
              <p className="mt-3 max-w-xl text-[16px] leading-relaxed text-ink/70">{first.ringkasan}</p>
            </article>
            <div className="lg:col-span-4 lg:border-l lg:border-brand/20 lg:pl-8">
              {rest.map((b) => (
                <article key={b.id} className="group border-b border-brand/20 pb-6 pt-6 first:pt-0">
                  <Link to={`/berita/${b.slug}`} className="block aspect-[16/10] overflow-hidden border border-brand/30 bg-surface">
                    {b.gambar && <img src={assetUrl(b.gambar)} alt="" loading="lazy" className="h-full w-full object-cover" />}
                  </Link>
                  <p className="mt-3 font-mono text-[11px] uppercase tracking-[0.1em] text-muted"><span className="text-brand-600">{b.kategori}</span> · {formatTanggal(b.tanggal, 'pendek')}</p>
                  <h3 className="mt-1.5 font-display text-[1.25rem] font-bold leading-snug text-brand"><Link to={`/berita/${b.slug}`} className="hover:underline hover:decoration-lime hover:decoration-4">{b.judul}</Link></h3>
                </article>
              ))}
            </div>
            <aside className="lg:col-span-3">
              <div className="border-[1.5px] border-brand bg-cream">
                <p className="border-b-[1.5px] border-brand bg-brand px-5 py-3 font-mono text-[11.5px] uppercase tracking-[0.14em] text-lime">Agenda Terdekat</p>
                {upcoming.length === 0 && <p className="p-5 text-[14px] text-muted">Belum ada agenda terdekat.</p>}
                <ul>
                  {upcoming.map((a) => {
                    const [y, m, d] = String(a.tanggal).slice(0, 10).split('-')
                    return (
                      <li key={a.id} className="grid grid-cols-[3.5rem_1fr] gap-3 border-b border-brand/15 px-5 py-4 last:border-0">
                        <span className="text-center">
                          <span className="block font-display text-[1.8rem] font-bold leading-none text-brand">{d}</span>
                          <span className="block font-mono text-[10.5px] uppercase text-muted">{formatTanggal(a.tanggal, 'pendek').split(' ')[1]} {y?.slice(2)}</span>
                        </span>
                        <span>
                          <span className="block text-[14.5px] font-bold leading-snug text-ink">{a.kegiatan}</span>
                          {a.lokasi && <span className="mt-1 block text-[12.5px] text-muted">{a.lokasi}</span>}
                        </span>
                      </li>
                    )
                  })}
                </ul>
              </div>
              <ArrowLink to="/kurikulum#kalender" className="mt-5 text-[14px]">Kalender pendidikan</ArrowLink>
            </aside>
          </div>
        )}
      </div>
    </section>
  )
}
