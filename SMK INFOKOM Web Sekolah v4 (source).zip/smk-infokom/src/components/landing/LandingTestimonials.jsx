import { useState } from 'react'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import { useList } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'

const initials = (n = '') => n.split(' ').map((w) => w[0]).slice(0, 2).join('')

export default function LandingTestimonials() {
  const { items } = useList('testimoni')
  const [i, setI] = useState(0)
  if (!items.length) return null
  const t = items[i % items.length]
  const go = (d) => setI((v) => (v + d + items.length) % items.length)
  return (
    <section className="bg-cream py-20 md:py-28">
      <div className="container-page">
        <div className="flex flex-col gap-6 border-b-[1.5px] border-brand pb-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="eyebrow">05 · Cerita Alumni</p>
            <h2 className="section-heading mt-4">Bukan janji brosur — cerita mereka yang sudah bekerja.</h2>
          </div>
          <div className="flex items-center gap-3">
            <span className="idx mr-2">{String((i % items.length) + 1).padStart(2, '0')} / {String(items.length).padStart(2, '0')}</span>
            <button type="button" onClick={() => go(-1)} aria-label="Sebelumnya" className="grid h-12 w-12 place-items-center border-[1.5px] border-brand text-brand hover:bg-brand hover:text-cream"><ArrowLeft className="h-5 w-5" /></button>
            <button type="button" onClick={() => go(1)} aria-label="Berikutnya" className="grid h-12 w-12 place-items-center border-[1.5px] border-brand bg-lime text-brand hover:bg-brand hover:text-lime"><ArrowRight className="h-5 w-5" /></button>
          </div>
        </div>
        <figure key={t.id} className="mt-12 grid gap-10 md:grid-cols-[auto_1fr] md:gap-14 animate-[reveal_0.4s_ease-out_both]">
          <div className="flex items-center gap-4 md:flex-col md:items-start">
            {t.foto ? <img src={assetUrl(t.foto)} alt={t.nama} className="h-24 w-24 border-[1.5px] border-brand object-cover md:h-40 md:w-40" />
              : <span className="grid h-24 w-24 place-items-center border-[1.5px] border-brand bg-lime font-display text-3xl font-bold text-brand md:h-40 md:w-40 md:text-5xl">{initials(t.nama)}</span>}
            <figcaption>
              <p className="text-[17px] font-bold text-ink">{t.nama}</p>
              <p className="mt-0.5 max-w-[14rem] text-[14px] text-muted">{t.peran}</p>
            </figcaption>
          </div>
          <blockquote className="relative font-display text-[1.7rem] font-normal leading-[1.35] tracking-[-0.01em] text-brand md:text-[2.5rem]">
            <span aria-hidden="true" className="absolute -left-2 -top-10 font-display text-[7rem] leading-none text-lime-deep md:-left-8">“</span>
            <span className="relative">{t.kutipan}</span>
          </blockquote>
        </figure>
      </div>
    </section>
  )
}
