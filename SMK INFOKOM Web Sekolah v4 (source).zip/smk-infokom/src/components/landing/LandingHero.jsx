import { Link } from 'react-router-dom'
import { ArrowRight, ArrowUpRight, BadgeCheck } from 'lucide-react'
import { useSettings, pairs } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'
import { CountUp } from '../../lib/motion.jsx'
import { AutoVideo } from '../Media.jsx'

export default function LandingHero() {
  const st = useSettings()
  const headline = (st.hero_headline || st.nama_sekolah || '').split('\n')
  const stats = pairs(st.hero_stats).slice(0, 3)
  const dibuka = st.ppdb_dibuka !== 'false'
  const ppdbTo = dibuka ? '/ppdb/daftar' : '/ppdb'
  const QUICK = [
    { label: `PPDB ${st.ppdb_tahun || ''}`, desc: 'Daftar siswa baru secara online', to: ppdbTo },
    { label: 'Lowongan BKK', desc: 'Info kerja untuk alumni & kelas XII', to: '/bkk#lowongan' },
    { label: 'Magang ke Jepang', desc: 'Ginou Jisshu & Tokutei Ginou', to: '/magang-jepang' },
    { label: 'Cek Status', desc: 'Pantau hasil pendaftaran PPDB', to: '/ppdb/cek-status' },
  ]
  const poster = assetUrl(st.hero_image || '/images/hero/beranda.jpg')

  return (
    <section data-noreveal className="relative overflow-hidden border-b-[1.5px] border-brand bg-cream">
      <div aria-hidden="true" className="bg-grid-dark pointer-events-none absolute inset-0" />
      <div className="container-page relative pt-10 md:pt-14">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-brand/15 pb-5 font-mono text-[11.5px] uppercase tracking-[0.14em] text-muted animate-[reveal_0.5s_ease-out_both]">
          <span className="flex items-center gap-2 text-brand"><BadgeCheck className="h-4 w-4 text-accent" />Terakreditasi {st.akreditasi} · {st.akreditasi_keterangan}</span>
          <span className="hidden sm:block">{st.kota} · NPSN {st.npsn}</span>
        </div>

        <h1 className="mt-10 font-display text-[3rem] font-bold leading-[0.95] tracking-[-0.035em] text-brand sm:text-[4.6rem] lg:text-[6.4rem]">
          {headline.map((l, i) => (
            <span key={i} className="block overflow-hidden pb-2">
              <span className="block animate-[reveal_0.8s_cubic-bezier(.16,1,.3,1)_both]" style={{ animationDelay: `${0.08 + i * 0.1}s` }}>
                {i === headline.length - 1 ? <em className="hl not-italic md:italic">{l}</em> : l}
              </span>
            </span>
          ))}
        </h1>

        <div className="mt-12 grid gap-12 pb-16 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16 lg:pb-20">
          <div className="flex flex-col justify-between gap-10 animate-[reveal_0.7s_ease-out_0.4s_both]">
            <div>
              <p className="max-w-md text-[18px] leading-relaxed text-ink/75">{st.hero_subtitle}</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to={ppdbTo} className="btn-primary px-7 py-3.5">Daftar Sekarang <ArrowRight className="h-4 w-4" /></Link>
                <Link to="/jurusan" className="btn-outline px-7 py-3.5">Jelajahi Jurusan</Link>
              </div>
            </div>
            {stats.length > 0 && (
              <dl className="grid grid-cols-3 border-y-[1.5px] border-brand">
                {stats.map((x, i) => (
                  <div key={x.label} className={`py-5 ${i ? 'border-l border-brand/20 pl-4 sm:pl-6' : 'pr-4'}`}>
                    <dd className="font-display text-[2.1rem] font-bold leading-none tracking-tight text-brand tabular-nums sm:text-[2.6rem]"><CountUp value={x.value} /></dd>
                    <dt className="mt-2 font-mono text-[11px] uppercase leading-snug tracking-[0.08em] text-muted">{x.label}</dt>
                  </div>
                ))}
              </dl>
            )}
          </div>

          <div className="relative animate-[reveal_0.9s_cubic-bezier(.16,1,.3,1)_0.25s_both]">
            <div aria-hidden="true" className="absolute -left-4 -top-4 h-28 w-28 bg-lime md:-left-6 md:-top-6" />
            <div className="relative aspect-[4/3.1] overflow-hidden border-[1.5px] border-brand bg-brand shadow-hard">
              <AutoVideo src={st.hero_video} poster={poster} alt={`Siswa ${st.nama_sekolah} belajar di laboratorium`} className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute bottom-0 left-0 flex items-center gap-2 border-r-[1.5px] border-t-[1.5px] border-brand bg-cream px-3 py-2 font-mono text-[11px] uppercase tracking-[0.1em] text-brand">
                <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full rounded-full bg-accent animate-ping-slow" /><span className="relative inline-flex h-2 w-2 rounded-full bg-accent" /></span>
                Live · Lab {st.nama_sekolah}
              </div>
            </div>
            <Link to="/magang-jepang" className="group absolute -bottom-6 right-4 hidden w-[260px] border-[1.5px] border-brand bg-lime p-4 text-brand shadow-hard-sm transition-transform hover:-translate-y-1 sm:block md:-right-4">
              <p className="font-mono text-[10.5px] uppercase tracking-[0.14em]">Baru · 日本</p>
              <p className="mt-1 text-[15px] font-bold leading-snug">Pendaftaran Magang ke Jepang {st.magang_angkatan ? `— ${st.magang_angkatan}` : ''}</p>
              <span className="mt-2 inline-flex items-center gap-1 text-[13px] font-bold">Lihat program <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:rotate-45" /></span>
            </Link>
          </div>
        </div>
      </div>

      {/* Tautan cepat — indeks bernomor */}
      <div className="relative border-t-[1.5px] border-brand bg-brand">
        <div className="container-page grid sm:grid-cols-2 lg:grid-cols-4">
          {QUICK.map((q, i) => (
            <Link key={q.label} to={q.to}
              className={`group flex items-start gap-4 py-6 text-cream transition-colors hover:bg-lime hover:text-brand sm:px-5 ${i ? 'border-t border-cream/15 sm:border-t-0' : ''} ${i % 2 ? 'sm:border-l sm:border-cream/15' : ''} ${i >= 2 ? 'sm:border-t lg:border-t-0 lg:border-l' : ''}`}>
              <span className="font-mono text-[12px] text-lime group-hover:text-brand">0{i + 1}</span>
              <span className="flex-1">
                <span className="flex items-center justify-between gap-2 text-[16px] font-bold">{q.label}<ArrowUpRight className="h-4 w-4 transition-transform group-hover:rotate-45" /></span>
                <span className="mt-1 block text-[13.5px] leading-snug opacity-70">{q.desc}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
