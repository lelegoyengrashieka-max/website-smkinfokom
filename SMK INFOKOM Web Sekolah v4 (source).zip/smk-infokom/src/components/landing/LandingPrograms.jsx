import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowUpRight } from 'lucide-react'
import { useList } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'
import { ArrowLink, Skeleton } from '../ui/index.jsx'

/** Daftar jurusan bergaya indeks: baris bernomor, foto berganti saat disorot. */
export default function LandingPrograms() {
  const { items, loading } = useList('jurusan')
  const [active, setActive] = useState(0)
  const cur = items[active] || items[0]
  return (
    <section className="grain relative bg-brand py-20 text-cream md:py-28">
      <div className="container-page relative z-[1]">
        <div className="flex flex-col gap-6 border-b-[1.5px] border-cream/25 pb-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="eyebrow !text-lime">02 · Program Keahlian</p>
            <h2 className="section-heading mt-4 !text-cream">Empat jurusan, satu standar: <span className="hl-dark">siap kerja.</span></h2>
          </div>
          <ArrowLink to="/jurusan" className="!text-cream">Semua jurusan</ArrowLink>
        </div>

        <div className="mt-10 grid gap-10 lg:grid-cols-[1.25fr_0.75fr] lg:gap-14">
          <ul>
            {loading && [0, 1, 2, 3].map((i) => <Skeleton key={i} className="mb-3 h-24 !bg-cream/10" />)}
            {items.map((p, i) => (
              <li key={p.id} className="border-b border-cream/15">
                <Link to={`/jurusan/${p.slug}`} onMouseEnter={() => setActive(i)} onFocus={() => setActive(i)}
                  className={`group grid grid-cols-[3rem_1fr_auto] items-center gap-4 py-6 transition-colors md:grid-cols-[4rem_1fr_auto] md:py-7 ${active === i ? 'text-lime' : 'text-cream hover:text-lime'}`}>
                  <span className="font-mono text-[13px] opacity-70">{String(i + 1).padStart(2, '0')}</span>
                  <span>
                    <span className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                      <span className="font-display text-[1.7rem] font-bold leading-tight md:text-[2.3rem]">{p.nama}</span>
                      <span className="font-mono text-[12px] tracking-[0.1em] opacity-70">{p.kode}</span>
                    </span>
                    <span className="mt-2 block max-w-xl text-[14.5px] leading-relaxed text-cream/65">{p.tagline || p.deskripsi}</span>
                  </span>
                  <span className={`grid h-11 w-11 place-items-center border-[1.5px] transition-all ${active === i ? 'rotate-45 border-lime bg-lime text-brand' : 'border-cream/30'}`}><ArrowUpRight className="h-5 w-5" /></span>
                </Link>
              </li>
            ))}
          </ul>
          <div className="relative hidden lg:block">
            <div className="sticky top-28">
              <div className="relative aspect-[4/5] overflow-hidden border-[1.5px] border-lime shadow-hard-lime">
                {cur && <img key={cur.id} src={assetUrl(cur.gambar || '/images/hero/jurusan.jpg')} alt={cur.nama} loading="lazy" className="h-full w-full object-cover animate-[reveal_0.45s_ease-out_both]" />}
                {cur && <span className="absolute left-0 top-0 border-b-[1.5px] border-r-[1.5px] border-lime bg-brand px-3 py-1.5 font-mono text-[12px] tracking-[0.1em] text-lime">{cur.kode}</span>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
