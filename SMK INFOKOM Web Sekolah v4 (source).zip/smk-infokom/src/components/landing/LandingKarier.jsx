import { Link } from 'react-router-dom'
import { ArrowRight, MapPin, CalendarClock, ArrowUpRight } from 'lucide-react'
import { useSettings, useList, pairs, formatTanggal } from '../../lib/data.jsx'
import { Skeleton } from '../ui/index.jsx'
import { AutoVideo } from '../Media.jsx'

export default function LandingKarier() {
  const st = useSettings()
  const { items: lowongan, loading } = useList('lowongan', { status: 'dibuka', limit: 3 })
  const magangStats = pairs(st.magang_stats).slice(0, 3)
  const bkkStats = pairs(st.bkk_stats_full || st.bkk_stats).slice(0, 2)

  return (
    <section className="bg-cream py-20 md:py-28">
      <div className="container-page">
        <div className="grid gap-6 border-b-[1.5px] border-brand pb-6 md:grid-cols-[1fr_auto] md:items-end">
          <div className="max-w-2xl">
            <p className="eyebrow">03 · Karier & Masa Depan</p>
            <h2 className="section-heading mt-4">Lulus bukan akhir. Kami dampingi <span className="hl">sampai kamu bekerja.</span></h2>
          </div>
        </div>

        <div className="mt-12 grid border-[1.5px] border-brand bg-white lg:grid-cols-2">
          {/* Magang Jepang */}
          <article className="flex flex-col border-b-[1.5px] border-brand lg:border-b-0 lg:border-r-[1.5px]">
            <div className="relative aspect-[16/9] overflow-hidden border-b-[1.5px] border-brand bg-brand">
              <AutoVideo src={st.magang_hero_video} poster={st.magang_image || '/images/hero/magang-jepang.jpg'} alt="Peserta magang di Jepang" className="absolute inset-0 h-full w-full object-cover" />
              <span className="absolute left-0 top-0 border-b-[1.5px] border-r-[1.5px] border-brand bg-lime px-3 py-1.5 font-mono text-[11.5px] uppercase tracking-[0.12em] text-brand">Magang ke Jepang · 技能実習</span>
            </div>
            <div className="flex flex-1 flex-col p-7 md:p-10">
              <h3 className="font-display text-[2rem] font-bold leading-tight text-brand md:text-[2.4rem]">{st.magang_heading || 'Program Magang Kerja ke Jepang'}</h3>
              <p className="mt-4 max-w-md text-[15.5px] leading-relaxed text-ink/70">{st.magang_desc}</p>
              {magangStats.length > 0 && (
                <dl className="mt-8 grid grid-cols-3 border-y border-brand/20">
                  {magangStats.map((s, i) => (
                    <div key={s.label} className={`py-4 ${i ? 'border-l border-brand/20 pl-4' : 'pr-4'}`}><dd className="font-display text-[1.8rem] font-bold text-brand">{s.value}</dd><dt className="mt-1 font-mono text-[10.5px] uppercase leading-snug tracking-[0.06em] text-muted">{s.label}</dt></div>
                  ))}
                </dl>
              )}
              <div className="mt-auto flex flex-wrap gap-3 pt-8">
                <Link to="/magang-jepang/daftar" className="btn-primary">Daftar Seleksi <ArrowRight className="h-4 w-4" /></Link>
                <Link to="/magang-jepang" className="btn-outline">Pelajari Program</Link>
              </div>
            </div>
          </article>

          {/* BKK */}
          <article className="flex flex-col p-7 md:p-10">
            <p className="font-mono text-[11.5px] uppercase tracking-[0.14em] text-brand-600">Bursa Kerja Khusus</p>
            <h3 className="mt-3 font-display text-[2rem] font-bold leading-tight text-brand">Lowongan terbaru dari mitra industri</h3>
            {bkkStats.length > 0 && (
              <p className="mt-3 text-[14.5px] text-muted">{bkkStats.map((s) => `${s.value} ${s.label.toLowerCase()}`).join(' · ')}</p>
            )}
            <ul className="mt-6 flex-1 border-t border-brand/20">
              {loading && [0, 1, 2].map((i) => <Skeleton key={i} className="mt-3 h-20" />)}
              {!loading && lowongan.length === 0 && <li className="py-5 text-[14.5px] text-muted">Belum ada lowongan aktif. Pantau terus halaman BKK.</li>}
              {lowongan.map((l) => (
                <li key={l.id} className="border-b border-brand/20">
                  <Link to={`/bkk/lowongan/${l.slug}`} className="group flex items-start justify-between gap-4 py-5 transition-colors hover:bg-lime-soft">
                    <div>
                      <p className="font-mono text-[11.5px] uppercase tracking-[0.08em] text-muted">{l.perusahaan}</p>
                      <p className="mt-1 text-[17px] font-bold text-brand">{l.judul}</p>
                      <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-[13px] text-muted">
                        {l.lokasi && <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" />{l.lokasi}</span>}
                        {l.deadline && <span className="flex items-center gap-1.5"><CalendarClock className="h-3.5 w-3.5" />Tutup {formatTanggal(l.deadline, 'pendek')}</span>}
                      </div>
                    </div>
                    <span className="flex shrink-0 flex-col items-end gap-3">
                      <span className="pill border border-brand/30 text-brand">{l.tipe}</span>
                      <ArrowUpRight className="h-5 w-5 text-brand transition-transform group-hover:rotate-45" />
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/bkk#lowongan" className="btn-dark">Semua Lowongan <ArrowRight className="h-4 w-4" /></Link>
              <Link to="/bkk#video" className="btn-outline">Video Kegiatan</Link>
            </div>
          </article>
        </div>
      </div>
    </section>
  )
}
