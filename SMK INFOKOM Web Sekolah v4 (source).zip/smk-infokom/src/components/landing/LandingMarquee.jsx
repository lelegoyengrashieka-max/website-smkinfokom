import { useSettings, lines } from '../../lib/data.jsx'

export default function LandingMarquee() {
  const ITEMS = lines(useSettings().marquee)
  if (!ITEMS.length) return null
  const loop = [...ITEMS, ...ITEMS]
  return (
    <div className="overflow-hidden border-b-[1.5px] border-brand bg-lime py-4" aria-label="Sorotan sekolah">
      <div className="flex w-max animate-[marquee_48s_linear_infinite] gap-8 whitespace-nowrap hover:[animation-play-state:paused]">
        {loop.map((t, i) => (
          <span key={i} className="flex items-center gap-8 font-display text-[1.4rem] font-bold italic tracking-[-0.01em] text-brand md:text-[1.8rem]">
            {t}
            <span className="font-mono text-[14px] not-italic" aria-hidden="true">✳</span>
          </span>
        ))}
      </div>
    </div>
  )
}
