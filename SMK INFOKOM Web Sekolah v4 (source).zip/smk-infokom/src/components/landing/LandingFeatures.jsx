import { useSettings, pairs } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'

export default function LandingFeatures() {
  const st = useSettings()
  const F = pairs(st.keunggulan)
  if (!F.length) return null
  return (
    <section className="border-y-[1.5px] border-brand bg-surface py-20 md:py-28">
      <div className="container-page">
        <div className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-end">
          <div>
            <p className="eyebrow">04 · Mengapa Kami</p>
            <h2 className="section-heading mt-4">Belajar dari standar industri, <span className="hl">bukan simulasi.</span></h2>
          </div>
          <p className="max-w-md text-[16.5px] leading-relaxed text-ink/70 lg:justify-self-end">Kurikulum disusun bersama mitra perusahaan, diajar praktisi, dan diuji lewat sertifikasi resmi.</p>
        </div>
        <div className="mt-12 grid border-l-[1.5px] border-t-[1.5px] border-brand md:grid-cols-2 lg:grid-cols-3">
          {F.map((f, i) => (
            <div key={f.label} className="group border-b-[1.5px] border-r-[1.5px] border-brand bg-cream p-7 transition-colors hover:bg-lime md:p-8">
              <div className="flex items-start justify-between">
                <span className="font-display text-[3rem] font-bold leading-none text-brand/20 transition-colors group-hover:text-brand tabular-nums">{String(i + 1).padStart(2, '0')}</span>
                <span className="h-3 w-3 bg-brand" aria-hidden="true" />
              </div>
              <h3 className="mt-8 font-display text-[1.45rem] font-bold leading-snug text-brand">{f.label}</h3>
              <p className="mt-2 text-[15px] leading-relaxed text-ink/70">{f.value}</p>
            </div>
          ))}
          {F.length % 3 !== 0 && (
            <div className="hidden overflow-hidden border-b-[1.5px] border-r-[1.5px] border-brand lg:block" style={{ gridColumn: `span ${3 - (F.length % 3)}` }}>
              <img src={assetUrl(st.keunggulan_image || '/images/hero/kurikulum.jpg')} alt="Siswa praktik bersama guru" loading="lazy" className="h-full w-full object-cover" />
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
