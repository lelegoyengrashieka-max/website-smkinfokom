import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { useSettings, lines, pairs } from '../../lib/data.jsx'
import { assetUrl } from '../../lib/api.js'

export default function LandingAbout() {
  const st = useSettings()
  const badge = pairs(st.about_badge)[0]
  const misi = lines(st.misi).slice(0, 4)
  return (
    <section className="bg-cream py-20 md:py-28">
      <div className="container-page">
        <div className="grid gap-6 border-b-[1.5px] border-brand pb-6 md:grid-cols-[auto_1fr] md:items-end md:gap-12">
          <p className="eyebrow">01 · Tentang Sekolah</p>
          <h2 className="section-heading md:text-right md:justify-self-end max-w-3xl">{st.about_heading}</h2>
        </div>

        <div className="mt-12 grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="relative aspect-[4/5] overflow-hidden border-[1.5px] border-brand">
              <img src={assetUrl(st.about_image || '/images/hero/profil.jpg')} alt={`Gedung ${st.nama_sekolah}`} loading="lazy" className="h-full w-full object-cover" />
              {badge && (
                <div className="absolute bottom-0 right-0 max-w-[62%] border-l-[1.5px] border-t-[1.5px] border-brand bg-lime p-5 text-brand">
                  <p className="font-display text-[2.6rem] font-bold leading-none">{badge.label}</p>
                  <p className="mt-2 text-[13px] font-medium leading-snug">{badge.value}</p>
                </div>
              )}
            </div>
          </div>
          <div className="lg:col-span-7 lg:pl-6">
            <p className="text-[19px] leading-[1.7] text-ink/80 first-letter:float-left first-letter:mr-3 first-letter:font-display first-letter:text-[4.2rem] first-letter:font-bold first-letter:leading-[0.8] first-letter:text-brand">{st.about_desc}</p>
            {st.visi && (
              <blockquote className="mt-10 border-l-[6px] border-lime pl-6">
                <p className="font-mono text-[11.5px] uppercase tracking-[0.16em] text-muted">Visi</p>
                <p className="mt-2 font-display text-[1.6rem] font-bold italic leading-snug text-brand">“{st.visi}”</p>
              </blockquote>
            )}
            <ol className="mt-10 grid border-t border-brand/20 sm:grid-cols-2">
              {misi.map((m, i) => (
                <li key={m} className={`flex gap-4 border-b border-brand/20 py-5 text-[15px] leading-relaxed text-ink/80 ${i % 2 ? 'sm:border-l sm:pl-5' : 'sm:pr-5'}`}>
                  <span className="idx pt-0.5 text-brand-600">M{i + 1}</span>{m}
                </li>
              ))}
            </ol>
            <Link to="/profil" className="btn-dark mt-10">Profil Lengkap <ArrowRight className="h-4 w-4" /></Link>
          </div>
        </div>
      </div>
    </section>
  )
}
