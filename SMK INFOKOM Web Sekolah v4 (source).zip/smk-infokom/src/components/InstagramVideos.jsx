import { useState } from 'react'
import { Instagram, Play, ArrowUpRight } from 'lucide-react'
import { useList, useSettings, formatTanggal } from '../lib/data.jsx'
import { assetUrl } from '../lib/api.js'
import { instagramEmbedUrl, instagramPermalink } from '../lib/instagram.js'
import { Skeleton } from './ui/index.jsx'

/** Satu kartu video: sampul + tombol putar → iframe resmi Instagram (dimuat saat diklik). */
function VideoCard({ v, index }) {
  const [playing, setPlaying] = useState(false)
  const embed = instagramEmbedUrl(v.url)
  const link = instagramPermalink(v.url)
  return (
    <article className="flex flex-col border-[1.5px] border-brand bg-white">
      <div className="relative border-b-[1.5px] border-brand bg-brand">
        {playing && embed ? (
          <iframe src={embed} title={v.judul} className="block h-[640px] w-full bg-white" loading="lazy"
            allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" allowFullScreen />
        ) : (
          <button type="button" onClick={() => setPlaying(true)} className="group relative block aspect-[9/14] w-full overflow-hidden text-left" aria-label={`Putar video: ${v.judul}`}>
            {v.sampul ? (
              <img src={assetUrl(v.sampul)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
            ) : (
              <span aria-hidden="true" className="bg-grid-light absolute inset-0 grid place-items-center">
                <Instagram className="h-16 w-16 text-lime/40" strokeWidth={1.2} />
              </span>
            )}
            <span className="absolute inset-0 bg-gradient-to-t from-brand/90 via-brand/10 to-transparent" />
            <span className="absolute left-0 top-0 flex items-center gap-1.5 border-b-[1.5px] border-r-[1.5px] border-brand bg-cream px-2.5 py-1.5 font-mono text-[10.5px] uppercase tracking-[0.12em] text-brand">
              <Instagram className="h-3.5 w-3.5" />Reel {String(index + 1).padStart(2, '0')}
            </span>
            <span className="absolute left-1/2 top-1/2 grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center border-[1.5px] border-brand bg-lime text-brand shadow-hard-sm transition-transform duration-300 group-hover:scale-110">
              <Play className="ml-0.5 h-6 w-6 fill-current" />
            </span>
            <span className="absolute bottom-0 left-0 right-0 p-5">
              <span className="block font-mono text-[10.5px] uppercase tracking-[0.14em] text-lime">Putar di sini</span>
              <span className="mt-1 block font-display text-[1.35rem] font-bold leading-snug text-cream">{v.judul}</span>
            </span>
          </button>
        )}
      </div>
      <div className="flex flex-1 flex-col p-5">
        {playing && <h3 className="mb-2 font-display text-[1.2rem] font-bold leading-snug text-brand">{v.judul}</h3>}
        {v.keterangan && <p className="text-[14px] leading-relaxed text-ink/70">{v.keterangan}</p>}
        <div className="mt-auto flex items-center justify-between gap-3 pt-4">
          <span className="idx">{v.tanggal ? formatTanggal(v.tanggal, 'pendek') : 'Instagram'}</span>
          <a href={link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[13px] font-bold text-brand underline decoration-lime decoration-2 underline-offset-4 hover:decoration-brand">
            Buka di Instagram <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </article>
  )
}

/**
 * Bagian video Instagram untuk halaman BKK / Magang Jepang.
 * Data dikelola di panel admin (resource video_bkk / video_magang).
 */
export default function InstagramVideos({ resource, id = 'video', eyebrow = 'Video Instagram', title, desc, tone = 'surface' }) {
  const st = useSettings()
  const { items, loading } = useList(resource, { limit: 24 })
  if (!loading && items.length === 0) return null
  const bg = tone === 'surface' ? 'border-y-[1.5px] border-brand bg-surface' : 'bg-cream'
  return (
    <section id={id} className={`scroll-mt-24 py-16 md:py-24 ${bg}`}>
      <div className="container-page">
        <div className="mb-10 flex flex-col gap-6 border-b-[1.5px] border-brand pb-6 md:mb-12 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="eyebrow">{eyebrow}</p>
            <h2 className="section-heading mt-4">{title}</h2>
            {desc && <p className="mt-4 text-[16.5px] leading-relaxed text-ink/70">{desc}</p>}
          </div>
          {st.instagram && (
            <a href={st.instagram} target="_blank" rel="noopener noreferrer" className="btn-outline shrink-0"><Instagram className="h-4 w-4" />Ikuti Instagram Kami</a>
          )}
        </div>
        <div className="grid items-start gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {loading && [0, 1, 2].map((i) => <Skeleton key={i} className="aspect-[9/14]" />)}
          {items.map((v, i) => <VideoCard key={v.id} v={v} index={i} />)}
        </div>
      </div>
    </section>
  )
}
