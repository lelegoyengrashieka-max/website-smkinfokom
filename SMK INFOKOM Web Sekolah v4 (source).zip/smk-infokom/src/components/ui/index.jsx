import { CountUp } from '../../lib/motion.jsx'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Plus } from 'lucide-react'

export function Section({ id, tone = 'white', className = '', children }) {
  const bg = { white: 'bg-cream', surface: 'bg-surface border-y-[1.5px] border-brand', brand: 'grain bg-brand text-cream', tint: 'bg-lime-soft', paper: 'bg-white' }[tone]
  return (
    <section id={id} className={`relative ${bg} py-16 md:py-24 ${className}`}>
      <div className="container-page relative z-[1]">{children}</div>
    </section>
  )
}

export function SectionHeader({ eyebrow, title, desc, action, light = false, className = '' }) {
  return (
    <div className={`mb-10 md:mb-14 flex flex-col gap-6 border-b-[1.5px] pb-6 md:flex-row md:items-end md:justify-between ${light ? 'border-cream/25' : 'border-brand'} ${className}`}>
      <div className="max-w-2xl">
        {eyebrow && <p className={`eyebrow ${light ? '!text-lime' : ''}`}>{eyebrow}</p>}
        <h2 className={`section-heading mt-4 ${light ? '!text-cream' : ''}`}>{title}</h2>
        {desc && <p className={`mt-4 text-[16.5px] leading-relaxed ${light ? 'text-cream/70' : 'text-ink/70'}`}>{desc}</p>}
      </div>
      {action}
    </div>
  )
}

export function ArrowLink({ to, children, className = '' }) {
  return (
    <Link to={to} className={`link-arrow group ${className}`}>
      {children}
      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
    </Link>
  )
}

export function StatRow({ items, light = false }) {
  return (
    <dl className={`grid grid-cols-2 lg:grid-cols-4 border-y-[1.5px] ${light ? 'border-cream/30' : 'border-brand'}`}>
      {items.map((s, i) => (
        <div key={i} className={`py-6 pr-6 ${i % 2 === 1 ? 'pl-6 border-l' : ''} ${i >= 2 ? 'lg:pl-6 lg:border-l' : ''} ${light ? 'border-cream/20' : 'border-brand/20'}`}>
          <dt className={`order-2 mt-2 font-mono text-[11.5px] uppercase tracking-[0.06em] leading-snug ${light ? 'text-cream/65' : 'text-muted'}`}>{s.label}</dt>
          <dd className={`font-display text-[2.6rem] md:text-[3.4rem] font-bold leading-none tracking-tight tabular-nums ${light ? 'text-lime' : 'text-brand'}`}><CountUp value={s.value} /></dd>
        </div>
      ))}
    </dl>
  )
}

export function Steps({ items, light = false }) {
  return (
    <ol className="relative grid gap-0">
      {items.map((s, i) => (
        <li key={i} className="relative grid grid-cols-[3rem_1fr] gap-4 pb-8 last:pb-0">
          {i < items.length - 1 && <span className={`absolute left-[1.45rem] top-12 bottom-0 w-px ${light ? 'bg-cream/25' : 'bg-brand/25'}`} aria-hidden />}
          <span className={`flex h-12 w-12 items-center justify-center border-[1.5px] font-mono text-[14px] font-bold tabular-nums ${light ? 'border-lime bg-lime text-brand' : 'border-brand bg-lime text-brand'}`}>
            {String(i + 1).padStart(2, '0')}
          </span>
          <div className="pt-2.5">
            <p className={`font-display text-[21px] font-bold ${light ? 'text-cream' : 'text-brand'}`}>{s.label}</p>
            {s.value && <p className={`mt-1.5 text-[15px] leading-relaxed ${light ? 'text-cream/65' : 'text-ink/65'}`}>{s.value}</p>}
          </div>
        </li>
      ))}
    </ol>
  )
}

export function FaqList({ items }) {
  const [open, setOpen] = useState(0)
  if (!items?.length) return null
  return (
    <div className="divide-y divide-brand/20 border-[1.5px] border-brand bg-white">
      {items.map((it, i) => {
        const isOpen = open === i
        return (
          <div key={it.id || i}>
            <button type="button" onClick={() => setOpen(isOpen ? -1 : i)} aria-expanded={isOpen}
              className={`flex w-full items-center justify-between gap-6 px-6 py-5 text-left transition-colors ${isOpen ? 'bg-lime-soft' : 'hover:bg-cream'}`}>
              <span className="flex gap-4 text-[16px] font-bold text-ink"><span className="idx pt-0.5">{String(i + 1).padStart(2, '0')}</span>{it.pertanyaan || it.q}</span>
              <span className={`grid h-8 w-8 shrink-0 place-items-center border-[1.5px] border-brand transition-all ${isOpen ? 'rotate-45 bg-lime' : ''}`}><Plus className="h-4 w-4 text-brand" /></span>
            </button>
            <div className={`grid transition-all duration-200 ${isOpen ? 'grid-rows-[1fr] pb-5' : 'grid-rows-[0fr]'}`}>
              <div className={`overflow-hidden px-6 ${isOpen ? 'bg-lime-soft' : ''}`}>
                <p className="max-w-2xl pl-9 text-[15px] leading-relaxed text-muted whitespace-pre-line">{it.jawaban || it.a}</p>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

/* ---------------- Form ---------------- */
export function Field({ label, name, error, required, hint, className = '', children }) {
  return (
    <div className={className}>
      <label htmlFor={name} className="field-label">{label}{required && <span className="text-accent"> *</span>}</label>
      {children}
      {hint && !error && <p className="mt-1.5 text-[12.5px] text-muted">{hint}</p>}
      {error && <p className="field-error">{error}</p>}
    </div>
  )
}

export function Input({ label, name, error, required, hint, className = '', ...rest }) {
  return (
    <Field label={label} name={name} error={error} required={required} hint={hint} className={className}>
      <input id={name} name={name} required={required} aria-invalid={!!error} className={`field-input ${error ? '!border-red-400' : ''}`} {...rest} />
    </Field>
  )
}

export function Textarea({ label, name, error, required, hint, className = '', rows = 4, ...rest }) {
  return (
    <Field label={label} name={name} error={error} required={required} hint={hint} className={className}>
      <textarea id={name} name={name} rows={rows} required={required} aria-invalid={!!error} className={`field-input resize-y ${error ? '!border-red-400' : ''}`} {...rest} />
    </Field>
  )
}

export function Select({ label, name, error, required, hint, options, className = '', ...rest }) {
  return (
    <Field label={label} name={name} error={error} required={required} hint={hint} className={className}>
      <select id={name} name={name} required={required} aria-invalid={!!error} className={`field-input ${error ? '!border-red-400' : ''}`} {...rest}>
        <option value="">Pilih…</option>
        {options.map((o) => {
          const [v, l] = Array.isArray(o) ? o : [o, o]
          return <option key={v} value={v}>{l}</option>
        })}
      </select>
    </Field>
  )
}

export function FormCard({ title, desc, children }) {
  return (
    <fieldset className="border-[1.5px] border-brand bg-white p-6 md:p-8">
      <legend className="sr-only">{title}</legend>
      <p className="font-display text-[1.6rem] font-bold text-brand">{title}</p>
      {desc && <p className="mt-1 text-[14px] text-muted">{desc}</p>}
      <div className="mt-6 grid gap-5 sm:grid-cols-2">{children}</div>
    </fieldset>
  )
}

export const Honeypot = ({ value, onChange }) => (
  <input type="text" name="website" value={value} onChange={onChange} tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />
)

export function Alert({ tone = 'error', children }) {
  const cls = tone === 'error' ? 'border-red-200 bg-red-50 text-red-700' : 'border-emerald-200 bg-emerald-50 text-emerald-800'
  return <div role="alert" className={`rounded-xl border px-4 py-3 text-[14px] font-medium ${cls}`}>{children}</div>
}

export function Skeleton({ className = '' }) {
  return <div className={`animate-pulse bg-brand/10 ${className}`} />
}

export function EmptyState({ title, desc, action }) {
  return (
    <div className="border-[1.5px] border-dashed border-brand/40 bg-white px-6 py-14 text-center">
      <p className="font-display text-[1.6rem] font-bold text-brand">{title}</p>
      {desc && <p className="mx-auto mt-2 max-w-md text-[15px] text-muted">{desc}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  )
}

export function useForm(initial) {
  const [form, setForm] = useState(initial)
  const set = (e) => {
    const { name, value, type, checked } = e.target
    setForm((f) => ({ ...f, [name]: type === 'checkbox' ? checked : value }))
  }
  return [form, set, setForm]
}
