import { Link } from 'react-router-dom'
import { Phone, Mail, ArrowRight } from 'lucide-react'
import { useSettings } from '../lib/data.jsx'

export default function TopBar() {
  const st = useSettings()
  const dibuka = st.ppdb_dibuka !== 'false'
  return (
    <div className="bg-brand text-cream/80">
      <div className="container-page flex h-9 items-center justify-between gap-4 font-mono text-[11.5px] uppercase tracking-[0.1em]">
        <Link to={dibuka ? '/ppdb/daftar' : '/ppdb'} className="group flex min-w-0 items-center gap-2 text-lime">
          <span className="h-1.5 w-1.5 shrink-0 bg-lime animate-[blink_1.4s_steps(1)_infinite]" aria-hidden="true" />
          <span className="truncate">PPDB {st.ppdb_tahun} {dibuka ? 'dibuka — daftar online' : '— lihat informasi'}</span>
          <ArrowRight className="h-3.5 w-3.5 shrink-0 transition-transform group-hover:translate-x-0.5" />
        </Link>
        <div className="hidden items-center gap-6 md:flex">
          {st.telepon && <a href={`tel:${st.telepon}`} className="flex items-center gap-2 hover:text-cream"><Phone className="h-3.5 w-3.5" />{st.telepon}</a>}
          {st.email && <a href={`mailto:${st.email}`} className="hidden lg:flex items-center gap-2 normal-case tracking-normal hover:text-cream"><Mail className="h-3.5 w-3.5" />{st.email}</a>}
          <span className="h-3 w-px bg-cream/20" aria-hidden="true" />
          <Link to="/bkk" className="hover:text-lime">BKK</Link>
          <Link to="/magang-jepang" className="hover:text-lime">Magang Jepang</Link>
          <Link to="/unduhan" className="hover:text-lime">Unduhan</Link>
        </div>
      </div>
    </div>
  )
}
