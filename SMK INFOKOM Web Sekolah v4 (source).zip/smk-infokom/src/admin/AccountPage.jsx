import { useState } from 'react'
import { api } from '../lib/api.js'
import { useAdmin } from './AdminContext.jsx'
import { Button, FormRow, inputCls, toast } from './ui.jsx'

export default function AccountPage() {
  const { user, setUser } = useAdmin()
  const [form, setForm] = useState({ nama: user?.nama || '', email: user?.email || '', password_lama: '', password_baru: '', konfirmasi: '' })
  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)
  const set = (k) => (e) => setForm((s) => ({ ...s, [k]: e.target.value }))

  const save = async (e) => {
    e.preventDefault()
    setErrors({})
    if (form.password_baru && form.password_baru !== form.konfirmasi) return setErrors({ konfirmasi: 'Konfirmasi password tidak sama' })
    setSaving(true)
    try {
      const { konfirmasi, ...body } = form
      if (!body.password_baru) { delete body.password_baru; delete body.password_lama }
      const { user: u } = await api('/api/auth/me', { method: 'PUT', body })
      setUser(u)
      setForm((s) => ({ ...s, password_lama: '', password_baru: '', konfirmasi: '' }))
      toast('Akun diperbarui.')
    } catch (err) { setErrors(err.details || {}); toast(err.message, 'error') } finally { setSaving(false) }
  }

  return (
    <form onSubmit={save} className="max-w-2xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy">Akun Saya</h1>
        <p className="mt-1 text-[13.5px] text-ink/55">Username: <span className="font-mono">{user?.username}</span> · Peran: {user?.role}</p>
      </div>
      <section className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6">
        <h2 className="font-display text-[16px] font-semibold text-navy">Profil</h2>
        <FormRow label="Nama Lengkap" required error={errors.nama}><input value={form.nama} onChange={set('nama')} className={inputCls(errors.nama)} /></FormRow>
        <FormRow label="Email" error={errors.email}><input type="email" value={form.email} onChange={set('email')} className={inputCls(errors.email)} /></FormRow>
      </section>
      <section className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6">
        <h2 className="font-display text-[16px] font-semibold text-navy">Ganti Password</h2>
        <FormRow label="Password Lama" error={errors.password_lama}><input type="password" autoComplete="current-password" value={form.password_lama} onChange={set('password_lama')} className={inputCls(errors.password_lama)} /></FormRow>
        <FormRow label="Password Baru" help="Minimal 8 karakter" error={errors.password_baru}><input type="password" autoComplete="new-password" value={form.password_baru} onChange={set('password_baru')} className={inputCls(errors.password_baru)} /></FormRow>
        <FormRow label="Konfirmasi Password Baru" error={errors.konfirmasi}><input type="password" autoComplete="new-password" value={form.konfirmasi} onChange={set('konfirmasi')} className={inputCls(errors.konfirmasi)} /></FormRow>
      </section>
      <div className="flex justify-end"><Button type="submit" disabled={saving}>{saving ? 'Menyimpan…' : 'Simpan Perubahan'}</Button></div>
    </form>
  )
}
