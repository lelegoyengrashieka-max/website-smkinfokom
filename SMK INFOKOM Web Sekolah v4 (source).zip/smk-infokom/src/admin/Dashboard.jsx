import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../lib/api.js'
import { useAdmin } from './AdminContext.jsx'
import { Icon, Spinner, STATUS_COLORS, formatDateTime } from './ui.jsx'
import { ADMIN_PATH } from '../lib/adminPath.js'

export default function Dashboard() {
  const { user } = useAdmin()
  const [s, setS] = useState(null)
  const [err, setErr] = useState('')
  useEffect(() => { api('/api/admin/stats').then(setS).catch((e) => setErr(e.message)) }, [])

  if (err) return <p className="text-red-600">{err}</p>
  if (!s) return <Spinner className="h-7 w-7" />

  const cards = [
    ['Pendaftar PPDB', s.counts.pendaftar, `${s.counts.pendaftarBaru} menunggu verifikasi`, 'clipboard', `${ADMIN_PATH}/pendaftar`],
    ['Pendaftar Magang Jepang', s.counts.magangTotal, `${s.counts.magangBaru} pendaftar baru`, 'plane', `${ADMIN_PATH}/pendaftar_magang`],
    ['Lamaran Kerja BKK', s.counts.lamaranBaru, 'lamaran belum diproses', 'briefcase', `${ADMIN_PATH}/lamaran`],
    ['Lowongan Dibuka', s.counts.lowonganAktif, 'lowongan aktif di BKK', 'briefcase', `${ADMIN_PATH}/lowongan`],
    ['Tracer Study', s.counts.alumniTotal, 'data alumni terkumpul', 'user', `${ADMIN_PATH}/alumni`],
    ['Pesan Belum Dibaca', s.counts.pesanBaru, 'dari formulir kontak', 'mail', `${ADMIN_PATH}/pesan`],
    ['Berita', s.counts.berita, 'artikel & pengumuman', 'news', `${ADMIN_PATH}/berita`],
    ['Guru & Staf', s.counts.guru, 'tenaga pendidik', 'user', `${ADMIN_PATH}/guru`],
    ['Jurusan', s.counts.jurusan, 'program keahlian', 'cap', `${ADMIN_PATH}/jurusan`],
    ['Foto Galeri', s.counts.galeri, 'dokumentasi', 'image', `${ADMIN_PATH}/galeri`],
    ['Prestasi', s.counts.prestasi, 'capaian siswa', 'trophy', `${ADMIN_PATH}/prestasi`],
  ]
  const max = Math.max(1, ...s.perJurusan.map((j) => j.n))

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy">Selamat datang, {user?.nama}</h1>
        <p className="mt-1 text-[14px] text-ink/60">Ringkasan aktivitas situs sekolah.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(([label, n, sub, icon, to]) => (
          <Link key={label} to={to} className="group rounded-2xl border border-slate-200 bg-white p-5 transition hover:border-navy/30 hover:shadow-md">
            <div className="flex items-center justify-between">
              <p className="text-[13px] font-semibold text-ink/60">{label}</p>
              <span className="rounded-lg bg-slate-100 p-2 text-navy group-hover:bg-navy group-hover:text-white"><Icon name={icon} className="h-4 w-4" /></span>
            </div>
            <p className="mt-3 font-display text-3xl font-semibold text-navy">{n}</p>
            <p className="mt-1 text-[12.5px] text-ink/50">{sub}</p>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Panel title="Pendaftar per Jurusan (pilihan 1)">
          <div className="space-y-4">
            {s.perJurusan.map((j) => (
              <div key={j.slug}>
                <div className="mb-1 flex justify-between text-[13px]"><span>{j.kode} — {j.nama}</span><span className="font-semibold">{j.n}</span></div>
                <div className="h-2.5 rounded-full bg-slate-100"><div className="h-2.5 rounded-full bg-teal" style={{ width: `${(j.n / max) * 100}%` }} /></div>
              </div>
            ))}
          </div>
          {s.perStatus.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-2 border-t border-slate-100 pt-4">
              {s.perStatus.map((p) => <span key={p.status} className={`rounded-full px-3 py-1 text-[12px] font-semibold ${STATUS_COLORS[p.status] || 'bg-slate-100'}`}>{p.status}: {p.n}</span>)}
            </div>
          )}
        </Panel>

        <Panel title="Pendaftar Terbaru" action={<Link to={`${ADMIN_PATH}/pendaftar`} className="text-[13px] text-navy hover:underline">Lihat semua</Link>}>
          {s.recentPendaftar.length === 0 ? <Empty /> : (
            <ul className="divide-y divide-slate-100">
              {s.recentPendaftar.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-[14px] font-semibold">{p.nama}</p>
                    <p className="text-[12px] text-ink/50">{p.nomor} · {p.asal_sekolah} · {p.jurusan_1?.toUpperCase()}</p>
                  </div>
                  <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-[11.5px] font-semibold ${STATUS_COLORS[p.status]}`}>{p.status}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Pesan Masuk Terbaru" action={<Link to={`${ADMIN_PATH}/pesan`} className="text-[13px] text-navy hover:underline">Lihat semua</Link>}>
          {s.recentPesan.length === 0 ? <Empty /> : (
            <ul className="divide-y divide-slate-100">
              {s.recentPesan.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <p className={`truncate text-[14px] ${p.dibaca ? '' : 'font-semibold'}`}>{p.subjek || '(tanpa subjek)'}</p>
                    <p className="text-[12px] text-ink/50">{p.nama} · {formatDateTime(p.created_at)}</p>
                  </div>
                  {!p.dibaca && <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-amber" title="Belum dibaca" />}
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Berita Terbaru" action={<Link to={`${ADMIN_PATH}/berita`} className="text-[13px] text-navy hover:underline">Kelola</Link>}>
          {s.recentBerita.length === 0 ? <Empty /> : (
            <ul className="divide-y divide-slate-100">
              {s.recentBerita.map((b) => (
                <li key={b.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-[14px] font-semibold">{b.judul}</p>
                    <p className="text-[12px] text-ink/50">{b.kategori} · {String(b.tanggal || '').slice(0, 10)}</p>
                  </div>
                  <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-[11.5px] font-semibold ${STATUS_COLORS[b.status]}`}>{b.status}</span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  )
}

function Panel({ title, action, children }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-6">
      <div className="mb-4 flex items-center justify-between"><h2 className="font-display text-[16px] font-semibold text-navy">{title}</h2>{action}</div>
      {children}
    </section>
  )
}
const Empty = () => <p className="py-6 text-center text-[13.5px] text-ink/45">Belum ada data.</p>
