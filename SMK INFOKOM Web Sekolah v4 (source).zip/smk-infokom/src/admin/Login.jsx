import { useEffect, useState } from 'react'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { api, auth } from '../lib/api.js'
import { inputCls } from './ui.jsx'
import { ADMIN_PATH } from '../lib/adminPath.js'

export default function Login() {
  const navigate = useNavigate()
  const loc = useLocation()
  const [form, setForm] = useState({ username: '', password: '' })
  const [state, setState] = useState({ loading: false, error: loc.state?.expired ? 'Sesi Anda berakhir. Silakan masuk kembali.' : '' })
  useEffect(() => { document.title = 'Masuk — Panel Admin' }, [])

  if (auth.token) return <Navigate to={`${ADMIN_PATH}/dashboard`} replace />

  const submit = async (e) => {
    e.preventDefault()
    setState({ loading: true, error: '' })
    try {
      const { token, user } = await api('/api/auth/login', { method: 'POST', body: form })
      auth.save(token, user)
      navigate(`${ADMIN_PATH}/dashboard`, { replace: true })
    } catch (err) {
      setState({ loading: false, error: err.message })
    }
  }

  return (
    <div className="grid min-h-screen bg-slate-100 lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-navy lg:block">
        <img src={import.meta.env.BASE_URL + "images/hero/beranda.jpg"} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" onError={(e) => { e.currentTarget.style.display = 'none' }} />
        <div className="relative flex h-full flex-col justify-between p-12 text-white">
          <Link to="/" className="font-display text-lg font-semibold">← Kembali ke situs</Link>
          <div>
            <p className="font-mono text-[12px] uppercase tracking-[0.2em] text-amber">Panel Admin</p>
            <h1 className="mt-4 max-w-md font-display text-4xl font-semibold leading-tight">Kelola seluruh konten situs sekolah dari satu tempat.</h1>
            <p className="mt-4 max-w-md text-white/65">Berita, galeri, guru, jurusan, PPDB online, pesan masuk, dan pengaturan situs.</p>
          </div>
          <p className="text-[12.5px] text-white/40">Akses khusus operator dan admin sekolah.</p>
        </div>
      </div>
      <div className="flex items-center justify-center p-6">
        <form onSubmit={submit} className="w-full max-w-sm rounded-2xl bg-white p-8 shadow-xl">
          <h2 className="font-display text-2xl font-semibold text-navy">Masuk</h2>
          <p className="mt-1 text-[14px] text-ink/60">Gunakan akun admin atau editor Anda.</p>
          <div className="mt-7 space-y-4">
            <div>
              <label htmlFor="u" className="mb-1.5 block text-[13px] font-semibold text-ink/80">Username</label>
              <input id="u" autoComplete="username" autoFocus value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} className={inputCls()} required />
            </div>
            <div>
              <label htmlFor="p" className="mb-1.5 block text-[13px] font-semibold text-ink/80">Password</label>
              <input id="p" type="password" autoComplete="current-password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className={inputCls()} required />
            </div>
          </div>
          {state.error && <p className="mt-4 rounded-lg bg-red-50 px-3 py-2.5 text-[13px] text-red-700">{state.error}</p>}
          <button type="submit" disabled={state.loading} className="mt-6 w-full rounded-lg bg-navy py-3 text-[14px] font-semibold text-white hover:bg-navy-light disabled:opacity-60">
            {state.loading ? 'Memproses…' : 'Masuk'}
          </button>
          <Link to="/" className="mt-5 block text-center text-[13px] text-ink/50 hover:text-navy lg:hidden">Kembali ke situs</Link>
        </form>
      </div>
    </div>
  )
}
