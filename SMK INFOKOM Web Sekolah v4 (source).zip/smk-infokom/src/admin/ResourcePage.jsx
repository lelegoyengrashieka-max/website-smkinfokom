import { useCallback, useEffect, useMemo, useState } from 'react'
import { Navigate, useParams, useSearchParams } from 'react-router-dom'
import { api, assetUrl } from '../lib/api.js'
import { useAdmin } from './AdminContext.jsx'
import { instagramEmbedUrl, instagramPermalink } from '../lib/instagram.js'
import { Button, FieldInput, FormRow, Icon, Modal, Spinner, STATUS_COLORS, formatDateTime, inputCls, toast } from './ui.jsx'
import { ADMIN_PATH } from '../lib/adminPath.js'

const WIDE_TYPES = new Set(['text', 'longtext', 'list', 'image'])

export default function ResourcePage() {
  const { resource } = useParams()
  const { meta } = useAdmin()
  const def = meta.resources[resource]
  if (!def) return <Navigate to={`${ADMIN_PATH}/dashboard`} replace />
  return <ResourceTable key={resource} name={resource} def={def} />
}

function ResourceTable({ name, def }) {
  const { jurusan, reloadJurusan } = useAdmin()
  const [params, setParams] = useSearchParams()
  const [data, setData] = useState({ data: [], total: 0, pages: 1, page: 1 })
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(null) // {} = tambah, row = edit
  const [removing, setRemoving] = useState(null)
  const [q, setQ] = useState(params.get('q') || '')

  const query = useMemo(() => {
    const o = { page: params.get('page') || 1, limit: 20, q: params.get('q') || undefined }
    ;(def.filters || []).forEach((f) => { if (params.get(f)) o[f] = params.get(f) })
    return o
  }, [params, def])

  const load = useCallback(() => {
    setLoading(true)
    api(`/api/admin/${name}`, { query })
      .then(setData)
      .catch((e) => toast(e.message, 'error'))
      .finally(() => setLoading(false))
  }, [name, query])

  useEffect(() => { load() }, [load])
  useEffect(() => { document.title = `${def.label} — Panel Admin` }, [def])

  const setParam = (patch) => {
    const next = new URLSearchParams(params)
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)))
    if (!('page' in patch)) next.delete('page')
    setParams(next)
  }

  const jurusanOpts = jurusan.map((j) => [j.slug, `${j.kode} — ${j.nama}`])
  const optionsFor = (key) => (name === 'pendaftar' && (key === 'jurusan_1' || key === 'jurusan_2') ? jurusanOpts : undefined)

  const exportCsv = async () => {
    try {
      const res = await api(`/api/admin/${name}/export.csv`, { query: { ...query, page: undefined, limit: undefined }, raw: true, headers: {} })
      const blob = await res.blob()
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = `${name}-${new Date().toISOString().slice(0, 10)}.csv`
      a.click()
      URL.revokeObjectURL(a.href)
    } catch (e) { toast(e.message, 'error') }
  }

  const openRow = async (row) => {
    setEditing(row)
    if (name === 'pesan' && !row.dibaca) {
      try { await api(`/api/admin/pesan/${row.id}`, { method: 'PUT', body: { dibaca: true } }); load() } catch { /* abaikan */ }
    }
  }

  const doDelete = async () => {
    try {
      await api(`/api/admin/${name}/${removing.id}`, { method: 'DELETE' })
      toast(`${def.singular} dihapus.`)
      setRemoving(null)
      if (name === 'jurusan') reloadJurusan()
      load()
    } catch (e) { toast(e.message, 'error') }
  }

  const columns = def.columns || [def.titleField]
  const title = (row) => row[def.titleField] || `#${row.id}`

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[12px] font-semibold uppercase tracking-[0.14em] text-ink/45">{def.group}</p>
          <h1 className="font-display text-2xl font-semibold text-navy">{def.label}</h1>
          <p className="mt-1 text-[13.5px] text-ink/55">{data.total} data</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {def.exportable && <Button variant="outline" onClick={exportCsv}><Icon name="download" className="h-4 w-4" />Ekspor CSV</Button>}
          {def.canCreate !== false && <Button onClick={() => setEditing({})}><Icon name="plus" className="h-4 w-4" />Tambah {def.singular}</Button>}
        </div>
      </div>

      <div className="flex flex-wrap gap-3 rounded-2xl border border-slate-200 bg-white p-4">
        {def.searchable?.length > 0 && (
          <form className="relative min-w-[220px] flex-1" onSubmit={(e) => { e.preventDefault(); setParam({ q: q.trim() }) }}>
            <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Cari ${def.label.toLowerCase()}…`} className={inputCls() + ' pl-9'} />
          </form>
        )}
        {(def.filters || []).map((f) => {
          const field = def.fields[f] || {}
          const opts = optionsFor(f) || (field.type === 'bool' ? [['true', 'Ya'], ['false', 'Tidak']] : (field.options || []).map((o) => [o, o]))
          return (
            <select key={f} value={params.get(f) || ''} onChange={(e) => setParam({ [f]: e.target.value })} className={inputCls() + ' w-auto min-w-[160px]'} aria-label={field.label}>
              <option value="">{field.label}: Semua</option>
              {opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          )
        })}
      </div>

      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[13.5px]">
            <thead className="border-b border-slate-200 bg-slate-50 text-[12px] uppercase tracking-wider text-ink/55">
              <tr>
                {columns.map((c) => <th key={c} className="whitespace-nowrap px-4 py-3 font-semibold">{def.fields[c]?.label || (c === 'created_at' ? 'Dibuat' : c)}</th>)}
                <th className="px-4 py-3 text-right font-semibold">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading && <tr><td colSpan={columns.length + 1} className="px-4 py-10 text-center"><Spinner /></td></tr>}
              {!loading && data.data.length === 0 && <tr><td colSpan={columns.length + 1} className="px-4 py-12 text-center text-ink/45">Belum ada data.</td></tr>}
              {!loading && data.data.map((row) => (
                <tr key={row.id} className={`hover:bg-slate-50 ${name === 'pesan' && !row.dibaca ? 'font-semibold' : ''}`}>
                  {columns.map((c) => <td key={c} className="max-w-[320px] px-4 py-3 align-middle"><Cell field={def.fields[c]} col={c} value={row[c]} jurusan={jurusan} /></td>)}
                  <td className="whitespace-nowrap px-4 py-3 text-right">
                    <button type="button" onClick={() => openRow(row)} className="rounded-lg p-2 text-navy hover:bg-slate-100" title={def.canCreate === false ? 'Lihat' : 'Ubah'}><Icon name="edit" className="h-4 w-4" /></button>
                    <button type="button" onClick={() => setRemoving(row)} className="rounded-lg p-2 text-red-600 hover:bg-red-50" title="Hapus"><Icon name="trash" className="h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {data.pages > 1 && (
          <div className="flex items-center justify-between border-t border-slate-200 px-4 py-3 text-[13px]">
            <span className="text-ink/55">Halaman {data.page} dari {data.pages}</span>
            <div className="flex gap-2">
              <Button variant="outline" disabled={data.page <= 1} onClick={() => setParam({ page: String(data.page - 1) })}>Sebelumnya</Button>
              <Button variant="outline" disabled={data.page >= data.pages} onClick={() => setParam({ page: String(data.page + 1) })}>Berikutnya</Button>
            </div>
          </div>
        )}
      </div>

      {editing && (
        <EditModal
          name={name}
          def={def}
          row={editing}
          optionsFor={optionsFor}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); if (name === 'jurusan') reloadJurusan(); load() }}
        />
      )}

      {removing && (
        <Modal title={`Hapus ${def.singular}?`} onClose={() => setRemoving(null)} footer={<><Button variant="outline" onClick={() => setRemoving(null)}>Batal</Button><Button variant="danger" onClick={doDelete}>Ya, hapus</Button></>}>
          <p className="text-[14px] text-ink/75">Data <strong>{title(removing)}</strong> akan dihapus permanen dan tidak dapat dikembalikan.</p>
        </Modal>
      )}
    </div>
  )
}

function Cell({ field, col, value, jurusan }) {
  if (col === 'created_at' || col === 'updated_at') return <span className="whitespace-nowrap text-ink/60">{formatDateTime(value)}</span>
  if (!field) return <span>{String(value ?? '—')}</span>
  if (field.type === 'image') return value ? <img src={assetUrl(value)} alt="" className="h-11 w-16 rounded-md object-cover" loading="lazy" /> : <span className="text-ink/30">—</span>
  if (field.type === 'bool') return <span className={`rounded-full px-2.5 py-0.5 text-[11.5px] font-semibold ${value ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>{value ? 'Ya' : 'Tidak'}</span>
  if (field.type === 'list') return <span className="text-ink/60">{(value || []).length} item</span>
  if (field.type === 'url' && value) return <a href={instagramPermalink(value)} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} className="line-clamp-1 max-w-[220px] break-all text-navy underline decoration-slate-300 hover:decoration-navy">{String(value).replace(/^https?:\/\/(www\.)?/, '')}</a>
  if (col === 'jurusan_1' || col === 'jurusan_2') return <span>{jurusan.find((j) => j.slug === value)?.kode || value || '—'}</span>
  if (field.type === 'select' && STATUS_COLORS[value]) return <span className={`rounded-full px-2.5 py-0.5 text-[11.5px] font-semibold ${STATUS_COLORS[value]}`}>{value}</span>
  if (field.type === 'date') return <span className="whitespace-nowrap">{value ? new Date(value).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}</span>
  return <span className="line-clamp-2">{value === null || value === undefined || value === '' ? '—' : String(value)}</span>
}

function EditModal({ name, def, row, optionsFor, onClose, onSaved }) {
  const isNew = !row.id
  const readOnly = def.canCreate === false && name === 'pesan'
  const [form, setForm] = useState(() => {
    const o = {}
    Object.entries(def.fields).forEach(([k, f]) => {
      if (isNew) o[k] = f.default !== undefined ? f.default : f.type === 'list' ? [] : f.type === 'bool' ? false : f.type === 'date' ? new Date().toISOString().slice(0, 10) : ''
      else o[k] = f.type === 'password' ? '' : row[k] ?? (f.type === 'list' ? [] : '')
    })
    return o
  })
  const [errors, setErrors] = useState({})
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const save = async () => {
    setSaving(true); setErrors({}); setError('')
    const body = {}
    Object.entries(def.fields).forEach(([k, f]) => {
      if (f.readonly) return
      let v = form[k]
      if (f.type === 'password' && !v) return
      if (f.type === 'list') v = (v || []).map((s) => String(s).trim()).filter(Boolean)
      body[k] = v
    })
    try {
      if (isNew) await api(`/api/admin/${name}`, { method: 'POST', body })
      else await api(`/api/admin/${name}/${row.id}`, { method: 'PUT', body })
      toast(isNew ? `${def.singular} ditambahkan.` : 'Perubahan disimpan.')
      onSaved()
    } catch (e) {
      setErrors(e.details || {}); setError(e.message)
    } finally { setSaving(false) }
  }

  const entries = Object.entries(def.fields).filter(([, f]) => !(isNew && f.readonly))

  return (
    <Modal
      wide
      title={readOnly ? `Detail ${def.singular}` : isNew ? `Tambah ${def.singular}` : `Ubah ${def.singular}`}
      onClose={onClose}
      footer={readOnly ? (
        <>
          {row.email && <a href={`mailto:${row.email}?subject=${encodeURIComponent('Re: ' + (row.subjek || ''))}`} className="inline-flex items-center rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-[13.5px] font-semibold hover:border-navy">Balas via Email</a>}
          <Button onClick={onClose}>Tutup</Button>
        </>
      ) : (
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={save} disabled={saving}>{saving ? 'Menyimpan…' : 'Simpan'}</Button>
        </>
      )}
    >
      {readOnly ? (
        <dl className="space-y-4 text-[14px]">
          {entries.filter(([k]) => k !== 'dibaca').map(([k, f]) => (
            <div key={k}><dt className="text-[12px] font-semibold uppercase tracking-wider text-ink/50">{f.label}</dt><dd className="mt-1 whitespace-pre-line">{row[k] || '—'}</dd></div>
          ))}
          <div><dt className="text-[12px] font-semibold uppercase tracking-wider text-ink/50">Diterima</dt><dd className="mt-1">{formatDateTime(row.created_at)}</dd></div>
        </dl>
      ) : (
        <div className="grid gap-5 md:grid-cols-2">
          {entries.map(([k, f]) => (
            <div key={k} className={WIDE_TYPES.has(f.type) ? 'md:col-span-2' : ''}>
              <FormRow label={f.label} required={f.required && !(f.type === 'password' && !isNew)} help={f.help} error={errors[k]} htmlFor={k}>
                <FieldInput name={k} field={f} value={form[k]} options={optionsFor(k)} error={errors[k]} onChange={(v) => { setForm((s) => ({ ...s, [k]: v })); if (errors[k]) setErrors((e) => ({ ...e, [k]: undefined })) }} />
              </FormRow>
            </div>
          ))}
        </div>
      )}
      {name.startsWith('video_') && !readOnly && <IgPreview url={form.url} />}
      {error && <p className="mt-5 rounded-lg bg-red-50 px-3 py-2.5 text-[13px] text-red-700">{error}</p>}
    </Modal>
  )
}

/** Pratinjau langsung video Instagram di form admin. */
function IgPreview({ url }) {
  const src = instagramEmbedUrl(url)
  return (
    <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-4">
      <p className="text-[12px] font-semibold uppercase tracking-wider text-ink/50">Pratinjau video</p>
      {src ? (
        <div className="mt-3 flex justify-center">
          <iframe key={src} src={src} title="Pratinjau Instagram" className="h-[560px] w-full max-w-[360px] rounded-lg border border-slate-200 bg-white" loading="lazy" allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen />
        </div>
      ) : (
        <p className="mt-2 text-[13px] text-ink/60">Tempel tautan Reel/Post Instagram yang valid untuk melihat pratinjau, mis. <code className="rounded bg-white px-1">https://www.instagram.com/reel/ABC123/</code></p>
      )}
    </div>
  )
}
