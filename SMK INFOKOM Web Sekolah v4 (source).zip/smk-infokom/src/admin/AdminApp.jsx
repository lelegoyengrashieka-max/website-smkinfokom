import { useCallback, useEffect, useState } from 'react'
import { Navigate, NavLink, Outlet, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { api, auth } from '../lib/api.js'
import { AdminContext, useAdmin } from './AdminContext.jsx'
import { Icon, Spinner, Toaster } from './ui.jsx'
import Login from './Login.jsx'
import Dashboard from './Dashboard.jsx'
import ResourcePage from './ResourcePage.jsx'
import SettingsPage from './SettingsPage.jsx'
import AccountPage from './AccountPage.jsx'
import { ADMIN_PATH } from '../lib/adminPath.js'

export default function AdminApp() {
  // Panel admin tidak untuk diindeks mesin pencari
  useEffect(() => {
    const m = document.createElement('meta')
    m.name = 'robots'; m.content = 'noindex, nofollow'
    document.head.appendChild(m)
    return () => m.remove()
  }, [])
  return (
    <>
      <Routes>
        <Route index element={<Login />} />
        <Route element={<Protected />}>
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="pengaturan" element={<SettingsPage />} />
          <Route path="akun" element={<AccountPage />} />
          <Route path=":resource" element={<ResourcePage />} />
        </Route>
        <Route path="*" element={<Navigate to={ADMIN_PATH} replace />} />
      </Routes>
      <Toaster />
    </>
  )
}

function Protected() {
  const navigate = useNavigate()
  const [user, setUserState] = useState(auth.user)
  const [meta, setMeta] = useState(null)
  const [jurusan, setJurusan] = useState([])
  const [error, setError] = useState('')

  const logout = useCallback(() => { auth.clear(); navigate(ADMIN_PATH, { replace: true }) }, [navigate])
  const setUser = (u) => { auth.setUser(u); setUserState(u) }

  useEffect(() => {
    if (!auth.token) return
    const onExpired = () => navigate(ADMIN_PATH, { replace: true, state: { expired: true } })
    window.addEventListener('smk-auth-expired', onExpired)
    Promise.all([api('/api/admin/meta'), api('/api/auth/me'), api('/api/admin/jurusan', { query: { limit: 100 } })])
      .then(([m, me, j]) => { setMeta(m); setUser(me.user); setJurusan(j.data) })
      .catch((e) => setError(e.message))
    return () => window.removeEventListener('smk-auth-expired', onExpired)
  }, [navigate])

  useEffect(() => { document.title = 'Panel Admin' }, [])

  if (!auth.token) return <Navigate to={ADMIN_PATH} replace />
  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-100 p-6 text-center">
        <div><p className="text-red-600">{error}</p><button type="button" className="mt-4 underline" onClick={() => window.location.reload()}>Muat ulang</button></div>
      </div>
    )
  }
  if (!meta) return <div className="flex min-h-screen items-center justify-center bg-slate-100"><Spinner className="h-8 w-8" /></div>

  return (
    <AdminContext.Provider value={{ meta, user, setUser, logout, jurusan, reloadJurusan: () => api('/api/admin/jurusan', { query: { limit: 100 } }).then((j) => setJurusan(j.data)) }}>
      <Shell />
    </AdminContext.Provider>
  )
}

function Shell() {
  const { meta, user, logout } = useAdmin()
  const [open, setOpen] = useState(false)
  const loc = useLocation()
  useEffect(() => setOpen(false), [loc.pathname])

  const groups = {}
  Object.entries(meta.resources).forEach(([key, r]) => { (groups[r.group] ||= []).push([key, r]) })

  const link = ({ isActive }) =>
    `flex items-center gap-3 rounded-lg px-3 py-2 text-[13.5px] transition ${isActive ? 'bg-white/10 text-white font-semibold' : 'text-white/65 hover:bg-white/5 hover:text-white'}`

  const sidebar = (
    <nav className="flex h-full flex-col">
      <div className="flex items-center gap-3 border-b border-white/10 px-5 py-5">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber font-display text-sm font-bold text-navy">SI</span>
        <div>
          <p className="font-display text-[15px] font-semibold text-white">Panel Admin</p>
          <p className="text-[11.5px] text-white/50">Manajemen situs sekolah</p>
        </div>
      </div>
      <div className="flex-1 space-y-5 overflow-y-auto px-3 py-4">
        <div className="space-y-0.5">
          <NavLink to={`${ADMIN_PATH}/dashboard`} className={link}><Icon name="dashboard" className="h-[18px] w-[18px]" />Dashboard</NavLink>
        </div>
        {Object.entries(groups).map(([g, items]) => (
          <div key={g}>
            <p className="px-3 pb-1.5 text-[10.5px] font-semibold uppercase tracking-[0.16em] text-white/35">{g}</p>
            <div className="space-y-0.5">
              {items.map(([key, r]) => (
                <NavLink key={key} to={`${ADMIN_PATH}/${key}`} className={link}><Icon name={r.icon} className="h-[18px] w-[18px]" />{r.label}</NavLink>
              ))}
            </div>
          </div>
        ))}
        <div>
          <p className="px-3 pb-1.5 text-[10.5px] font-semibold uppercase tracking-[0.16em] text-white/35">Akun</p>
          <div className="space-y-0.5">
            {user?.role === 'admin' && <NavLink to={`${ADMIN_PATH}/pengaturan`} className={link}><Icon name="settings" className="h-[18px] w-[18px]" />Pengaturan Situs</NavLink>}
            <NavLink to={`${ADMIN_PATH}/akun`} className={link}><Icon name="key" className="h-[18px] w-[18px]" />Akun Saya</NavLink>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 p-3">
        <a href="/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 rounded-lg px-3 py-2 text-[13.5px] text-white/65 hover:bg-white/5 hover:text-white"><Icon name="external" className="h-[18px] w-[18px]" />Lihat Situs</a>
        <button type="button" onClick={logout} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-[13.5px] text-white/65 hover:bg-white/5 hover:text-white"><Icon name="logout" className="h-[18px] w-[18px]" />Keluar</button>
      </div>
    </nav>
  )

  return (
    <div className="min-h-screen bg-slate-100 font-body text-ink">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 bg-navy lg:block">{sidebar}</aside>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-navy">{sidebar}</aside>
        </div>
      )}
      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-200 bg-white/90 px-4 backdrop-blur md:px-8">
          <button type="button" className="rounded-lg p-2 hover:bg-slate-100 lg:hidden" onClick={() => setOpen(true)} aria-label="Buka menu"><Icon name="menu" /></button>
          <div className="hidden lg:block" />
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-[13.5px] font-semibold text-ink">{user?.nama}</p>
              <p className="text-[11.5px] uppercase tracking-wider text-ink/50">{user?.role}</p>
            </div>
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-navy text-[13px] font-bold text-white">{(user?.nama || '?').slice(0, 1).toUpperCase()}</span>
          </div>
        </header>
        <main className="p-4 md:p-8"><Outlet /></main>
      </div>
    </div>
  )
}
