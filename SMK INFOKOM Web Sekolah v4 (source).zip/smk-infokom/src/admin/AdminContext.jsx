import { createContext, useContext } from 'react'
export const AdminContext = createContext({ meta: null, user: null, setUser: () => {}, logout: () => {}, jurusan: [] })
export const useAdmin = () => useContext(AdminContext)
