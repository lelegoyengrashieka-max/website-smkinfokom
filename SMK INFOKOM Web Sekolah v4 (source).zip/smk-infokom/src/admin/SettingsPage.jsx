import { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'
import { api } from '../lib/api.js'
import { useAdmin } from './AdminContext.jsx'
import { Button, FormRow, ImageInput, Spinner, inputCls, toast } from './ui.jsx'
import { ADMIN_PATH } from '../lib/adminPath.js'

export default function SettingsPage() {
  const { meta, user } = useAdmin()
  const groups = meta.settings || []
  const [values, setValues] = useState(null)
  const [active, setActive] = useState(groups[0]?.key)
  const [saving, setSaving] = useState(false)

  useEffect(() => { api('/api/admin/settings').then(setValues).catch((e) => toast(e.message, 'error')) }, [])
  useEffect(() => { document.title = 'Pengaturan Situs — Panel Admin' }, [])

  if (user?.role !== 'admin') return <Navigate to={`${ADMIN_PATH}/dashboard`} replace />
  if (!values) return <Spinner className="h-7 w-7" />

  const group = groups.find((g) => g.key === active) || groups[0]
  const set = (k, v) => setValues((s) => ({ ...s, [k]: v }))

  const save = async () => {
    setSaving(true)
    try {
      const body = Object.fromEntries(group.fields.map((f) => [f.key, values[f.key] ?? '']))
      setValues(await api('/api/admin/settings', { method: 'PUT', body }))
      toast('Pengaturan disimpan. Muat ulang situs publik untuk melihat perubahan.')
    } catch (e) { toast(e.message, 'error') } finally { setSaving(false) }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-navy">Pengaturan Situs</h1>
        <p className="mt-1 text-[13.5px] text-ink/55">Teks, gambar, dan informasi umum yang tampil di halaman publik.</p>
      </div>
      <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
        <nav className="flex gap-1 overflow-x-auto rounded-2xl border border-slate-200 bg-white p-2 lg:flex-col lg:self-start">
          {groups.map((g) => (
            <button key={g.key} type="button" onClick={() => setActive(g.key)} className={`whitespace-nowrap rounded-lg px-3 py-2 text-left text-[13.5px] ${g.key === group.key ? 'bg-navy font-semibold text-white' : 'text-ink/70 hover:bg-slate-100'}`}>{g.label}</button>
          ))}
        </nav>
        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="mb-6 font-display text-lg font-semibold text-navy">{group.label}</h2>
          <div className="space-y-5">
            {group.fields.map((f) => (
              <FormRow key={f.key} label={f.label} help={f.help || (f.type === 'lines' ? 'Satu item per baris' : f.type === 'pairs' ? 'Format per baris: Label | Nilai' : '')} htmlFor={f.key}>
                {f.type === 'image' ? <ImageInput value={values[f.key]} onChange={(v) => set(f.key, v)} />
                  : f.type === 'bool' ? (
                    <label className="inline-flex items-center gap-3">
                      <input type="checkbox" checked={values[f.key] !== 'false'} onChange={(e) => set(f.key, e.target.checked ? 'true' : 'false')} className="h-4 w-4 accent-navy" />
                      <span className="text-[14px]">{values[f.key] !== 'false' ? 'Aktif' : 'Nonaktif'}</span>
                    </label>
                  ) : f.type === 'text' ? <input id={f.key} value={values[f.key] ?? ''} onChange={(e) => set(f.key, e.target.value)} className={inputCls()} />
                  : <textarea id={f.key} rows={f.type === 'textarea' ? 3 : 6} value={values[f.key] ?? ''} onChange={(e) => set(f.key, e.target.value)} className={inputCls() + ' leading-relaxed'} />}
              </FormRow>
            ))}
          </div>
          <div className="mt-8 flex justify-end border-t border-slate-100 pt-5">
            <Button onClick={save} disabled={saving}>{saving ? 'Menyimpan…' : 'Simpan Pengaturan'}</Button>
          </div>
        </section>
      </div>
    </div>
  )
}
