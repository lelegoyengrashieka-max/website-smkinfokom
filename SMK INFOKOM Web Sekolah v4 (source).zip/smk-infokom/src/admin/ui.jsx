import { useEffect, useRef, useState } from 'react'
import { assetUrl, uploadImage } from '../lib/api.js'

/* ---------- Ikon sederhana (stroke) ---------- */
const PATHS = {
  dashboard: 'M3 13h8V3H3v10Zm10 8h8V11h-8v10ZM3 21h8v-6H3v6Zm10-18v6h8V3h-8Z',
  news: 'M4 5h13v14H6a2 2 0 0 1-2-2V5Zm13 4h3v8a2 2 0 0 1-2 2M8 9h5M8 13h5',
  calendar: 'M4 6h16v14H4zM4 10h16M9 3v4M15 3v4',
  image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M15 9h.01',
  trophy: 'M8 4h8v5a4 4 0 0 1-8 0V4Zm0 2H5a3 3 0 0 0 3 4m8-4h3a3 3 0 0 1-3 4M12 13v4m-4 3h8',
  star: 'm12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9L12 3Z',
  quote: 'M7 7h4v4c0 3-1.5 5-4 6m6-10h4v4c0 3-1.5 5-4 6',
  cap: 'm2 9 10-5 10 5-10 5L2 9Zm4 2v5c3 2.5 9 2.5 12 0v-5',
  user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 9a7 7 0 0 1 14 0',
  tree: 'M9 3h6v5H9zM3 16h6v5H3zm12 0h6v5h-6zM12 8v4M6 16v-4h12v4',
  building: 'M4 21V5l8-3 8 3v16M9 21v-5h6v5M8 8h.01M12 8h.01M16 8h.01M8 12h.01M12 12h.01M16 12h.01',
  clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-13v5l3 2',
  handshake: 'm11 17 2 2a1.5 1.5 0 0 0 2-2m-4 0 2.5 2.5M11 17l-4-4 4.5-4.5 5 5M3 11l4 4m14-4-4 4M7 7l4-2 3 2',
  clipboard: 'M9 4h6v3H9zM7 5H5v16h14V5h-2M9 12h6M9 16h4',
  money: 'M3 7h18v10H3zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z',
  steps: 'M4 20h4v-4h4v-4h4V8h4',
  help: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm-2.5-11.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14m0 3h.01',
  mail: 'M3 6h18v12H3zM3 7l9 6 9-6',
  briefcase: 'M4 8h16v11H4zM9 8V5h6v3M4 13h16',
  plane: 'M3 14l18-7-7 18-2-8-9-3Z',
  file: 'M6 3h8l4 4v14H6zM14 3v4h4',
  shield: 'M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7.4-3a7.4 7.4 0 0 0-.1-1.3l2-1.6-2-3.4-2.4 1a7.6 7.6 0 0 0-2.2-1.3L14.3 3h-4l-.4 2.4a7.6 7.6 0 0 0-2.2 1.3l-2.4-1-2 3.4 2 1.6a7.4 7.4 0 0 0 0 2.6l-2 1.6 2 3.4 2.4-1a7.6 7.6 0 0 0 2.2 1.3l.4 2.4h4l.4-2.4a7.6 7.6 0 0 0 2.2-1.3l2.4 1 2-3.4-2-1.6c.1-.4.1-.9.1-1.3Z',
  logout: 'M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11',
  plus: 'M12 5v14M5 12h14',
  video: 'M4 6h11v12H4zM15 10l5-3v10l-5-3',
  search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14Zm5-2 4 4',
  edit: 'm4 20 4-1 11-11-3-3L5 16l-1 4Zm10-13 3 3',
  trash: 'M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13',
  download: 'M12 4v11m-4-4 4 4 4-4M5 20h14',
  menu: 'M4 6h16M4 12h16M4 18h16',
  x: 'M6 6l12 12M18 6 6 18',
  external: 'M14 4h6v6m0-6-9 9M18 14v6H4V6h6',
  key: 'M14 10a4 4 0 1 0-3.5 4L9 16H7v2H5v2H3v-3l6.5-6.5A4 4 0 0 0 14 10Zm1-2h.01',
}

export function Icon({ name, className = 'h-5 w-5' }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d={PATHS[name] || PATHS.dashboard} />
    </svg>
  )
}

export const inputCls = (error) =>
  `w-full rounded-lg border bg-white px-3 py-2.5 text-[14px] text-ink outline-none transition focus:border-navy focus:ring-2 focus:ring-navy/10 ${error ? 'border-red-400' : 'border-slate-300'}`

export function Button({ variant = 'primary', className = '', children, ...rest }) {
  const styles = {
    primary: 'bg-navy text-white hover:bg-navy-light',
    outline: 'border border-slate-300 bg-white text-ink hover:border-navy hover:text-navy',
    danger: 'bg-red-600 text-white hover:bg-red-700',
    ghost: 'text-ink/70 hover:bg-slate-100',
  }
  return (
    <button type="button" className={`inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-[13.5px] font-semibold transition disabled:cursor-not-allowed disabled:opacity-50 ${styles[variant]} ${className}`} {...rest}>
      {children}
    </button>
  )
}

export function Spinner({ className = 'h-5 w-5' }) {
  return <span className={`inline-block animate-spin rounded-full border-2 border-navy/15 border-t-navy ${className}`} />
}

export function Modal({ title, onClose, children, footer, wide }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = '' }
  }, [onClose])
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-900/50 p-4 md:p-8" role="dialog" aria-modal="true">
      <div className={`w-full ${wide ? 'max-w-3xl' : 'max-w-lg'} rounded-2xl bg-white shadow-2xl`}>
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <h2 className="font-display text-lg font-semibold text-navy">{title}</h2>
          <button type="button" onClick={onClose} className="rounded-lg p-1.5 text-ink/50 hover:bg-slate-100" aria-label="Tutup"><Icon name="x" /></button>
        </div>
        <div className="px-6 py-5">{children}</div>
        {footer && <div className="flex justify-end gap-3 border-t border-slate-200 bg-slate-50 px-6 py-4 rounded-b-2xl">{footer}</div>}
      </div>
    </div>
  )
}

/* ---------- Toast ---------- */
let pushToast = () => {}
export const toast = (msg, type = 'success') => pushToast({ msg, type, id: Math.random() })

export function Toaster() {
  const [items, setItems] = useState([])
  useEffect(() => {
    pushToast = (t) => {
      setItems((s) => [...s, t])
      setTimeout(() => setItems((s) => s.filter((x) => x.id !== t.id)), 3500)
    }
    return () => { pushToast = () => {} }
  }, [])
  return (
    <div className="fixed bottom-5 right-5 z-[60] space-y-2">
      {items.map((t) => (
        <div key={t.id} className={`rounded-lg px-4 py-3 text-[13.5px] font-medium text-white shadow-lg ${t.type === 'error' ? 'bg-red-600' : 'bg-teal'}`}>{t.msg}</div>
      ))}
    </div>
  )
}

/* ---------- Unggah gambar ---------- */
export function ImageInput({ value, onChange, error }) {
  const ref = useRef(null)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const pick = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setBusy(true); setErr('')
    try { onChange(await uploadImage(file)) } catch (x) { setErr(x.message) } finally { setBusy(false) }
  }
  return (
    <div>
      <div className="flex items-start gap-4">
        <div className="flex h-24 w-32 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-dashed border-slate-300 bg-slate-50">
          {value ? <img src={assetUrl(value)} alt="" className="h-full w-full object-cover" /> : <Icon name="image" className="h-7 w-7 text-slate-400" />}
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => ref.current?.click()} disabled={busy}>{busy ? <><Spinner className="h-4 w-4" /> Mengunggah…</> : 'Pilih gambar'}</Button>
            {value && <Button variant="ghost" onClick={() => onChange('')}>Hapus</Button>}
          </div>
          <input value={value || ''} onChange={(e) => onChange(e.target.value)} placeholder="atau tempel URL / path gambar" className={inputCls(error) + ' text-[12.5px]'} />
        </div>
      </div>
      <input ref={ref} type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={pick} />
      {err && <p className="mt-1 text-[12.5px] text-red-600">{err}</p>}
    </div>
  )
}

/* ---------- Input generik berdasarkan tipe field ---------- */
export function FieldInput({ name, field, value, onChange, error, options }) {
  const t = field.type
  const opts = options || (field.options || []).map((o) => (Array.isArray(o) ? o : [o, o]))
  if (field.readonly) return <p className="rounded-lg bg-slate-100 px-3 py-2.5 font-mono text-[13.5px] text-ink/70">{value || '—'}</p>
  if (t === 'image') return <ImageInput value={value} onChange={onChange} error={error} />
  if (t === 'bool') {
    return (
      <label className="inline-flex cursor-pointer items-center gap-3">
        <input type="checkbox" checked={!!value} onChange={(e) => onChange(e.target.checked)} className="h-4 w-4 accent-navy" />
        <span className="text-[14px] text-ink/80">{value ? 'Ya' : 'Tidak'}</span>
      </label>
    )
  }
  if (t === 'select') {
    return (
      <select id={name} value={value ?? ''} onChange={(e) => onChange(e.target.value)} className={inputCls(error)}>
        {!field.required || !value ? <option value="">— Pilih —</option> : null}
        {opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    )
  }
  if (t === 'text' || t === 'longtext') {
    return <textarea id={name} rows={t === 'longtext' ? 12 : 4} value={value ?? ''} onChange={(e) => onChange(e.target.value)} className={inputCls(error) + ' leading-relaxed'} />
  }
  if (t === 'list') {
    const text = Array.isArray(value) ? value.join('\n') : value || ''
    return <textarea id={name} rows={5} value={text} onChange={(e) => onChange(e.target.value.split('\n'))} className={inputCls(error)} placeholder="Satu item per baris" />
  }
  const type = { int: 'number', date: 'date', email: 'email', url: 'url', password: 'password' }[t] || 'text'
  return (
    <input id={name} type={type} value={value ?? ''} autoComplete={t === 'password' ? 'new-password' : undefined}
      onChange={(e) => onChange(t === 'int' ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value)} className={inputCls(error)} />
  )
}

export function FormRow({ label, required, help, error, children, htmlFor }) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-[13px] font-semibold text-ink/80">
        {label}{required && <span className="text-red-500"> *</span>}
      </label>
      {children}
      {help && !error && <p className="mt-1 text-[12px] text-ink/50">{help}</p>}
      {error && <p className="mt-1 text-[12.5px] text-red-600">{error}</p>}
    </div>
  )
}

export function formatDateTime(v) {
  if (!v) return '—'
  const d = new Date(String(v).replace(' ', 'T'))
  if (Number.isNaN(d.getTime())) return String(v)
  return d.toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

export const STATUS_COLORS = {
  baru: 'bg-slate-100 text-slate-700', diverifikasi: 'bg-blue-100 text-blue-800', diterima: 'bg-emerald-100 text-emerald-800',
  cadangan: 'bg-amber-100 text-amber-800', ditolak: 'bg-red-100 text-red-700', terbit: 'bg-emerald-100 text-emerald-800', draft: 'bg-slate-100 text-slate-600',
  diproses: 'bg-blue-100 text-blue-800', wawancara: 'bg-violet-100 text-violet-800', dibuka: 'bg-emerald-100 text-emerald-800', ditutup: 'bg-slate-100 text-slate-600',
  'seleksi administrasi': 'bg-blue-100 text-blue-800', 'tes tertulis': 'bg-indigo-100 text-indigo-800', pelatihan: 'bg-amber-100 text-amber-800',
  lolos: 'bg-emerald-100 text-emerald-800', berangkat: 'bg-teal-100 text-teal-800', 'tidak lolos': 'bg-red-100 text-red-700',
}
