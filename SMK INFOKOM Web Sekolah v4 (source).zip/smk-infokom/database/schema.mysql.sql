-- Skema database SMK INFOKOM (MySQL / MariaDB)
-- Dibuat otomatis dari server/resources.js
-- Import lewat phpMyAdmin atau: mysql -u root -p smk_infokom < database/schema.mysql.sql

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `berita`;
create table `berita` (`id` int unsigned not null auto_increment primary key, `judul` varchar(255) null, `slug` varchar(255) null, `kategori` varchar(255) null, `tanggal` date null, `gambar` varchar(500) null, `ringkasan` text null, `isi` longtext null, `penulis` varchar(255) null, `status` varchar(255) null, `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;
alter table `berita` add unique `berita_slug_unique`(`slug`);

DROP TABLE IF EXISTS `agenda`;
create table `agenda` (`id` int unsigned not null auto_increment primary key, `kegiatan` varchar(255) null, `tanggal` date null, `tanggal_selesai` date null, `periode` varchar(255) null, `lokasi` varchar(255) null, `keterangan` text null, `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `galeri`;
create table `galeri` (`id` int unsigned not null auto_increment primary key, `judul` varchar(255) null, `kategori` varchar(255) null, `gambar` varchar(500) null, `tanggal` date null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `prestasi`;
create table `prestasi` (`id` int unsigned not null auto_increment primary key, `judul` varchar(255) null, `tahun` varchar(255) null, `tingkat` varchar(255) null, `peraih` varchar(255) null, `gambar` varchar(500) null, `keterangan` text null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `ekskul`;
create table `ekskul` (`id` int unsigned not null auto_increment primary key, `nama` varchar(255) null, `jadwal` varchar(255) null, `pembina` varchar(255) null, `deskripsi` text null, `gambar` varchar(500) null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `testimoni`;
create table `testimoni` (`id` int unsigned not null auto_increment primary key, `nama` varchar(255) null, `peran` varchar(255) null, `kutipan` text null, `foto` varchar(500) null, `tampil` boolean default '1', `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `jurusan`;
create table `jurusan` (`id` int unsigned not null auto_increment primary key, `nama` varchar(255) null, `kode` varchar(255) null, `slug` varchar(255) null, `tagline` varchar(255) null, `deskripsi` text null, `gambar` varchar(500) null, `skills` text null, `kompetensi` text null, `mapel_x` text null, `mapel_xi` text null, `mapel_xii` text null, `karir` text null, `mitra` text null, `aktif` boolean default '1', `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;
alter table `jurusan` add unique `jurusan_slug_unique`(`slug`);

DROP TABLE IF EXISTS `guru`;
create table `guru` (`id` int unsigned not null auto_increment primary key, `nama` varchar(255) null, `nip` varchar(255) null, `jabatan` varchar(255) null, `bidang` varchar(255) null, `foto` varchar(500) null, `email` varchar(255) null, `telepon` varchar(255) null, `tampil` boolean default '1', `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `struktur`;
create table `struktur` (`id` int unsigned not null auto_increment primary key, `jabatan` varchar(255) null, `nama` varchar(255) null, `level` varchar(255) null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fasilitas`;
create table `fasilitas` (`id` int unsigned not null auto_increment primary key, `ruang` varchar(255) null, `unit` varchar(255) null, `kapasitas` varchar(255) null, `deskripsi` text null, `gambar` varchar(500) null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sejarah`;
create table `sejarah` (`id` int unsigned not null auto_increment primary key, `tahun` varchar(255) null, `teks` text null, `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `mitra`;
create table `mitra` (`id` int unsigned not null auto_increment primary key, `nama` varchar(255) null, `bidang` varchar(255) null, `logo` varchar(500) null, `website` varchar(500) null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `pendaftar`;
create table `pendaftar` (`id` int unsigned not null auto_increment primary key, `nomor` varchar(255) null, `nama` varchar(255) null, `nisn` varchar(255) null, `jenis_kelamin` varchar(255) null, `tempat_lahir` varchar(255) null, `tanggal_lahir` date null, `agama` varchar(255) null, `asal_sekolah` varchar(255) null, `jurusan_1` varchar(255) null, `jurusan_2` varchar(255) null, `nama_ortu` varchar(255) null, `telepon` varchar(255) null, `email` varchar(255) null, `alamat` text null, `status` varchar(255) null, `catatan_admin` text null, `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `biaya`;
create table `biaya` (`id` int unsigned not null auto_increment primary key, `item` varchar(255) null, `nominal` varchar(255) null, `keterangan` varchar(255) null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `tahapan`;
create table `tahapan` (`id` int unsigned not null auto_increment primary key, `label` varchar(255) null, `waktu` varchar(255) null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `faq`;
create table `faq` (`id` int unsigned not null auto_increment primary key, `pertanyaan` varchar(500) null, `jawaban` text null, `urutan` int default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `pesan`;
create table `pesan` (`id` int unsigned not null auto_increment primary key, `nama` varchar(255) null, `email` varchar(255) null, `telepon` varchar(255) null, `subjek` varchar(255) null, `pesan` text null, `dibaca` boolean default '0', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `users`;
create table `users` (`id` int unsigned not null auto_increment primary key, `username` varchar(255) null, `nama` varchar(255) null, `email` varchar(255) null, `password` varchar(255) null, `role` varchar(255) null, `aktif` boolean default '1', `created_at` timestamp default CURRENT_TIMESTAMP, `updated_at` timestamp default CURRENT_TIMESTAMP) default character set utf8mb4 collate utf8mb4_unicode_ci;
alter table `users` add unique `users_username_unique`(`username`);

DROP TABLE IF EXISTS `settings`;
create table `settings` (`key` varchar(100), `value` longtext null, `updated_at` timestamp default CURRENT_TIMESTAMP, primary key (`key`)) default character set utf8mb4 collate utf8mb4_unicode_ci;
