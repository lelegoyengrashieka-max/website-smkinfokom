# SMK INFOKOM — Website Sekolah Lengkap

Website sekolah siap publik dengan panel admin (CRUD penuh), PPDB online, dan database.

- **Frontend**: React 18 + React Router 6 + Vite 5 + Tailwind CSS 3
- **Backend**: Node.js (Express 5) + Knex — REST API, login JWT, unggah gambar
- **Database**: SQLite (bawaan, tanpa instalasi), MySQL/MariaDB, atau PostgreSQL

## Fitur

### Situs publik
| Rute | Isi |
|---|---|
| `/` | Beranda: hero, statistik, profil singkat, jurusan, keunggulan, testimoni alumni, berita + agenda terdekat, ajakan PPDB |
| `/profil` | Sambutan kepala sekolah, visi misi, sejarah, struktur organisasi, guru & staf, ekstrakurikuler, prestasi, tata tertib |
| `/jurusan`, `/jurusan/:slug` | Daftar & detail program keahlian (kompetensi, mapel per tingkat, prospek karier, mitra) |
| `/fasilitas` | Sarana & prasarana |
| `/kurikulum` | Kalender pendidikan, akademik, non akademik |
| `/hubinmas` | BKK, PKL, kemitraan industri, tracer study |
| `/manajemen-mutu` | Penjaminan mutu |
| `/galeri` | Galeri berfilter kategori + lightbox (tombol panah / Esc) |
| `/berita`, `/berita/:slug` | Berita dengan pencarian, filter kategori, paginasi, tombol bagikan |
| `/ppdb` | Informasi PPDB: syarat, tahapan, biaya, FAQ |
| `/ppdb/daftar` | **Formulir pendaftaran online** → menghasilkan nomor `PPDB-2026-0001` |
| `/ppdb/cek-status` | Cek status pendaftaran (nomor + tanggal lahir) beserta catatan panitia |
| `/bkk` | Bursa Kerja Khusus: layanan, lowongan (cari/filter), alur melamar, mitra rekrutmen, pengurus, FAQ |
| `/bkk/lowongan/:slug` | Detail lowongan + **formulir lamaran online** |
| `/magang-jepang` | Program Magang ke Jepang (Ginou Jisshu & Tokutei Ginou): bidang kerja, syarat, alur seleksi, pelatihan, rincian biaya, alumni, FAQ |
| `/magang-jepang/daftar` | **Formulir pendaftaran seleksi** → nomor `MJ-2026-0001` |
| `/magang-jepang/cek-status` | Cek status seleksi magang |
| `/unduhan` | Pusat unduhan dokumen (brosur, formulir, panduan) |
| `/kontak` | Formulir kontak (tersimpan ke database), peta Google Maps, info kontak |

Tambahan: tombol WhatsApp melayang, judul tab per halaman, halaman 404, proteksi spam (honeypot + rate limit).

### Panel admin (`/kelola-infokom`)
- Login JWT dengan 2 peran: **admin** (akses penuh) dan **editor** (konten saja).
- Dashboard: ringkasan jumlah data, pendaftar per jurusan, pendaftar/pesan/berita terbaru.
- CRUD lengkap (tambah, ubah, hapus, cari, filter, paginasi) untuk:
  Berita, Agenda, Galeri, Prestasi, Ekstrakurikuler, Testimoni, Jurusan, Guru & Staf,
  Struktur Organisasi, Fasilitas, Sejarah, Mitra Industri, Pendaftar PPDB, Biaya, Tahapan PPDB,
  FAQ, Pesan Masuk, Pengguna Admin.
- Unggah gambar (dikompres otomatis di browser, maks. 5 MB).
- Verifikasi pendaftar: ubah status (baru, diverifikasi, diterima, cadangan, ditolak) + catatan yang terlihat oleh pendaftar.
- Ekspor CSV (pendaftar, pesan, dll.) — bisa dibuka di Excel.
- **Pengaturan Situs**: identitas sekolah, kontak, media sosial, teks beranda, visi misi, sambutan, gambar banner, info PPDB, buka/tutup pendaftaran online, dll.
- Akun Saya: ubah nama, email, dan password.

### Baru di v4
- Tampilan baru "Kampus Hijau": krem, hijau hutan, aksen lime; font Zodiak + Satoshi.
- **Video Instagram BKK & Magang Jepang**: menu admin *Video Instagram BKK* dan *Video Instagram Magang* (tambah/ubah/hapus, urutan, tampil/sembunyi, sampul opsional, pratinjau). Tempel tautan Reel/Post Instagram (akun harus publik). Video tampil di halaman `/bkk#video` dan `/magang-jepang#video`.
- **Guru & Staf dikelompokkan**: field *Kelompok* (Kepala Sekolah, Wakasek, Guru, Staf). Halaman Profil menampilkan tiga kelompok terpisah dengan tab filter. Database lama otomatis diisi kelompoknya berdasarkan jabatan saat `npm run db:setup`.
- Login admin tidak ditampilkan di web; alamat panel dipindah ke `/kelola-infokom`.

## Menjalankan di komputer lokal

Butuh **Node.js 18.18+** (disarankan 20 atau 22).

```bash
npm install
cp .env.example .env      # Windows: copy .env.example .env
npm run dev
```

- Situs: http://localhost:5175
- Panel admin: http://localhost:5175/kelola-infokom — login bawaan **admin / admin12345** (segera ganti lewat menu Akun Saya)
- API: http://localhost:4000/api/health

Saat pertama kali jalan, tabel database dibuat otomatis dan diisi data contoh (bisa dimatikan dengan `AUTO_SEED=false`).

## Database

### SQLite (bawaan)
Tidak perlu instalasi apa pun. File database: `database/smk_infokom.sqlite`.

### MySQL / MariaDB (XAMPP, Laragon, cPanel)
1. Buat database kosong, mis. `smk_infokom` (utf8mb4).
2. Ubah `.env`:
   ```env
   DB_CLIENT=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=
   DB_NAME=smk_infokom
   ```
3. Jalankan `npm run db:setup` (atau langsung `npm run dev` — tabel dibuat otomatis).

Alternatif: impor manual `database/schema.mysql.sql` lewat phpMyAdmin (file ini bisa dibuat ulang dengan `npm run db:sql`).

### PostgreSQL
```bash
npm install pg
```
Lalu isi `DB_CLIENT=pg` dan `DATABASE_URL=postgres://user:pass@host:5432/smk_infokom`.

### Perintah database
| Perintah | Fungsi |
|---|---|
| `npm run db:migrate` | Membuat/memperbarui tabel & kolom sesuai `server/resources.js` |
| `npm run db:seed` | Mengisi data contoh ke tabel yang masih kosong |
| `npm run db:setup` | migrate + seed |
| `npm run db:sql` | Menghasilkan `database/schema.mysql.sql` |

## Online (produksi)

```bash
npm install
npm run build          # hasil ke folder dist/
npm start              # Windows: npm run start:win
```

Satu server Node menyajikan situs (dist) + API + file unggahan di port `PORT` (bawaan 4000).
**Wajib** mengganti `JWT_SECRET` di `.env` dengan string acak panjang (mis. `openssl rand -hex 32`) — server akan menampilkan peringatan bila masih memakai nilai bawaan.

### VPS (Ubuntu) dengan PM2 + Nginx
```bash
npm install -g pm2
NODE_ENV=production pm2 start server/index.js --name smk-infokom
pm2 save && pm2 startup
```
Contoh blok Nginx:
```nginx
server {
  server_name smkinfokom.sch.id;
  client_max_body_size 10m;
  location / {
    proxy_pass http://127.0.0.1:4000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```
Pasang HTTPS dengan `certbot --nginx`.

### cPanel (Setup Node.js App)
1. Unggah proyek (tanpa `node_modules`), jalankan `npm run build` di lokal lalu ikut unggah folder `dist/`.
2. Setup Node.js App → Application startup file: `server/index.js`, mode: Production.
3. Buat database MySQL di cPanel, isi `.env` (DB_CLIENT=mysql, dst.) lalu klik **Run NPM Install** dan **Restart**.

### Frontend & API di domain berbeda (opsional)
Isi `VITE_API_URL=https://api.domainanda.sch.id` sebelum `npm run build`, dan isi `CORS_ORIGIN` di server API dengan domain frontend.

> Folder `uploads/` dan file database SQLite berisi data asli — sertakan dalam backup rutin.

## Endpoint API

**Publik** (`/api/public`)
| Metode | Endpoint | Keterangan |
|---|---|---|
| GET | `/settings` | Semua pengaturan situs |
| GET | `/beranda` | Data ringkas beranda |
| GET | `/:resource` | Daftar data (`?q=`, `?page=`, `?limit=`, filter, `?exclude=slug`) |
| GET | `/:resource/:slug-atau-id` | Detail data |
| POST | `/pesan` | Kirim pesan kontak |
| POST | `/pendaftaran` | Kirim formulir PPDB |
| GET | `/pendaftaran/cek?nomor=&tanggal_lahir=` | Cek status PPDB |

Resource publik: `berita, agenda, galeri, prestasi, ekskul, testimoni, jurusan, guru, struktur, fasilitas, sejarah, mitra, biaya, tahapan, faq`.

**Autentikasi** (`/api/auth`): `POST /login`, `GET /me`, `PUT /me`

**Admin** (`/api/admin`, header `Authorization: Bearer <token>`)
`GET /meta`, `GET /stats`, `GET|PUT /settings`, `POST /upload`,
`GET /:resource`, `GET /:resource/:id`, `POST /:resource`, `PUT /:resource/:id`, `DELETE /:resource/:id`, `GET /:resource/export.csv`

## Struktur folder

```
server/
  index.js            # Express: API + file statis + fallback SPA
  config.js           # membaca .env
  resources.js        # DEFINISI SEMUA TABEL: kolom, validasi, form & tabel admin
  settings.js         # daftar pengaturan situs + nilai bawaan
  db/                 # koneksi knex, sinkron tabel otomatis, data contoh, CLI
  lib/                # validasi & query generik
  middleware/auth.js  # JWT & peran
  routes/             # public.js, auth.js, admin.js
src/
  admin/              # panel admin (login, dashboard, CRUD generik, pengaturan, akun)
  components/         # komponen situs publik
  pages/              # halaman situs publik
  lib/api.js          # klien API, auth, unggah gambar
  lib/data.jsx        # SettingsProvider, usePublic, useList, helper format
public/images/        # gambar bawaan
uploads/              # gambar hasil unggahan admin
database/             # file SQLite & skema SQL
```

### Menambah tabel/fitur baru
Cukup tambahkan definisi di `server/resources.js` (nama field, tipe, label, validasi). Saat server dijalankan ulang,
tabel dibuat otomatis, API CRUD tersedia, dan menu + formulirnya langsung muncul di panel admin.


## Build pratinjau statis (opsional)
Untuk hosting statis tanpa fallback SPA: `VITE_BASE=./ VITE_HASH_ROUTER=1 VITE_API_URL=https://api.domain-anda npm run build`.

## Video & dokumen
- Video latar beranda, banner Magang, dan video profil Magang ada di `public/videos/`. URL-nya bisa diganti di **Admin → Pengaturan** (file .mp4 atau tautan YouTube untuk video profil).
- PDF PPDB (formulir pendaftaran isian, surat pernyataan orang tua, brosur) ada di `public/files/` dan tampil di halaman PPDB serta Pusat Unduhan. Kelola daftarnya lewat **Admin → Unduhan**.
- Panel admin tidak ditautkan dari situs publik; buka langsung `/kelola-infokom` (alamat bisa diganti lewat `VITE_ADMIN_PATH` di `.env`, lalu build ulang). Alamat `/admin` sengaja menampilkan 404, dan tidak ada tombol login di situs publik. Meta `noindex` mencegah panel diindeks mesin pencari.
